"use strict";

const CONSTANTS = {
    STATEMENT_TITLE: 'Bank Statement',
    STATEMENT_SUBTITLE: 'NSFAS',
    DATE: 'Date',
    DESCRIPTION: 'Description',
    AMOUNT: 'Amount',
    BALANCE: 'Balance',
    CLOSING_BALANCE: 'Closing Balance'
};

module.exports = {
    CONSTANTS: CONSTANTS
};