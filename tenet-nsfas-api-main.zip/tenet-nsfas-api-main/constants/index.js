"use strict";

module.exports = {
	messages:require("./constants")
};