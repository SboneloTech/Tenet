"use strict";

module.exports = {
	messages:require("./messages")
};