
const bcrypt = require('bcryptjs');
const config = require('config');
const jwt = require('jsonwebtoken');
const fs = require("fs");
const path = require('path');
var crypto = require("crypto");
const moment = require("moment");
module.exports = {
  hashPasswordUsingBcrypt: async (plainTextPassword) => {
    return await bcrypt.hashSync(plainTextPassword, 10);
  },

  comparePasswordUsingBcrypt: async (pass, hash) => {
    return await bcrypt.compareSync(pass, hash);
  },

  jwtSign: async (payload) => {
    // eslint-disable-next-line no-useless-catch
    try {
      return jwt.sign(payload, config.get("jwtOption.jwtSecretKey"), { expiresIn: config.get("jwtOption.expiresIn") });
    } catch (error) {
      throw error;
    }
  },

  jwtRefreshSign: async (payload) => {
    // eslint-disable-next-line no-useless-catch
    try {
      return jwt.sign(payload, config.get("jwtOption.jwtRefreshSecretKey"), { expiresIn: config.get("jwtOption.expiresIn") });
    } catch (error) {
      throw error;
    }
  },

  jwtRefreshVerify: async (token) => {
    try {
      return jwt.verify(token, config.get("jwtOption.jwtRefreshSecretKey"));
    } catch (e) {
      return false;
    }
  },

  jwtVerify: async (token) => {
    try {
      return jwt.verify(token, config.get("jwtOption.jwtSecretKey"));
    }
    catch (e) {
      return false;
    }
  },

  deleteFile: async (filePath) => {
    try {
      let paths = path.resolve(__dirname, filePath);
      fs.unlinkSync(paths);
    } catch (error) {
      console.log("error in delete file ", filePath);
    }
    return;
  },

  getJwtExpireTime: async () => {
    return parseInt(config.get("jwtOption.expiresIn").replace("s", ""));
  },
  getServerCurrentTime: async () => {
    return Math.floor(new Date().getTime() / 1000);
  },
  isEmail: (value) => {
    let re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(value).toLowerCase());
  },

  isPhone: (value) => {
    let intRegex = /[0-9 -()+]+$/;
    return intRegex.test(value);
  },

  generateRandom: (n) => {
    var add = 1, max = 12 - add;   // 12 is the min safe number Math.random() can generate without it starting to pad the end with zeros.   

    // if ( n > max ) {
    //         return generate(max) + generate(n - max);
    // }

    max = Math.pow(10, n + add);
    var min = max / 10; // Math.pow(10, n) basically
    var number = Math.floor(Math.random() * (max - min + 1)) + min;

    return ("" + number).substring(add);
  },

  generateRandomString: (n) => {
    return crypto.randomBytes(n).toString('hex');
  },
  chatTemplate: (chat, userId) => {
    let data = '';
    for (let i = 0; i < chat.length; i++) {
      if (JSON.stringify(chat[i].senderId) == JSON.stringify(userId))
        data += `<div class="message user-message">
          ${chat[i].text}
      </div>`;
      else
        data += `<div class="message other-message">
         ${chat[i].text}
     </div>`;
    }
    let str = `<!DOCTYPE html>
      <html>
      <head>
          <title>WhatsApp Chat</title>
          <style>
              body {
                  font-family: Arial, sans-serif;
                  margin: 0;
                  padding: 0;
                  background-color: #f4f4f4;
              }
              .chat-container {
                  max-width: 600px;
                  margin: 20px auto;
                  padding: 20px;
                  background-color: #ffffff;
                  border-radius: 15px;
                  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
              }
              .message {
                  border-radius: 10px;
                  border: 1px solid #ccc;
                  padding: 10px;
                  margin: 10px;
                  word-wrap: break-word;
                  max-width: 70%;
              }
              .user-message {
                  background-color: #DCF8C6;
                  float: right;
                  clear: both;
              }
              .other-message {
                  background-color: #E0E0E0;
                  float: left;
                  clear: both;
              }
          </style>
      </head>
      <body>
          <div class="chat-container">
              ${data}
          </div>
      </body>
      </html>
      `;
    return str;
  },
  chatNewTemplate: (chat, userId, firstName) => {
    let data = '';
    for (let i = 0; i < chat.length; i++) {
      if (JSON.stringify(chat[i].senderId) == JSON.stringify(userId))
        data += ` <tr>
      <td style="padding-bottom: 20px;" colspan="2">
         <figure style="margin: 0px;     margin-left: 20px;     width: 40px;float: left;">
          <img  src="./images/icn.png">
         </figure><p style="
            width: auto;
            background-color: #FFF4DE;
            padding: 10px 20px 10px 10px;
            margin: 0px;
            border-radius: 0px 10px 10px 10px;
            font-size: 15px;    line-height: 20px;
            float: left;
            ">${chat[i].text}<br><span style="   
            color: gray;
            font-size: 14px;
            margin-top: 10px;"> ${moment(chat[i].createdAt).format("HH:mm")}</span></p>
      </td>
   </tr>`;
      else
        data += `<tr>
     <td style="text-align: right; padding-bottom: 20px;" colspan="2">
        <figure style="margin: 0px;     margin-right: 20px;  width:55px; float: right;">
         <img style="width: 40px;" src="./images/profile.png">
        </figure><p style="
          width: auto;
           background-color: #EBEBEB;
           padding: 10px 10px 10px 20px;
           margin: 0px;
           border-radius: 10px 0px 10px 10px;
           font-size: 15px;    line-height: 20px;
           float: right;
           ">   ${chat[i].text}<br> <span style="  
           color: gray;
           font-size: 14px;
           margin-top: 10px;"> 11:20</span></p>
     </td>
  </tr>`;
    }
    let str = `<!DOCTYPE html
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office"
  style="font-family:arial, 'helvetica neue', helvetica, sans-serif">
  <head>
     <meta charset="UTF-8">
     <meta content="width=device-width, initial-scale=1" name="viewport">
     <meta name="x-apple-disable-message-reformatting">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta content="telephone=no" name="format-detection">
     <title>Template</title>
     <link rel="preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Poppins&family=Roboto&display=swap"
        rel="stylesheet">
  </head>
  <body style="width:100%; padding:0;margin:0;    background-color: #000;">
     <table width="600" cellspacing="0" cellpadding="0"
        style="margin: 0px auto; background-color: #ffff;">
        <tr>
           <td  colspan="2" style="text-align: center; padding: 20px 20px;">
              <figure style="    margin: 0px;">
                 <img style="    width: 100%;" src="https://kooban.s3.af-south-1.amazonaws.com/1693457230629_banner.png">
              </figure>
           </td>
        </tr>
        <tr>
           <td colspan="2">
              <h1 style="padding-left: 20px; margin: 0px; font-size: 24px;"> Hey, ${firstName}</h1>
              <p style="padding: 0px 20px; line-height: 1.5; font-size: 15px;"> You query has been <span style="color: #06B58B; font-weight: 600;"> Resolved.</span>I am here to personally thank you for considering us as your digital partner </p>
              <p style="background-color: #EBEBEB; margin: 0px; margin-bottom: 30px;    padding: 15px 20px; font-size: 15px;"> I am unable to connect my transation?</p>
           </td>
        </tr>

        ${data}
        <tr>
           <td colspan="2">
              <p style="font-size: 15px;
                 width: 63%;
                 text-align: center;
                 margin: 0 auto;
                 margin-top: 30px;
                 margin-bottom: 30px; color: #c2b7b7;"> This conversation has been marked as closed. if you have any other queries regarding this issue . Raise another query</p>
           </td>
        </tr>
     </table>
     <table width="600" cellspacing="0" cellpadding="0"style="margin: 0px auto;background-color: #fff;     padding: 20px;" >
        <tbody>
           <tr>
              <td  style="background-color:#eaab2126;     padding: 20px;">
                 <h3 style="    margin: 0px;
                    font-size: 18px; color:#EAAB21 "> Thank you once again,</h3>
                 <p style="margin: 0px;padding-bottom: 30px;
                    margin-top: 20px; font-size: 15px;"> <span style="font-size: 20px;
                    font-weight: 700;
                    line-height: 1.5; "> Tenet Technology</span><br> We are always there to serve you</p>
              </td>

              <td>
               <figure style="margin: 0px;">
                   <img style="    width: 287px;
                   background-color: #fcf3de;" src="https://kooban.s3.af-south-1.amazonaws.com/1693457346946_footer.png">
               </figure>
              </td>
           </tr>
        </tbody>
     </table>
  </body>`;
    return str;
  },

  clearJunk: (folder) => {
    folder = path.resolve(__dirname, folder);
    fs.readdir(folder, function (err, files) {
      if (err) {
        return console.error(err);
      }
      files.forEach(function (file) {
        fs.stat(path.join(folder, file), function (err, stat) {
          var endTime, now;
          if (err) {
            return console.error(err);
          }
          now = new Date().getTime();
          endTime = new Date(stat.ctime).getTime() + 3600000; //Older than 1 hour
          if (now > endTime) {
            return fs.unlink(path.join(folder, file), function (err) {
              if (err) {
                return console.error(err);
              }
            });
          }
        });
      });
    });
  }

};
