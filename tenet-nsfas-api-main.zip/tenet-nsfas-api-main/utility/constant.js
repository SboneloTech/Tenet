module.exports = {
  admin: {
    exportUrl: "static/csv/"
  },
  LANGUAGE_TYPE: {
    ENGLISH: "en"
  },
  USER_ROLE: {
    USER: "user",
    USER_KYC: "user_kyc"
  },
  DEVICE_TYPE: {
    ANDROID: 'ANDROID',
    IOS: 'IOS',
    WEB: 'WEB'
  },

  PUSH_TYPE_KEYS: {
    DEFAULT: 0,
    ACCEPTED: 1,
    HANGUP: 2,
    END: 3,
    INCOMING_VIDEO: 4,
    INCOMING_CALL: 5,
    POST: 6,
    CHAT: 7,
    PROFILE_VERIFY: 8
  },
  DOC_TYPE: {
    SOUTH_AFRICA_ID: 'SOUTH_AFRICA_ID',
    SOUTH_AFRICA_PASSPOERT: 'SOUTH_AFRICA_PASSPOERT',
    SA_DRIVER_LICENSE: 'SA_DRIVER_LICENSE',
    FOREIGN_PASSPORT: 'FOREIGN_PASSPORT',
    ASYLUMN_PASSPORT: 'ASYLUMN_PASSPORT',
    CUSTOM_DOC: 'CUSTOM_DOC',
    THUMB_SELFIE: 'THUMB_SELFIE'
  },
  QUERY_TYPE: [
    'Wallet Related Query',
    'KYC Related Query',
    'I am unable to complete my transaction ?',
    'My query is not listed here'
  ],
  STATUS_LIST: [
    'Link, selfie with ID',
    'Fraud',
    'Onboarded',
    'Not onboarded',
    'In progress',
    'Voicemail'
  ]

};
