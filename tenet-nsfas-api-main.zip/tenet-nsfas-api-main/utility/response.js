const responseCode = require("./responseCode");
// const appMessages = require("../lang");
// const constant = require("./constant")

function sendSuccessResponse(req, res, data, httpCode = responseCode.OK, message) {
    if (!data && message) {
        data = {
            message: message
        };
    } else if (data && message) {
        data.message = message;
    }
    let responseData = {};
    data = data || {};
    responseData.data = data;
    if (data.pagination) {
        responseData = data;
        // responseData.total = data.count;
        // responseData.pageCount = Math.ceil(data.count / data.limit);
        // headers["x-total"] = data.count;
        // headers["x-total-pages"] = Math.ceil(data.count / data.limit);
    }
    if (!data.noCode) {
        responseData.statusCode = 200;
    } responseData.message = data.message || "";

    res.status(httpCode).send(responseData);
}

function sendAcceptedResponse(req, res, data, httpCode = 202, message) {
    if (!data && message) {
        data = {
            message: message
        };
    } else if (data && message) {
        data.message = message;
    }
    let responseData = {};
    let headers = {};
    data = data || {};
    responseData.data = data;
    if (data.pagination) {
        responseData = data;
        // responseData.total = data.count;
        // responseData.pageCount = Math.ceil(data.count / data.limit);
        // headers["x-total"] = data.count;
        // headers["x-total-pages"] = Math.ceil(data.count / data.limit);
    }
    if (!data.noCode) {
        responseData.statusCode = 202;
    } responseData.message = data.message || "";

    res.status(httpCode).send(responseData);
}

function sendFailResponse(req, res, httpCode = responseCode.BAD_REQUEST, message, data) {
    if (!data && message) {
        data = {
            statusCode: httpCode,
            message: message
        };
    } else if (data && message) {
        data.message = message;
    }
    if (data) {
        data.data = {};
    }
    res.status(httpCode).send(data);
}



module.exports = {
    sendSuccessResponse,
    sendFailResponse,
    sendAcceptedResponse
    // getMessage
};