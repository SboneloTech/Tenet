const winston = require('winston');

const nrLogger = winston.createLogger({
    level: 'error',
    format: winston.format.json(),
    transports: [
        //
        // - Write all logs with importance level of `error` or less to `error.log`
        // - Write all logs with importance level of `info` or less to `combined.log`
        //
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
        new winston.transports.File({ filename: 'combined.log' })
    ]
});

/**
 * Logs To new relic
 * @param {string} message String stating the message e.g. "Invalid Credentials"
 * @param {object} traceIds object of the traceIds  e.g {ukhesheTraceid: '', nsfasTraceID: ''}
 * @param {object} details Object of whats needed e.g {identity: '', phonenumber: '', deviceType}
 * @param {string} type type
 * @returns {void}
 */
function logToNewRelic(message, traceIds, details, type = 'info') {
    switch (type) {
        case 'error':
            nrLogger.error(message, { traceIds: { ...traceIds }, details: { ...details } });
            break;

        default:
            nrLogger.info(message, { traceIds: { ...traceIds }, details: { ...details } });
            break;
    }

}

module.exports = {
    logToNewRelic
};