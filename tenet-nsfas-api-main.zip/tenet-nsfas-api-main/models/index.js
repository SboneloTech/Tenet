
module.exports = {
    user: require("./user"),
    otp: require('./otp'),
    admin: require('./admin'),
    subAdmin: require('./subAdminPermission'),
    cms: require('./cms'),
    notification: require("./notifications"),
    faq: require('./faq'),
    userDocument: require("./userDocument"),
    studentCards: require("./studentCards"),
    query: require('./help'),
    error: require('./errorLogs'),
    errorPin: require('./errorPin'),
    chatMessage: require('./chatMessage'),
    archivedUsers: require('./archivedUser')

};