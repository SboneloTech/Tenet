const MONGOOSE = require("mongoose");
const Schema = MONGOOSE.Schema;

const helpModel = new Schema({

    name: { type: String, default: "" },
    email: { type: String, default: "" },
    phone: { type: String, default: "" },
    query: { type: String, default: "" },
    countryCode: { type: String, default: "" },
    isoCode: { type: String, default: "" },

    isDeleted: { type: Boolean, default: false },

    isResolved: { type: Boolean, default: false },
    resolvedRemarks: { type: String, default: "" },
    userId: { type: Schema.Types.ObjectId, ref: 'user' }

},
    { timestamps: true }
);

const help = MONGOOSE.model("help", helpModel);
module.exports = help;
