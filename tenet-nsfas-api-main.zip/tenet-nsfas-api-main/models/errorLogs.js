const MONGOOSE = require("mongoose");
const Schema = MONGOOSE.Schema;

const errorModel = new Schema(
    {
        header: { type: String, default: "" },
        body: { type: String, default: "" },
        token: { type: String, default: "" },
        error: { type: String, default: "" },
        url: { type: String, default: "" },
        response: { type: String, default: "" },
        statusCode: { type: String, default: "" },
        isDeleted: { type: Boolean, default: false }
    },
    { timestamps: true }
);

const error = MONGOOSE.model("error", errorModel);
module.exports = error;