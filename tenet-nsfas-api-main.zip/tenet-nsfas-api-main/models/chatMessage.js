const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const ObjectId = Schema.Types.ObjectId;

const ChatMessageModel = new Schema({
    type: {
        type: String,
        enum: ["TEXT", "VIDEO", "DOC", "IMAGE", "AUDIO", "LOCATION"],
        default: "TEXT"
    },
    senderId: { type: ObjectId, ref: "user", required: true },
    recieverId: { type: ObjectId, ref: "user", required: true },
    adminId: { type: ObjectId, ref: "user" },
    queryType: { type: String },
    connectionId: { type: String },
    text: { type: String },
    uploads: { type: String },
    thumbnail: { type: String },
    isReaded: { type: Boolean, default: false },
    latitude: { type: Number },
    longitude: { type: Number },

    seenBy: [{ type: Schema.Types.ObjectId, ref: "user" }],
    isDeleted: { type: Boolean, default: false },

    isQueryResolved: { type: Boolean, default: false },

    isEscalated: { type: Boolean, default: false },
    resolvedBy: {
        type: String,
        enum: ["ADMIN", "SUBADMIN", "USER"],
        default: "SUBADMIN"
    },
    assign: {
        type: String,
        enum: ["AUTO_ASSIGN", "ASSIGN_BY_ADMIN", "PENDING"],
        default: "PENDING"
    },
    accountType: { type: String, enum: ["TENET", "NSFAS"], default: "TENET" },
    status: { type: String }


},
    {
        timestamps: true,
        toObject: { virtuals: true },
        toJSON: { virtuals: true }
    }
);
ChatMessageModel.index({ senderId: 1 });
ChatMessageModel.index({ recieverId: 1 });
ChatMessageModel.index({ connectionId: 1 });

const ChatMessage = mongoose.model("Chatmessage", ChatMessageModel);
module.exports = ChatMessage;
