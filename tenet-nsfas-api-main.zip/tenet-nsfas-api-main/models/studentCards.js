const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const studentCardsModel = new Schema({

    IDNumber: { type: String, index: true },
    StudentNumber: { type: String },
    Name: { type: String },
    Gender: { type: String },
    MobileNumber: { type: String },
    RegistrationDate: { type: String },
    InstitutionID: { type: String },
    InstitutionName: { type: String },
    CampusName: { type: String },
    StudyTerm: { type: String },
    WalletType: { type: String },
    WalletName: { type: String },
    WalletDescription: { type: String },
    KYC: { type: String },
    CardID: { type: String },
    CardNumber: { type: String },
    CardType: { type: String },
    DateCardIssued: { type: String },
    DateCardActivated: { type: String },
    CardIssued: { type: String }

}, {
    timestamps: true,
    toObject: { virtuals: true },
    toJSON: { virtuals: true }
});

const studentCard = mongoose.model("studentCards", studentCardsModel);
module.exports = studentCard;
