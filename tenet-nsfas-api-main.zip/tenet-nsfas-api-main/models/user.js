const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const UserModel = new Schema({

    isSocialLogin: { type: Boolean, default: false },
    socialId: { type: String },
    socialType: { type: String, enum: ["FACEBOOK", "GOOGLE", "APPLE"] },
    role: { type: String, enum: ["user", "ADMIN", "SUBADMIN"], default: "user" },
    fullName: { type: String, default: "", trim: true },
    userName: { type: String, default: "", trim: true },
    firstName: { type: String, default: "", trim: true },
    lastName: { type: String, default: "", trim: true },
    email: { type: String, lowercase: true, index: true, trim: true },
    phone: { type: String, trim: true, default: "" },
    identityPhone: { type: String, trim: true, default: "" },
    saIdNo: { type: String, trim: true, default: "", index: true },
    countryCode: { type: String, trim: true },
    isProfileComplete: { type: Boolean, default: false },
    isEmailVerify: { type: Boolean, default: false },
    isPhoneVerify: { type: Boolean, default: false },
    isVerifiedByAdmin: { type: Boolean, default: false },
    password: { type: String, default: "", select: false },
    submitKey: { type: String, default: "", select: false }, // password hash 
    deviceId: { type: String, default: "" }, // deviceId
    passCode: { type: String, default: "" },
    passCodeRamdom: { type: String, default: "" }, // for Passcode check security
    image: { type: String, default: "" },
    coverImage: { type: String, default: "" },
    dateOfBirth: { type: String, default: "" },
    title: { type: String, enum: ["CHIEF", "DR", "MISS", "MR", "MRS", "MS", "SIR"] },
    maritalStatus: { type: String, enum: ["S", "M", "D", "W"] },
    gender: { type: String, enum: ["M", "F", "O"] },
    jti: { type: String, default: "", trim: true, select: false },
    zipCode: { type: String, default: null },
    profileCompleteAt: { type: Number, default: 0 },
    ukhesheCustId: { type: String }, // ukhesheCustId customer Id
    ukhesheExternalCustId: { type: String }, // ukhesheCustId customer Id
    locale: { type: String, default: null },

    location: {
        type: {
            type: String,
            enum: ["Point"],
            default: "Point"
        },
        coordinates: { type: [Number], default: [0, 0] }
    },

    deviceType: { type: String, default: "" },
    deviceToken: { type: String, default: "" },

    isKYCCompleted: { type: Boolean, default: false },

    isThumbKyc: { type: Boolean, default: false },
    selfieIsASelfie: { type: Boolean, default: false },
    selfieIsLegitimate: { type: Boolean, default: false },
    selfieMatchesIdentity: { type: Boolean, default: false },
    firstNameMatchesIdentity: { type: Boolean, default: false },
    lastNameMatchesIdentity: { type: Boolean, default: false },
    identityNumberMatchesIdentity: { type: Boolean, default: false },
    idChecksPassed: { type: Boolean, default: false },
    selfieChecksPassed: { type: Boolean, default: false },
    isNotificationEnable: { type: Boolean, default: false },
    isDeleted: { type: Boolean, default: false, index: true },
    isBlocked: { type: Boolean, default: false },
    latitude: { type: String, default: 0 },
    longitude: { type: String, default: 0 },
    documentExpiryDate: {
        type: Date
    },
    adminId: { type: Schema.Types.ObjectId, ref: "user" },
    userType: { type: String, enum: ["TENET", "NSFAS"], default: "TENET" },
    queryCount: { type: Number, default: 0 },
    time: { type: String, default: "", select: false }

}, {
    timestamps: true,
    toObject: { virtuals: true },
    toJSON: { virtuals: true }
}
);
UserModel.index({ userLocation: "2dsphere" });

UserModel.pre(/save|create|update/i, function (next) {
    if (this.get("latitude") && this.get("longitude")) {
        const longitude = this.get("longitude");
        const latitude = this.get("latitude");
        const geoPoint = {
            type: "Point",
            coordinates: [parseFloat(longitude), parseFloat(latitude)]
        };
        this.set({ geoPoint });
    }
    // if (this.get("firstName")) {
    //     const firstName = this.get("firstName");
    //     const lastName = this.get("lastName");
    //     let fullName = firstName + " " + lastName;
    //     this.set({ fullName });
    // }

    next();
});
const User = mongoose.model("user", UserModel);
module.exports = User;
