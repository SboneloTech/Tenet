const MONGOOSE = require("mongoose");
const Schema = MONGOOSE.Schema;

const errorModel = new Schema({

    userId: { type: Schema.Types.ObjectId, ref: 'user' },
    lastTryAt: { type: Date, default: null },

    lastTryCount: { type: Number, default: 0 },

    isDeleted: { type: Boolean, default: false },

    type: {
        type: String, default: 'PASSCODE',
        enum: ['PASSCODE', 'OTP']
    }

},
    { timestamps: true }
);

const error = MONGOOSE.model("errorPin", errorModel);
module.exports = error;
 