const MONGOOSE = require("mongoose");
const Schema = MONGOOSE.Schema;

const cmsModel = new Schema(
    {
        security: { type: String, default: "" },
        contact: { type: String, default: "" },
        support: { type: String, default: "" },
        terms: { type: String, default: "" },
        about: { type: String, default: "" },
        privacyPolicy: { type: String, default: "" },

        legal: { type: String, default: "" },
        email: { type: String, default: "" },
        phone: { type: String, default: "" },
        isDeleted: { type: Boolean, default: false }
    },
    { timestamps: true }
);

const cms = MONGOOSE.model("cms", cmsModel);
module.exports = cms;
