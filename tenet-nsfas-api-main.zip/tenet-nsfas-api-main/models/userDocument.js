const MONGOOSE = require("mongoose");
const constant = require("../utility/constant");
const Schema = MONGOOSE.Schema;

const userDocModel = new Schema({
    userId: { type: Schema.Types.ObjectId, ref: 'user' },
    document: { type: String, default: "" },
    ukhesheDocId: { type: String, default: "" },
    ukhesheDocType: { type: String, default: "" },


    hash: { type: String, default: "" },
    signature: { type: String, default: "" },
    doc_Number: { type: String, default: "" },
    doc_type: {
        type: String, enum: Object.values(constant.DOC_TYPE)
    },

    type: { type: String, enum: ["FRONT", "BACK", "OTHERS"], default: "OTHERS" },

    expiredDate: { type: String, default: "" },
    isVerified: { type: Boolean, default: false },

    dac_detail: [{ type: String }],

    isDeleted: { type: Boolean, default: false },
    isBlocked: { type: Boolean, default: false }

},
    { timestamps: true }
);

const docs = MONGOOSE.model("userDocument", userDocModel);
module.exports = docs;
