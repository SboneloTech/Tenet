const joi = require("joi");
const constant = require("../../utility/constant");

const validateSchema = async (inputs, schema) => {
    // eslint-disable-next-line no-useless-catch
    try {
        const { error } = schema.validate(inputs, {
            stripUnknown: true
        });
        if (error) {
            console.log('error.details', error.details);
        }
        if (error) throw error.details ? error.details[0].message.replace(/['"]+/g, "") : "";
        else return false;
    } catch (error) {
        throw error;
    }
};


// ***************************** ONBAORDING ******************************* //

const validateSignUp = async (req, property = "body") => {
    let schema = {};
    schema = joi.object().keys({
        key: joi.string().optional(),
        countryCode: joi.string().optional(),
        password: joi.string().optional(),
        sek: joi.string().optional(),
        appKey: joi.string().optional(),
        hash: joi.string().optional()
    });

    return await validateSchema(req[property], schema);
};

const validateVerifyOtp = async (req, property = "body") => {
    let schema = {};
    schema = joi.object().keys({
        key: joi.string().required(),
        code: joi.string().required(),
        countryCode: joi.string().required(),
        type: joi.string().optional()
    });
    return await validateSchema(req[property], schema);
};

const setPassword = async (req, property = "body") => {
    let schema = {};
    schema = joi.object().keys({
        password: joi.string().required()
    });
    return await validateSchema(req[property], schema);
};

const socialLogin = async (req, property = "body") => {
    let schema = joi.object().keys({
        email: joi.string().optional(),
        phone: joi.string().optional(),
        image: joi.string().optional(),
        userName: joi.string().optional(),
        firstName: joi.string().optional(),
        lastName: joi.string().optional(),
        countryCode: joi.string().optional(),
        socialId: joi.string().required(),
        socialType: joi.string().optional().valid("FACEBOOK", "GOOGLE", "APPLE"),
        deviceType: joi.string().optional().valid("ANDROID", "IOS", "WEB"),
        role: joi.string().valid(constant.USER_ROLE.USER, constant.USER_ROLE.USER_KYC).required(),
        deviceToken: joi.string().when("deviceType", { is: "ANDROID", then: joi.string().optional() })
            .concat(joi.string().when("deviceType", { is: "IOS", then: joi.string().optional() })
                .concat(joi.string().when("deviceType", { is: "WEB", then: joi.string().allow("", null).optional() }))
            )
    });
    return await validateSchema(req[property], schema);
};

const validateProfileUpdate = async (req, property = "body") => { // coming soon app
    let schema = joi.object().keys({
        email: joi.string().optional(),
        phone: joi.string().optional(),
        fullName: joi.string().optional(),
        firstName: joi.string().optional(),
        lastName: joi.string().optional(),
        userName: joi.string().optional(),
        countryCode: joi.string().optional(),
        deviceType: joi.string().optional().valid("ANDROID", "IOS", "WEB"),
        deviceToken: joi.string().optional(),
        title: joi.string().optional().valid("CHIEF", "DR", "MISS", "MR", "MRS", "MS", "SIR"),
        image: joi.string().optional(),
        documentExpiryDate: joi.string().optional(),
        dateOfBirth: joi.string().optional(),
        maritalStatus: joi.string().optional().valid("S", "M", "D", "W"),
        gender: joi.string().optional().valid("F", "M", "O"),
        latitude: joi.number().optional(),
        longitude: joi.number().optional(),
        isProfileComplete: joi.boolean().optional(),
        address: joi.string().optional(),
        zipCode: joi.string().allow('', null).optional(),
        coverImage: joi.string().optional(),
        password: joi.string().allow('', null).optional(),
        saIdNo: joi.string().optional(),
        isRunKycAlgo: joi.boolean().optional()
    });
    return await validateSchema(req[property], schema);
};
const updatepassCode = async (req, property = "body") => { // coming soon app
    let schema = joi.object().keys({
        passCode: joi.string().required(),
        isUpdate: joi.boolean().optional(),
        passCodeRamdom: joi.string().optional()
    });
    return await validateSchema(req[property], schema);
};

const validateLogIn = async (req, property = 'body') => {
    let schema = {};
    schema = joi.object().keys({
        countryCode: joi.string().allow('', null).optional(),
        userName: joi.string().allow('', null).optional(),
        saIdNo: joi.string().allow('', null).optional(),
        email: joi.string().allow('', null).optional(),
        role: joi.string().optional(),
        phone: joi.string().allow('', null).regex(/^[0-9]+$/).min(5).optional(),
        password: joi.string().required(),
        deviceType: joi.string().optional().valid("ANDROID", "IOS", "WEB"),
        deviceToken: joi.string()
            .when('deviceType', { is: "ANDROID", then: joi.string().optional() })
            .concat(joi.string().when('deviceType', { is: "IOS", then: joi.string().optional() })
                .concat(joi.string().when('deviceType', { is: "WEB", then: joi.string().allow('', null).optional() })))
    });
    return await validateSchema(req[property], schema);
};

const validateChangePassword = async (req, property = 'body', forReset) => {
    let schema = {};
    if (forReset) {
        schema = joi.object().keys({
            password: joi.string().required()
        });
    } else {
        schema = joi.object().keys({
            oldPassword: joi.string().required(),
            password: joi.string().required()
        });
    }
    return await validateSchema(req[property], schema);
};

//*********************************** DashBoard **************************************//
const validateDashBoard = async (req, property = 'query') => {
    let schema = joi.object().keys({
        page: joi.number().optional(),
        limit: joi.number().optional(),
        timeZone: joi.string().required()
    });
    return await validateSchema(req[property], schema);
};

const findSaId = async (req, property = 'body') => {
    let schema = joi.object().keys({
        saIdNo: joi.string().required(),
        deviceId: joi.string().required()
    });
    return await validateSchema(req[property], schema);
};
const validateDocsUploads = async (req, property = 'body') => {
    let schema = joi.object().keys({
        document: joi.string().optional(),
        doc_Number: joi.string().optional(),
        type: joi.string().required().valid("FRONT", "BACK", "OTHERS"),
        doc_type: joi.string().optional(),
        isSelfie: joi.boolean().optional(),
        isThumb_image: joi.boolean().optional(),
        isAllDocCompleted: joi.boolean().optional(),
        isProfileUpdate: joi.boolean().optional(),
        expiredDate: joi.string().optional()
    });
    return await validateSchema(req[property], schema);
};
const validateDocuments = async (req, property = 'body') => {
    let schema = joi.object().keys({
        document: joi.string().required(),
        signType: joi.string().required().valid(constant.DOC_SHARE.ME, constant.DOC_SHARE.ME_AND_OTHERS,
            constant.DOC_SHARE.ONLY_OTHERS),
        toBeSigned: joi.array().optional(),
        pages: joi.number().optional(),
        signature: joi.string().optional(),
        thumbnail: joi.string().optional()

    });
    return await validateSchema(req[property], schema);
};

const airtimePayment = async (req, property = 'body') => {
    let schema = joi.object().keys({
        requestId: joi.string().required(),
        vendorId: joi.string().required(),
        // constant.DOC_SHARE.ONLY_OTHERS),
        mobileNumber: joi.string().required(),
        amount: joi.number().required(),
        productId: joi.string().optional(),
        description: joi.string().required(),
        fromWalletId: joi.string().required(),
        cardId: joi.string().optional(),
        type: joi.number().valid(0, 1).required()
        // toWalletId: joi.string().required()


    });
    return await validateSchema(req[property], schema);
};

const validateHeaders = async (req, property = 'headers') => {
    let schema = joi.object({
        origin: joi.string().optional(),
        referer: joi.string().optional(),
        accept: joi.string().optional(),
        authorization: joi.string().optional(),
        host: joi.string().optional(),
        connection: joi.string().optional(),
        "content-language": joi.string().optional(),
        "content-type": joi.string().optional(),
        "content-length": joi.string().optional(),
        "user-agent": joi.string().optional(),
        "accept-encoding": joi.string().optional(),
        "postman-token": joi.string().optional(),
        "sec-ch-ua": joi.string().optional(),
        "sec-ch-ua-mobile": joi.string().optional(),
        "sec-ch-ua-platform": joi.string().optional(),
        "sec-fetch-site": joi.string().optional(),
        "sec-fetch-mode": joi.string().optional(),
        "sec-fetch-dest": joi.string().optional(),
        "accept-language": joi.string().optional(),
        "x-forwarded-for": joi.string().optional(),
        "x-forwarded-host": joi.string().optional(),
        "x-forwarded-server": joi.string().optional(),
        "cache-control": joi.string().optional(),
        "upgrade-insecure-requests": joi.string().optional(),
        "sec-fetch-user": joi.string().optional(),
        "cookie": joi.string().optional(),
        "if-none-match": joi.string().optional(),
        "if-modified-since": joi.string().optional(),
        "x-real-ip": joi.string().optional()
    });
    return await validateSchema(req[property], schema);

};

module.exports = {
    airtimePayment,
    validateHeaders,
    findSaId,
    validateSignUp,
    validateVerifyOtp,
    setPassword,
    validateProfileUpdate,
    socialLogin,
    validateLogIn,
    validateChangePassword,
    validateDashBoard,
    updatepassCode,
    validateDocsUploads,
    validateDocuments

};

