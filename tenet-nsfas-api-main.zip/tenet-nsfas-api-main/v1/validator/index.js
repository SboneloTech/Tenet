module.exports = {
    user: require("./user"),
    admin : require('./admin')
    
};
