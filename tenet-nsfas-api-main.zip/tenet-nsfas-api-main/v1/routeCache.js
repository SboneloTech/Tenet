const NodeCache = require('node-cache');

const cache = new NodeCache();

module.exports = duration => (req, res, next) => {
    // Is request a get
    // if not call next
    if (req.method !== 'GET') {
        console.error('CANNOT CACHE NON-GET-Methods');
        next();
    }
    // check if key exists
    const key = req.originalUrl;
    const cachedResponse = cache.get(key);
    // if it exists, send cached result
    if (cachedResponse) {
        console.log(`Cache hit for ${key}`);
        res.send(cachedResponse);
    } else {
        console.log(`Cache miss for ${key}`);
        res.originalSend = res.send;
        res.send = body => {
            res.originalSend(body);
            cache.set(key, body, duration);
        };
        next();
    }

};