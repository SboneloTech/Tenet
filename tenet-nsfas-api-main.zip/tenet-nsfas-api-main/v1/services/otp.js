const Model = require('../../models');
const moment = require('moment');
const emailService = require('../services/emailService');
const mongoose = require('mongoose');
const smsService = require("./SMSService");


async function generatePhoneOtp(countryCode, phone, user, otpCode = '1234', expiredAt = moment().add(5, 'minutes').toDate()) {
    let data = {
        phone: phone,
        countryCode: countryCode,
        code: otpCode,
        expiredAt: expiredAt
    };
    if (user) {
        data.userId = user._id;
    }
    await smsService.sendSMSToPhone(countryCode, phone, otpCode);

    return { isSuccess: true };
}
async function generateOtp(countryCode, phone, type, user, otpCode = '1234', expiredAt = moment().add(5, 'minutes').toDate()) {
    await Model.otp.deleteMany({
        phone: phone, countryCode: countryCode
    }); //Clear Old Send otp message
    let data = {

        phone: phone,
        countryCode: countryCode,
        code: otpCode,
        expiredAt: expiredAt,
        type: type
    };
    if (user) {
        data.userId = user._id;
    }
    await smsService.sendSMSToPhone(countryCode, phone, otpCode);

    return { isSuccess: true };
}

async function generateEmailVerification(email, user, code = '1234', expiredAt = moment().add(60, 'minutes').toDate()) {

    email = email.toLowerCase();
    await Model.otp.deleteMany({
        email: email
    }); //Clear Old Send otp message
    let data = {
        email: email,
        code: code,
        expiredAt: expiredAt
    };
    if (!data.code) {
        data.code = '1234';
    }
    if (user) {
        data.userId = user._id;
    }
    let otp = await Model.otp.create(data);

    if (user) {
        emailService.sendOtpEmail(email, user.firstName, otp.code);
    } else {
        emailService.sendOtpEmail(email, "", otp.code);
    }

    return otp;
}
async function generateEmailVerificationOtp(email, type, user, code = '1234', expiredAt = moment().add(60, 'minutes').toDate()) {
    email = email.toLowerCase();
    await Model.otp.deleteMany({
        email: email
    }); //Clear Old Send otp message
    let data = {
        email: email,
        code: code,
        expiredAt: expiredAt,
        type: type
    };
    if (!data.code) {
        data.code = '1234';
    }
    if (user) {
        data.userId = user._id;
    }
    let otp = await Model.otp.create(data);

    if (user) {
        emailService.sendOtpEmail(email, user.firstName, otp.code);
    } else {
        emailService.sendOtpEmail(email, "", otp.code);
    }

    return otp;
}
async function verifyEmailCode(email, code, removeOtp = true) {
    return await verifyPhoneOtp(null, email, code, removeOtp, false);
}

async function verifyPhoneOtp(countryCode, key, otpCode, removeOtp = true, isForEmail = false, userId) {
    if (isForEmail == false) {

        key = key.trim();

        if (key.startsWith('0')) {
            key = key.slice(1);
        }

        let number = countryCode + key;
        return await smsService.verifySMSToPhone(otpCode, number);

    } else {
        let qry = {
            code: otpCode,
            expiredAt: {
                $gte: new Date()
            }
        };
        if (isForEmail) {
            qry.email = key.toLowerCase();
        } else {
            qry.phone = key;
        }
        if (userId) {
            qry.userId = mongoose.Types.ObjectId(userId);
        }
        if (countryCode) {
            qry.countryCode = countryCode;
        }
        let otp = await Model.otp.findOne(qry, { _id: 1 });
        if (otp && removeOtp) {
            otp.remove();
        }
        return otp;
    }
}


async function verotp(countryCode, key, otpCode, removeOtp = true, isForEmail = false, userId, type) {

    if (key.startsWith('0')) {
        key = key.slice(1);
    }

    if (isForEmail == false) {
        let number = countryCode + key;
        return await smsService.verifySMSToPhone(otpCode, number);

    } else {
        let qry = {
            code: otpCode,
            type: type,
            expiredAt: {
                $gte: new Date()
            }
        };
        if (isForEmail) {
            qry.email = key.toLowerCase();
        } else {
            qry.phone = key;
        }
        if (userId) {
            qry.userId = mongoose.Types.ObjectId(userId);
        }
        if (countryCode) {
            qry.countryCode = countryCode;
        }
        let otp = await Model.otp.findOne(qry, { _id: 1 });
        if (otp && removeOtp) {
            otp.remove();
        }
        return otp;

    }
}



module.exports = {
    generatePhoneOtp,
    generateEmailVerification,
    verifyPhoneOtp,
    verifyEmailCode,
    generateEmailVerificationOtp,
    generateOtp,
    verotp
};