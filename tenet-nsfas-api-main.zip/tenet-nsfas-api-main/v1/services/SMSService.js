const axios = require('axios');
const ukheshe = require('./ukhesheService');
const logger = require('../services/logger');
const moment = require('moment');

async function sendSMSToPhone(countryCode, phone) {
    const startTime = moment().unix();
    try {

        //replace 27 in number if its the first 2 digits
        if (phone.substring(0, 2) == '27') {
            phone = phone.replace('27', '');
        }

        if (phone.startsWith('0')) {
            phone = phone.slice(1);
        }

        let token = await ukheshe.createkhesheToken(true);
        let body = JSON.stringify({
            "tenantId": process.env.UKHESHE_TENANT_ID,
            "type": "SMS",
            "phone":  "+27" + phone
        });

        let config = {
            method: 'post',
            url: process.env.UKHESHE_BASE_URL + '/eclipse-conductor/rest/v1/global/verifications',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: body
        };

        const response = await axios(config).catch((error) => {
            // logger.error('Error sending Ukheshe SMS..', {
            //     body: JSON.stringify(error),
            //     duration: moment().unix() - startTime,
            //     UkTraceId: error.response.data[0].traceId,
            //     UkErrorMessage: error.response.data[0].description
            // });
            throw (error);
        });

        logger.info('Ukheshe SMS Response', {
            body: JSON.stringify(response.data),
            duration: moment().unix() - startTime,
            UkeTraceId: response.config.headers.traceparent
        });
    } catch (error) {
        logger.error('Error sending Ukheshe SMS', {
            body: JSON.stringify(error.message),
            duration: moment().unix() - startTime,
            UkeTraceId: error.response.data[0].traceId,
            UkeErrorMessage: error.response.data[0].description
        });
    }
}

async function sendSMSToIdentity(identity) {
    const startTime = moment().unix();
    try {
        let token = await ukheshe.createkhesheToken(true);
        let body = JSON.stringify({
            "tenantId": process.env.UKHESHE_TENANT_ID,
            "type": "SMS",
            "identity": identity
        });

        let config = {
            method: 'post',
            url: process.env.UKHESHE_BASE_URL + '/eclipse-conductor/rest/v1/global/verifications',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: body
        };

        const response = await axios(config).catch((error) => {
            throw (error);
            // logger.error('Error sending Ukheshe SMS..', {
            //     body: JSON.stringify(error),
            //     duration: moment().unix() - startTime,                
            // });
        });

        logger.info('Ukheshe SMS Response', {
            body: JSON.stringify(response.data),
            duration: moment().unix() - startTime,
            UkeTraceId: response.config.headers.traceparent
        });
    } catch (error) {
        logger.error('Error sending Ukheshe SMS', {
            body: JSON.stringify(error),
            duration: moment().unix() - startTime,
            UkeTraceId: error.response.data[0].traceId,
            UkeErrorMessage: error.response.data[0].description
        });
    }
}


async function verifySMSToPhone(code, identifier) {
    try {
        if (code == '001100' && (process.env.NODE_ENV == 'dev' || process.env.NODE_ENV == 'qa')) {
            return { data: {}, isSuccess: true };
        }
        
        let token = await ukheshe.createkhesheToken(true);
        let config = {
            method: 'get',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/global/verifications/${identifier}?code=${code}`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            }
        };

        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return { data: (error.response.data), isSuccess: false };
    }
}

module.exports = {
    sendSMSToPhone: sendSMSToPhone,
    verifySMSToPhone: verifySMSToPhone,
    sendSMSToIdentity: sendSMSToIdentity
};