const Model = require("../../models");
const responseCode = require("../../utility/responseCode");
const Otp = require("./otp");
const config = require('config');
const utility = require("../../utility/Utility");
const mongoose = require("mongoose");
const airtime = require("./airTime");
const common = require("./common");
const moment = require("moment");
const constant = require("../../utility/constant");
const ukhesheService = require('./ukhesheService');
var pdf = require('html-pdf-node');
var path = require("path");
// const notification = require('../../utility/pushNotifications');
const ObjectId = mongoose.Types.ObjectId;
const fileUpload = require("./fileUpload");
const request = require("request");
const fs = require('fs');
const fs1 = require('fs-extra');
var aws = require('aws-sdk');
const { execSync } = require('child_process');
const axios = require('axios');

async function getCatalog(req,res) {
    let accessToken = req.headers["ukheshetoken"];
    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/vas/catalogs`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

module.exports = {
    getCatalog
};