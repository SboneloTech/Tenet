const server = require("socket.io");
const Utility = require('../../utility/Utility');
const chatService = require('./chatService');
const common = require('./common');

const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;

const io = server();

let users = {};
var usersSockets = {};


io.use(async (socket, next) => {
  if (socket.handshake.query.token) {
    let token = socket.handshake.query.token;
    let decoded = await Utility.jwtVerify(socket.handshake.query.token);
    if (!decoded) return next(new Error("Authentication error"));
    else {
      users[String(socket.id)] = decoded._id;
      usersSockets[decoded._id] = socket;
      socket.join(String(decoded._id));
      next();
    }
  } else {
    next(new Error("Authentication error"));
  }
}).on("connection", function (socket) {

  // one to one chat sockets
  socket.on("connectToChat", async (data) => {
    let roomId = "chat_" + data.connectionId;
    socket.join(roomId);
    io.to(roomId).emit("connectToChatOk", { status: 200, message: "Room successfully joined" });
  });
  socket.on("test", async () => {
    io.to(users[String(socket.id)]).emit("testOk", { status: 200, message: "Room successfully joined" });
  });

  socket.on("disconnect", () => {
  });

  socket.on("sendMessage", async (data) => {
    let user = users[String(socket.id)];
    let roomId = "chat_" + data.connectionId;
    let message = await chatService.sendMessage(data, user);
    if (!message) {
      return;
    }
    io.to(roomId).emit("receiveMessage", message);
  });

  socket.on("messageRecevied", async (data) => {
    let user = users[String(socket.id)];
    await chatService.markMessageAsRead(data, user);
  });

  socket.on("disConnectToChat", async (data) => {
    try {
      if (data && data.connectionId) {
        let roomId = "chat_" + data.connectionId;
        socket.leave(roomId);
        io.to(roomId).emit("disConnectToChatOk", { status: 200, message: "Room successfully disconnected" });
      } else {
        console.log("chat Leave without proper data");
      }
    } catch (error) { console.log(error); }
  });

  // end of one to one chat

  socket.on("viewAndDownloadCount", async (data) => {
    const user = users[String(socket.id)];
    await common.postViewandDownloadCount(user, data.postId, data.isView);
    io.to(user).emit("viewAndDownloadCount", { status: 200, message: "Counted successfully" });
  });

  socket.on("seenByMessage", async (data) => {
    const user = users[String(socket.id)];
    await common.messageSeenBy(user, data);
    io.to(user).emit("seenByMessage", { status: 200, message: "seen by updated successfully" });
  });

  socket.on("notificationCount", async (data) => { // sub-admin case notification count sent    
    const user = users[String(socket.id)];
    const count = await chatService.findUnReadNotifications(user);
    io.to(user).emit("notificationCount", { count: count, status: 200, message: "count sent successfully" });
  });

});

process.on("notificationCount", async (payload) => {
  payload = JSON.parse(JSON.stringify(payload));
  let socket = usersSockets[payload.userId];
  if (socket) {
    socket.join(payload.userId);
  }
  const count = await chatService.findUnReadNotifications(payload.userId);
  io.to(payload.userId).emit("notificationCount", { count: count, status: 200, message: "count sent successfully" });


  io.to(payload.userId).emit("newQuery", { status: 200, message: "You have a new Query" });
  io.to(payload.adminId).emit("newQuery", { status: 200, message: "You have a new Query" });
});

process.on("DocUploaded", async (payload) => {
  payload = JSON.parse(JSON.stringify(payload));
  let socket = usersSockets[payload.userId];
  if (socket) {
    socket.join(payload.userId);
  }
  io.to(payload.userId).emit("DocUploaded", { code: 200, message: "Documents uploaded successfully" });
});

process.on("queryResolved", async (payload) => {
  payload = JSON.parse(JSON.stringify(payload));
  let socket = usersSockets[payload.userId];
  if (socket) {
    socket.join(payload.userId);
  }
  io.to(payload.userId).emit("queryResolved", { status: 200, message: "count sent successfully" });
});

exports.io = io;