const axios = require('axios');
const fileUpload = require('./fileUpload');
const fs = require('fs');


function formatPhone(phone) {
    let ph = phone + "";
    ph = ph.replace('+', '');
    if (ph && ph.startsWith("0") || ph.startsWith("27")) {
        if (ph.startsWith("0")) {
            ph = ph.slice(1, ph.length);
        } else if (ph.startsWith("27")) {
            ph = ph.slice(2, ph.length);
        }
    }
    return '0' + ph;
}

async function getProductList(req) {
    try {
        var basicAuth = 'Basic ' + Buffer.from(process.env.UKHESHE_AIRTIME_API_USERNAME + ':' + process.env.UKHESHE_AIRTIME_API_PASSWORD).toString('base64');
        let config = {
            method: 'get',
            url: `${process.env.UKHESHE_AIRTIME_BASE_URL}/v2/trade/mobile/airtime/products`,
            headers: {
                'apikey': process.env.UKHESHE_AIRTIME_API_KEY,
                'Authorization': basicAuth
            }
        };
        const response = await axios(config);
        return response.data;
    } catch (err) {
        return err.response.data;
    }
}

async function setSales(req) {
    try {
        var basicAuth = 'Basic ' + Buffer.from(process.env.UKHESHE_AIRTIME_API_USERNAME + ':' + process.env.UKHESHE_AIRTIME_API_PASSWORD).toString('base64');
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_AIRTIME_BASE_URL}/v2/trade/mobile/airtime/sales`,
            headers: {
                'apikey': process.env.UKHESHE_AIRTIME_API_KEY,
                'Authorization': basicAuth,
                'Content-Type': 'application/json'
            },
            data: req.body
        };
        const response = await axios(config);
        return response.data;
    } catch (err) {
        return err.response.data;
    }
}

async function getApis(req) {
    let url;
    if (!req.query.productid && !req.query.vendorid) {
        url = `${process.env.UKHESHE_AIRTIME_BASE_URL}${req.query.api}`;
    }
    else if (req.query.mobilenumber && req.query.vendorid) {

        url = `${process.env.UKHESHE_AIRTIME_BASE_URL}${req.query.api}&mobilenumber=${formatPhone(req.query.mobilenumber)}&vendorid=${req.query.vendorid}`;
    }
    else {
        url = `${process.env.UKHESHE_AIRTIME_BASE_URL}${req.query.api}&productid=${req.query.productid}&vendorid=${req.query.vendorid}`;
    }
    var basicAuth = 'Basic ' + Buffer.from(process.env.UKHESHE_AIRTIME_API_USERNAME + ':' + process.env.UKHESHE_AIRTIME_API_PASSWORD).toString('base64');
    let config = {
        method: 'get',
        url: url,
        headers: {
            'apikey': process.env.UKHESHE_AIRTIME_API_KEY,
            'Authorization': basicAuth,
            'Content-Type': 'application/json'
        }
        // data: req.body
    };
    const response = await axios(config);
    return response.data;
}

async function postApis(req) {
    try {
        var basicAuth = 'Basic ' + Buffer.from(process.env.UKHESHE_AIRTIME_API_USERNAME + ':' + process.env.UKHESHE_AIRTIME_API_PASSWORD).toString('base64');
        let config = {
            method: 'post',
            // url: `${process.env.UKHESHE_AIRTIME_BASE_URL}/v2/trade/mobile/airtime/sales`,
            url: `${process.env.UKHESHE_AIRTIME_BASE_URL}${req.query.api}`,
            headers: {
                'apikey': process.env.UKHESHE_AIRTIME_API_KEY,
                'Authorization': basicAuth,
                'Content-Type': 'application/json'
            },
            data: req.body
        };
        const response = await axios(config);
        return response.data;
    } catch (err) {
        return err.response.data;
    }
}

async function airtimeinfo(data, url) {
    try {
        var basicAuth = 'Basic ' + Buffer.from(process.env.UKHESHE_AIRTIME_API_USERNAME + ':' + process.env.UKHESHE_AIRTIME_API_PASSWORD).toString('base64');
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_AIRTIME_BASE_URL}/v2/trade/${url}`,
            headers: {
                'apikey': process.env.UKHESHE_AIRTIME_API_KEY,
                'Authorization': basicAuth,
                'Content-Type': 'application/json'
            },
            data: data

        };
        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (err) {
        return { data: err.response.data, isSuccess: false };
    }
}

module.exports = {
    getProductList,
    airtimeinfo,
    setSales,
    getApis,
    postApis
};