const cron = require("node-cron");
const Model = require("../../models");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const moment = require("moment");
const common = require("./common");



module.exports.cronRun = () =>
    //*/5 * * * * every i mint
    cron.schedule("* * * * *", async () => {
        // cron.schedule("*/5 * * * *", async () => {
        // console.log("Crons run");
        // let pipeline = [];
        // pipeline.push({ $match: { "isDeleted": false } },
        //     { $match: { isQueryResolved: false, isEscalated: false } },
        //     {
        //         $lookup: {
        //             from: "chatmessages",
        //             let: { connectionId: "$connectionId" },
        //             pipeline: [{
        //                 $match: {
        //                     $expr: {
        //                         $or: [{ $eq: ["$$connectionId", "$connectionId"] }]
        //                     }
        //                 }
        //             },
        //             { $sort: { createdAt: -1 } },
        //             { $limit: 1 }
        //             ],
        //             as: "lastMessage"
        //         }
        //     },
        //     {
        //         $group: {
        //             _id: {
        //                 connectionId: "$connectionId",
        //                 lastMessage: { $arrayElemAt: ["$lastMessage", -1] }
        //             }
        //         }
        //     },
        //     { $project: { _id: 0, lastMessage: "$_id.lastMessage", connectionId: "$_id.connectionId" } });

        // let chats = await Model.chatMessage.aggregate(pipeline);
        // // console.log('chatschatschats', JSON.stringify(chats));
        // if (chats.length > 0) {
        //     for (let i = 0; i < chats.length; i++) {
        //         const row = chats[i];
        //         let admin;
        //         if (row.lastMessage.accountType == 'TENET') {
        //             admin = await Model.user.findOne({ isDeleted: false, role: "ADMIN", userType: "TENET" }).select("+time");
        //         } else if (row.lastMessage.accountType == 'NSFAS') {
        //             admin = await Model.user.findOne({ isDeleted: false, role: "ADMIN", userType: "NSFAS" }).select("+time");
        //         }
        //         if (admin && Number(admin.time) > 0) {
        //             let currTime = moment().utcOffset(0, true).valueOf();
        //             console.log('currTime ', moment().utcOffset(0, true));

        //              let messageTime = moment(row.lastMessage.createdAt).add(Number(admin.time), 'm').utcOffset(0, true);
        //             console.log('messageTime ', messageTime);

        //             console.log('condition ', messageTime.valueOf() < currTime);

        //             if (messageTime.valueOf() < currTime) {
        //                 // query Escalated zone
        //                 let detail = {
        //                     connectionId: row.lastMessage.connectionId,
        //                     accountType: row.lastMessage.accountType
        //                 };
        //                 await common.escalate(detail);
        //             }
        //         }

        //     }
        // }

    },
        { scheduled: true }
    );
