const Model = require("../../models");
const config = require('config');
const mongoose = require("mongoose");
const moment = require("moment");
const ukhesheService = require('./ukhesheService');
const ObjectId = mongoose.Types.ObjectId;
var aws = require('aws-sdk');
const { execSync } = require('child_process');
const axios = require('axios');
const logger = require('../services/logger');

let timer = moment().unix();

axios.interceptors.request.use((config) => {
    logger.info(`Ukheshe request - ${config.url.replace(process.env.UKHESHE_BASE_URL, '')}`, config);
    timer = moment().unix();
    return config;
});

axios.interceptors.response.use((response) => {
    const now = moment().unix();

    const data = {
        duration: now - timer,
        status: response.status,
        statusText: response.statusText,
        data: response.data,
        headers: response.headers,
        logMessage: "RESPONSE RECEIVED"
    };

    logger.info(`Ukheshe response - ${response.config.url.replace(process.env.UKHESHE_BASE_URL, '')}`, data);
    return response;
});

if (process.env.NODE_ENV == 'dev') {
    aws.config.update({
        secretAccessKey: process.env.BUCKET_KEY,
        accessKeyId: process.env.BUCKET_ID
    });
}
var s3 = new aws.S3();

async function getWallets(req, res) {
    let accessToken = req.headers['ukheshetoken'];

    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/wallets`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    // return response.data;

    let lockedWalletTypeId;
    if (process.env.NODE_ENV == 'dev' || process.env.NODE_ENV == 'qa') {
        lockedWalletTypeId = 1487;
    } else {
        lockedWalletTypeId = 114;
    }

    const lockedWallet = response.data.find(item => item.walletTypeId == lockedWalletTypeId);

    let digitalWalletTypeId;
    if (process.env.NODE_ENV == 'dev' || process.env.NODE_ENV == 'qa') {
        digitalWalletTypeId = 1346;
    } else {
        digitalWalletTypeId = 102;
    }

    let user = req.user;

    if (lockedWallet !== undefined && user.isKYCCompleted == true) {

        let externalUniqueId = `${moment().valueOf()}-${user.saIdNo}`;

        let body = {
            externalUniqueId: externalUniqueId,
            status: 'ACTIVE',
            walletTypeId: digitalWalletTypeId
        };

        try {
            let createWallet = {
                method: 'POST',
                url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/wallets`,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': accessToken
                },
                data: JSON.stringify(body)
            };

            await axios(createWallet);
        } catch (error) {
            confirmIsOver18(user.saIdNo, req);
            confirmErrorIsSecureCitizen(error, req);
            //TODO: log to new relic
            throw Object.assign(
                new Error(`Getting Wallet Failed`),
                {
                    message: 'Getting Wallet Failed',
                    newRelicMessage: 'Getting Wallet Failed',
                    details: { req: req.body, description: error.response?.data[0], config: error.config }
                }
            );
        }
    }

    return response.data.filter(x => x.status == "ACTIVE" || x.status == "BARRED");
}

async function getWalletById(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let walletId = req.params.walletId;
    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${walletId}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

async function getWalletByPhoneNumber(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let phone = req.params.phone;

    if (phone.startsWith('0')) {
        phone = '27' + phone.slice(1);
    }

    if (!phone.startsWith('27')) {
        phone = '27' + phone;
    }
    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/?phone=${phone}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

async function getWalletCards(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let walletId = req.params.walletId;
    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${walletId}/cards`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

async function getQRCode(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let code = req.params.code;
    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/qr-codes/${code}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

async function getTransactions(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let walletId = req.params.walletId;
    let config = {
        method: 'GET',
        ///wallets/${this.walletData?.walletId}/transactions?offset=0&limit=100000
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${walletId}/transactions?offset=0&limit=100000`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

async function getWithdrawals(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let walletId = req.params.walletId;
    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${walletId}/withdrawals?offset=0&limit=100000`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

async function getWithdrawalFees(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let walletId = req.params.walletId;
    let amount = req.query.amount;
    let type = req.query.type;

    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${walletId}/withdrawals/fees?amount=${amount}&type=${type}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

function calculateAge(birthday) { // birthday is a date
    var ageDifMs = Date.now() - birthday;
    var ageDate = new Date(ageDifMs); // miliseconds from epoch
    return Math.abs(ageDate.getUTCFullYear() - 1970);
}

function confirmIsOver18(saIdNo, req) {
    // eslint-disable-next-line no-useless-catch
    try {
        let birthYear = saIdNo?.substring(0, 2);
        birthYear = (birthYear.substring(0,1) === '0' ? '20' : '19') + birthYear;
        let userBirthDate = new Date(birthYear, saIdNo?.substring(2, 4) - 1, saIdNo?.substring(4, 6));
        let age = calculateAge(userBirthDate);
        if (age < 18) {
            throw Object.assign(
                new Error(`User is under the age of 18. Please contact support to finalise registration.`),
                {
                    message: 'User is under the age of 18. Please contact support to finalise registration.',
                    newRelicMessage: 'User under 18',
                    details: { req: req.body, saIdNo: req?.user?.saIdNo }
                }
            );
        }
    } catch (error) {
        throw error;
    }
}

function confirmErrorIsSecureCitizen(err, req) {
    if (err.response?.data[0]?.description?.includes('SA home affairs')) {
        throw Object.assign(
            new Error('There was an issue finalising your KYC documentation. Please contact support to finalise registration.'),
            {
                message: 'There was an issue finalising your KYC documentation. Please contact support to finalise registration.',
                newRelicMessage: 'Secure Citizen Failed',
                details: { req: req.body, description: err.response?.data[0], config: err.config }
            }
        );
    }
}

async function createWallet(req, res) {
    confirmIsOver18(req.user?.saIdNo, req);
    try {
        let accessToken = req.headers["ukheshetoken"];

        let config = {
            method: 'POST',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/wallets`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': accessToken
            },
            data: JSON.stringify(req.body)
        };
        const response = await axios(config);
        return response.data;
    } catch (error) {
        confirmErrorIsSecureCitizen(error, req);
        throw Object.assign(
            new Error(`Wallet Creation Failed`),
            {
                message: 'Wallet Creation Failed',
                newRelicMessage: 'Wallet createWallet Failed',
                details: { req: req.body, description: error.response?.data[0], config: error.config }
            }
        );
    }
}

async function topupWallet(req, res) {
    try {
        let accessToken = req.headers["ukheshetoken"];

        let walletId = req.params.walletId;
        let config = {
            method: 'POST',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${walletId}/topups`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': accessToken
            },
            data: JSON.stringify(req.body)
        };
        const response = await axios(config);
        return response.data;
    } catch (error) {
        throw Object.assign(
            new Error(`Failed to Topup Wallet`),
            {
                message: 'Failed to Topup Wallet',
                newRelicMessage: 'Wallet topupWallet Failed',
                details: { req: req.body, description: error.response?.data[0], config: error.config }
            }
        );
    }
}


async function createWalletQRCode(req, res) {
    try {
        let accessToken = req.headers["ukheshetoken"];

        let walletId = req.params.walletId;
        let config = {
            method: 'POST',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${walletId}/qr-codes`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': accessToken
            },
            data: JSON.stringify(req.body)
        };
        const response = await axios(config);
        return response.data;
    } catch (error) {
        throw Object.assign(
            new Error(`Failed to create a Wallet QR Code`),
            {
                message: 'Failed to create a wallet QR Code',
                newRelicMessage: 'Wallet createWalletQRCode Failed',
                details: { req: req.body, description: error.response?.data[0], config: error.config }
            }
        );
    }
}

async function walletWithdrawals(req, res) {
    req.body.deliverToPhone = null;
    let accessToken = req.headers["ukheshetoken"];

    let profile = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(profile);

    req.body.deliverToPhone = response.data.phone1 ?? null;

    let walletId = req.params.walletId;
    let config = {
        method: 'POST',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${walletId}/withdrawals`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        },
        data: JSON.stringify(req.body)
    };
    try {
        const response = await axios(config);

        if (response.status == 200) {
            //send notification to people
            let user = await Model.user.findOne({ saIdNo: req.user.saIdNo, isDeleted: false });
            if (user && user.deviceToken) {
                let type = response.data.type ? response.data.type.toUpperCase() : "";
                let notification = {
                    title: `${type} WITHDRAWAL PENDING`,
                    message: response.data.token ? `Token: ${response.data.token}` : "",
                    userId: user._id,
                    isSaved: true,
                    pushType: 2,
                    deviceToken: user.deviceToken,
                    deviceType: user.deviceType
                };
                process.emit("sendNotification", notification);
            }
        }
        return response.data;

    } catch (error) {
        let user = await Model.user.findOne({ saIdNo: req.user.saIdNo, isDeleted: false });

        if (user && user.deviceToken && error.response?.data[0]?.description != "JWT has expired") {
            let notification = {
                title: req.body?.description ? `${req.body.description} FAILED` : "Withdrawal FAILED",
                message: error.response?.data[0]?.description ?? `${req.body.description} FAILED`,
                userId: user._id,
                isSaved: true,
                pushType: 2,
                deviceToken: user.deviceToken,
                deviceType: user.deviceType
            };
            process.emit("sendNotification", notification);
        }
        // throw error?.response?.data[0]?.description;
        throw Object.assign(
            new Error(`Failed to Withdraw`),
            {
                message: error.response?.data[0]?.description ??  "Failed to Withdraw",
                newRelicMessage: 'Wallet walletWithdrawels Failed',
                details: { req: req.body, description: error.response?.data[0], config: error.config }
            }
        );
    }
}


async function walletTransfer(req, res) {
    try {
        let accessToken = req.headers["ukheshetoken"];

        let config = {
            method: 'POST',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/transfers`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': accessToken
            },
            data: JSON.stringify(req.body)
        };
        const response = await axios(config);
        if (response.status == 204) {
            //send notification to people
            let externalUniqueId = req.body.externalUniqueId;
            if (externalUniqueId.includes("-")) {
                externalUniqueId = externalUniqueId.split("-")[1];
            }
            let user = await Model.user.findOne({ _id: ObjectId(externalUniqueId), isDeleted: false }).lean();
            if (user && user.deviceToken) {
                let notification = {
                    title: "Wallet Transfer Successful",
                    message: `${req.body.description} of R${req.body.amount} successful`,
                    userId: user._id,
                    isSaved: true,
                    pushType: 2,
                    deviceToken: user.deviceToken,
                    deviceType: user.deviceType
                };
                process.emit("sendNotification", notification);
            }
        }
        return response.data;
    } catch (error) {
        throw Object.assign(
            new Error(`Failed to Transfer`),
            {
                message: 'Failed to Transfer',
                newRelicMessage: 'Wallet walletTransfer Failed',
                details: { req: req.body, description: error.response?.data[0], config: error.config }
            }
        );
    }
}


async function updateWallet(req, res) {
    try {
        let accessToken = req.headers["ukheshetoken"];

        let walletId = req.params.walletId;
        let config = {
            method: 'PUT',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${walletId}`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': accessToken
            },
            data: JSON.stringify(req.body)
        };
        const response = await axios(config);
        return response.data;
    } catch (error) {
        throw Object.assign(
            new Error(`Failed to update Wallet`),
            {
                message: 'Failed to update',
                newRelicMessage: 'Wallet updateWallet Failed',
                details: { req: req.body, description: error.response?.data[0], config: error.config }
            }
        );
    }
}

async function getDigitalWallets(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/wallets`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);

    let wallettypeid;
    if (process.env.NODE_ENV == 'dev' || process.env.NODE_ENV == 'qa') {
        wallettypeid = 1346;
    } else {
        wallettypeid = 102;
    }

    return response.data.filter(x => x.status == "ACTIVE" && x.walletTypeId == wallettypeid);
}


module.exports = {
    //GET
    getWallets,
    getWalletById,
    getWalletByPhoneNumber,
    getWalletCards,
    getQRCode,
    getTransactions,
    getWithdrawals,
    getWithdrawalFees,
    getDigitalWallets,

    //POST
    createWallet,
    topupWallet,
    createWalletQRCode,
    walletWithdrawals,
    walletTransfer,

    //PUT
    updateWallet
};