const Model = require("../../models");
const responseCode = require("../../utility/responseCode");
const Otp = require("./otp");
const config = require('config');
const utility = require("../../utility/Utility");
const mongoose = require("mongoose");
const airtime = require("./airTime");
const common = require("./common");
const moment = require("moment");
const constant = require("../../utility/constant");
const ukhesheService = require('./ukhesheService');
var pdf = require('html-pdf-node');
var path = require("path");
// const notification = require('../../utility/pushNotifications');
const ObjectId = mongoose.Types.ObjectId;
const fileUpload = require("./fileUpload");
const request = require("request");
const fs = require('fs');
const fs1 = require('fs-extra');
var aws = require('aws-sdk');
const { execSync } = require('child_process');
const axios = require('axios');

if (process.env.NODE_ENV == 'dev') {
    aws.config.update({
        secretAccessKey: process.env.BUCKET_KEY,
        accessKeyId: process.env.BUCKET_ID
    });
}
var s3 = new aws.S3();

async function getCard(req,res) {
    let accessToken = req.headers["ukheshetoken"];

    let cardid = req.params.cardId;
    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/cards/${cardid}?masked=false`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}


async function createPinSet(req,res) {
    let accessToken = req.headers["ukheshetoken"];

    let cardid = req.params.cardId;
    let config = {
        method: 'POST',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/cards/${cardid}/pin-sets`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        },
        data: JSON.stringify(req.body)
    };
    const response = await axios(config);
    return response.data;
}

async function updateCard(req,res) {
    let accessToken = req.headers["ukheshetoken"];

    let cardid = req.params.cardId;
    let config = {
        method: 'PUT',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/cards/${cardid}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        },
        data: JSON.stringify(req.body)
    };
    const response = await axios(config);
    return response.data;
}

module.exports = {
    //GET
    getCard,

    //POST
    createPinSet,

    //PUT
    updateCard
};