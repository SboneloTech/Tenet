const Model = require("../../models");
const mongoose = require("mongoose");
const moment = require('moment-timezone');
const Agenda = require("agenda");

const ObjectId = mongoose.Types.ObjectId;

let agenda = new Agenda({ mongo: mongoose.connection });
agenda.start();

process.on("userBlock", async (payload) => {
    payload = JSON.parse(JSON.stringify(payload));
    let user = await Model.user.findOneAndUpdate({ _id: ObjectId(payload.userId) }, { $set: { isBlocked: true } }, { new: true }).lean();

    let unblockTime = new Date(moment().add(2, 'hours').toDate());
    await agenda.schedule(unblockTime, "userBlockAfter2Hours", payload);
});

agenda.define("userBlockAfter2Hours", async (payload) => {
    let userId = payload.attrs.data.userId;
    await Model.user.findOneAndUpdate({ _id: ObjectId(userId) }, { $set: { isBlocked: false } }).lean();

    if (payload.attrs.data.type == "VERIFY_PIN") {
        await Model.errorPin.updateMany({ userId: ObjectId(userId), isDeleted: false, type: 'PASSCODE' }, { isDeleted: true });
    } else if (payload.attrs.data.type == "VERIFY_OTP") {
        await Model.errorPin.updateMany({ userId: ObjectId(userId), isDeleted: false, type: 'OTP' }, { isDeleted: true });
    }
});