const response = require("../../utility/response");
const Utility = require("../../utility/Utility");
const responseCode = require("../../utility/responseCode");
const messages = require("../../messages/messages").MESSAGES;
const Model = require("../../models");
const mongoose = require("mongoose");

const userAuth = async (req, res, next) => {
    try {
        if (req && req.user && req.user.guestMode) {
            next();
        } else if (req && req.headers.authorization) {
            const accessTokenFull = req.headers.authorization;
            let accessToken = "";
            if (accessTokenFull.startsWith("Bearer")) {
                accessToken = accessTokenFull.substr("Bearer".length + 1);
            } else {
                const parts = accessTokenFull.split(" ");
                accessToken = parts[1];
            }
            const decodeData = await Utility.jwtVerify(accessToken);
            if (!decodeData) {
                throw Object.assign(new Error(process.lang.INVALID_TOKEN), {
                    newRelicMessage: process.lang.INVALID_TOKEN,
                    details: { description: 'INVALID JWT TOKEN', accessToken }
                });
            }
            let userData = await Model.user.findOne({ _id: decodeData._id, isDeleted: false }).select("+submitKey").lean().exec();
            if (userData) {
                const userBlockedData = await Model.user.findOne({ _id: decodeData._id, isDeleted: false, isBlocked: false }).select("+submitKey").lean().exec();
                if (!userData) {
                    throw Object.assign(new Error(process.lang.USER_BLOCKED), {
                        newRelicMessage: process.lang.USER_BLOCKED,
                        details: { description: 'MongoDB user is blocked', saIdNo: userBlockedData?.saIdNo }
                    });
                }
                req.user = userData;
                req.user.forResetPassword = decodeData.forResetPassword;
                req.user.userType = "USER";
                next();
            } else {
                return response.sendFailResponse(req, res, responseCode.UN_AUTHORIZED, process.lang.INVALID_TOKEN);
            }
        } else {
            return response.sendFailResponse(req, res, responseCode.UN_AUTHORIZED, process.lang.AUTH_TOKEN_MISSING);
        }
    } catch (error) {
        next(error);
    }
};

const adminAuth = async (req, res, next) => {
    try {
        if (req.admin && req.admin.guestMode) {
            next();
        } else if (req.headers.authorization) {
            let accessToken = req.headers.authorization;
            if (accessToken.startsWith("Bearer")) {
                accessToken = accessToken.substr("Bearer".length + 1);
            }
            const decodeData = await Utility.jwtVerify(accessToken);
            if (!decodeData) throw messages.INVALID_TOKEN;
            let qry = {
                _id: mongoose.Types.ObjectId(decodeData._id),
                isDeleted: false
            };
            if ((decodeData.role == 'ADMIN') || decodeData.role == 'SUBADMIN')
                qry.role = decodeData.role;
            else throw messages.INVALID_TOKEN;

            const adminData = await Model.admin.findOne(qry).lean().exec();
            if (adminData) {
                // // req.admin = adminData;
                // req.admin.forResetPassword = decodeData.forResetPassword;
                // req.admin.adminType = "ADMIN";
                // if (req.originalUrl.includes('/chatList') || req.originalUrl.includes('/chat/history')) {
                req.user = adminData;
                req.user.forResetPassword = decodeData.forResetPassword;
                // }
                next();
            } else {
                return response.sendFailResponse(req, res, responseCode.UN_AUTHORIZED, process.lang.INVALID_TOKEN);
            }
        } else {
            return response.sendFailResponse(req, res, responseCode.UN_AUTHORIZED, process.lang.AUTH_TOKEN_MISSING);
        }
    } catch (error) {
        next(error);
    }
};

module.exports = {
    userAuth,
    adminAuth
};
