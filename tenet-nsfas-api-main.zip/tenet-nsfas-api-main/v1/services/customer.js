const Model = require("../../models");
const responseCode = require("../../utility/responseCode");
const Otp = require("./otp");
const config = require('config');
const utility = require("../../utility/Utility");
const mongoose = require("mongoose");
const airtime = require("./airTime");
const common = require("./common");
const moment = require("moment");
const constant = require("../../utility/constant");
const ukhesheService = require('./ukhesheService');
var pdf = require('html-pdf-node');
var path = require("path");
// const notification = require('../../utility/pushNotifications');
const ObjectId = mongoose.Types.ObjectId;
const fileUpload = require("./fileUpload");
const request = require("request");
const fs = require('fs');
const fs1 = require('fs-extra');
var aws = require('aws-sdk');
const { execSync } = require('child_process');
const axios = require('axios');
const PDFDocument = require('pdfkit-table');
const constants = require('../../constants/constants').CONSTANTS;

if (process.env.NODE_ENV == 'dev') {
    aws.config.update({
        secretAccessKey: process.env.BUCKET_KEY,
        accessKeyId: process.env.BUCKET_ID
    });
}
var s3 = new aws.S3();

async function getCardsOnFile(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/cards-on-file`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

async function getCards(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/cards`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

async function getAddresses(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/addresses`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}


async function createCardOnFile(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let config = {
        method: 'POST',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/cards-on-file`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        },
        data: JSON.stringify(req.body)
    };
    const response = await axios(config);
    return response.data;
}

async function createPayment(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let config = {
        method: 'POST',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/payments`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        },
        data: JSON.stringify(req.body)
    };
    const response = await axios(config);
    return response.data;
}


async function updatePayment(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let paymentId = req.body.paymentId;
    let config = {
        method: 'PUT',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/payments/${paymentId}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        },
        data: JSON.stringify(req.body)
    };
    const response = await axios(config);
    return response.data;
}


async function deleteCardOnFile(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let cardId = req.params.cardId;
    let config = {
        method: 'DELETE',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/cards-on-file/${cardId}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

async function generatePDFContent(data, userData, address) {
    return new Promise((resolve, reject) => {
        const doc = new PDFDocument({ margin: 30, size: 'A4' });

        doc.text(`${userData.firstName} ${userData.lastName}`);
        if (address !== null && address !== undefined) {
            doc.text(`${address.line1}, ${address.line2}`);
            doc.text(address.city);
            doc.text(address.country);
            doc.text(address.code);
        }
        doc.moveDown();
        const logoPath = './images/tenetech_logo.jpeg';
        const rightAlignX = doc.page.width - 60 - 100;
        doc.image(logoPath, rightAlignX, 20, { height: 80 });
        doc.moveDown();

        const table = {
            title: constants.STATEMENT_TITLE,
            subtitle: constants.STATEMENT_SUBTITLE,
            headers: [
                {
                    label: constants.DATE,
                    property: 'date',
                    renderer: (value) => {
                        const date = new Date(value);
                        const options = {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                        };
                        return date.toLocaleString('en-US', options);
                    }
                },
                {
                    label: constants.DESCRIPTION,
                    property: 'description',
                    renderer: null
                },
                {
                    label: constants.AMOUNT,
                    property: 'amount',
                    renderer: (value, indexColumn, indexRow) => {
                        return `${data[indexRow].currency} ${Number(value).toFixed(2)}`;
                    }
                },
                {
                    label: constants.BALANCE,
                    property: 'balance',
                    renderer: (value, indexColumn, indexRow) => {
                        return `${data[indexRow].currency} ${Number(value).toFixed(2)}`;
                    }
                }
            ],
            datas: data
        };

        doc.table(table, { /* options */ });
        doc.text(`${constants.CLOSING_BALANCE}: ${data[0].currency} ${Number(data[data.length - 1].balance).toFixed(2)}`, { align: 'right' });

        const chunks = [];
        doc.on('data', (chunk) => {
            chunks.push(chunk);
        });

        doc.on('end', () => {
            const pdfBuffer = Buffer.concat(chunks);
            resolve(pdfBuffer);
        });

        doc.end();
    });
}

async function statement(req, res) {
    let accessToken = req.headers["ukheshetoken"];

    let wallets = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/wallets`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };

    const walletsResponse = await axios(wallets);
    let wallettypeid;

    if (process.env.NODE_ENV == 'dev' || process.env.NODE_ENV == 'qa') {
        wallettypeid = 1346;
    } else {
        wallettypeid = 102;
    }

    const wallet = walletsResponse.data.find(item => item.walletTypeId == wallettypeid);

    let user = await Model.user.findOne({ _id: req.user._id, isDeleted: false });
    let date = req.params.month.split('-');

    let month = parseInt(date[0], 10);
    let year = parseInt(date[1], 10);

    if (month < 1 || month > 12) {
        throw new Error(process.lang.INVALID_MONTH);
    }

    const startDate = new Date(year, month - 2, 26).toISOString().slice(0, 10);
    const endDate = new Date(year, month - 1, 26).toISOString().slice(0, 10);
    let walletId = wallet.walletId;

    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${walletId}/transactions?dateFromIncl=${startDate}&dateToExcl=${endDate}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };

    const transactions = await axios(config);
    const content = transactions.data;

    if (transactions.data.length < 1) {
        throw process.lang.EMPTY_STATEMENT;
    }

    let addresses = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}/addresses`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };

    const addressesResponse = await axios(addresses);

    let address = addressesResponse.data[0];
    
    const transactionsData = content.reverse();

    const pdfBuffer = await generatePDFContent(transactionsData, user, address);

    // Set response headers for PDF
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="example.pdf"');

    // Send the PDF to the response
    res.send(pdfBuffer);
}

module.exports = {
    //GET
    getCardsOnFile,
    getAddresses,
    getCards,
    statement,

    //POST
    createCardOnFile,
    createPayment,

    //PUT
    updatePayment,

    //DELETE
    deleteCardOnFile
};