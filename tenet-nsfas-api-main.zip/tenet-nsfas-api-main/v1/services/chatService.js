const Model = require("../../models");
const mongoose = require("mongoose");
const common = require("./common");


async function sendMessage(data, user) {

    // let lastMessage = await Model.chatMessage.findOne({ connectionId: data.connectionId, isQueryResolved: false, isDeleted: false });
    let lastMessage = await Model.chatMessage.findOne({ connectionId: data.connectionId, isDeleted: false });
    if (lastMessage) {
        data.queryType = lastMessage.queryType;
        data.assign = lastMessage.assign;
        data.status = lastMessage.status;
        data.accountType = lastMessage.accountType;
    }

    let message = await Model.chatMessage.create(data);
    message = await Model.chatMessage.findById(message._id).
        populate("senderId", "firstName lastName fullName userName phone email image saIdNo countryCode role").
        populate("adminId", "firstName lastName fullName userName phone email image saIdNo countryCode role").
        populate("recieverId", "firstName lastName  fullName userName phone email image saIdNo countryCode role").lean();

    let sender = await getUserDetail(user);
    let name = await common.getUserName(sender);
    let receiver = await getUserDetail(data.recieverId);

    let title = `${name}`;
    let messages = `${message.text} `;
    switch (data.type) {
        case 'TEXT':
            messages = `${message.text} `;
            break;
        case 'IMAGE':
            messages = `shared a image `;
            break;
        case 'VIDEO':
            messages = `shared a video `;
            break;
        case 'AUDIO':
            messages = `shared a audio `;
            break;
        case 'LOCATION':
            messages = `shared a location `;
            break;
        default:
            // eslint-disable-next-line no-unused-expressions
            "not found";
    }
    return message;
}

async function markMessageAsRead(data, user) {
    let qry = { connectionId: mongoose.Types.ObjectId(data.connectionId) };

    if (user) {
        qry.$or = [{ senderId: mongoose.Types.ObjectId(user._id) },
        { recieverId: mongoose.Types.ObjectId(user._id) }];
    }

    await Model.chatMessage.updateMany(qry, { $set: { isReaded: true } });
}

async function findUnReadNotifications(user) {
    let count = 0;
    let subAdmin = await Model.user.findOne({ _id: mongoose.Types.ObjectId(user), isDeleted: false, isRead: true }).lean();
    if (subAdmin) {
        count = await Model.notification.countDocuments({ userId: subAdmin._id, isDeleted: false, isRead: false });
    }
    return count;

}

async function getUserDetail(user) {
    return await Model.user.findOne({ _id: mongoose.Types.ObjectId(user) }).lean();
}

module.exports = {
    sendMessage,
    markMessageAsRead,
    findUnReadNotifications,
    getUserDetail
};
