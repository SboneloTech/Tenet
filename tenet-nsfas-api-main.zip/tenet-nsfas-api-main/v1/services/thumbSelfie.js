const request = require('request');
const upload = require("./fileUpload");
const Model = require("../../models");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const constant = require("../../utility/constant");
const fs = require('fs');

async function convertS3LinkToFileName(link) {
    let part = link.split("/");
    return part[part.length - 1];
}
module.exports = {
    convertS3LinkToFileName
};
