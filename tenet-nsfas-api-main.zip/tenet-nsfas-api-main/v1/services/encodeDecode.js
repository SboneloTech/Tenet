const crypto = require('crypto');
const cryptoJS = require('crypto-js');
const algorithm = 'aes-256-cbc';
const iv = 'SQNOTTTDKQCFTDFJ';
const key = "MKOIJNQASDFVRGHNMKUCFTXDRESZOP";
const moment = require("moment");


const secKeyDecryptedWithSekForWEB = async (req, res, next) => {
    try {
        let payload = req.headers.hash;
        let keyWEB = cryptoJS.SHA256(key);
        let ivWEB = cryptoJS.enc.Base64.parse(iv);
        let decrypted = cryptoJS.AES.decrypt(payload, keyWEB, {
            iv: ivWEB,
            mode: cryptoJS.mode.CBC,
            padding: cryptoJS.pad.Pkcs7
        });
        decrypted = decrypted.toString(cryptoJS.enc.Utf8);

        const utcTime = moment(decrypted).utc();
        const now = moment.utc();


        if (moment(decrypted) == "Invalid date" || now.diff(utcTime, "seconds") >= 60) {
            return res.status(429).send({
                "statusCode": 429,
                "message": process.lang.RESTRICTED_ACCESS,
                "data": {
                    errorCode: moment(decrypted) == "Invalid date" ? 10004 : 10002,
                    errorMessage: moment(decrypted) == "Invalid date" ? process.lang.INVALID_DATE + '-web' : process.lang.INVALID_TIME + '-web',
                    difference: now.diff(utcTime, "milliseconds") + ' milliseconds',
                    now: now,
                    utcTime: utcTime
                },
                "status": 0,
                "isSessionExpired": true
            });
        }
        return;
    } catch (error) {
        return res.status(429).send({
            "statusCode": 429,
            "message": process.lang.RESTRICTED_ACCESS,
            "data": {
                // Invalid Date / Time is longer than
                errorCode: 10003,
                errorMessage: error
            },
            "status": 0,
            "isSessionExpired": true
        });
    }
};

async function decrypWithSek(req, res, next) {
    if (req.originalUrl == "/v1/health" || req.originalUrl == "/health") {
        return res.status(200).send({
            "statusCode": 200,
            "message": "Healthy Service",
            "data": {},
            "status": 200
        });
    }
    else if (req.originalUrl == '/v1/transactioncallback' || req.originalUrl == '/transactioncallback') {
        return res.status(200).send({
            "statusCode": 200,
            "message": "Callback url hit",
            "data": {},
            "status": 200
        });
    }
    /**
     * NOTE:
     * COMMENTING THE RESTRICTED ACCESS CHECKER AS MOMENT.JS USES DEVICES LOCAL TIME TO CALCULATE UTC     
     * TODO: GET ANOTHER METHOD TO CHECK TIME DIFFERENCES*     
    */
    next();

    // else if (req.headers.hash == "dev") {
    //     next();
    // } else {
    //     try {
    //         if (req.headers.devicetype && req.headers.devicetype == 'WEB') {
    //             await secKeyDecryptedWithSekForWEB(req, res, next);
    //         } else {
    //             if (!req.headers.hash || !req.headers.sek) {
    //                 return res.status(429).send({
    //                     "statusCode": 429,
    //                     "message": process.lang.RESTRICTED_ACCESS,
    //                     "data": {
    //                         // Invalid Hash or Sek 
    //                         errorCode: 10001,
    //                         errorMessage: process.lang.INVALID_HASH_SEK
    //                     },
    //                     "status": 0,
    //                     "isSessionExpired": true
    //                 });
    //             }
    //             let hash = req.headers.hash;
    //             let sek = req.headers.sek;
    //             let key = Buffer.from(sek, 'hex');
    //             hash = Buffer.from(hash, 'hex');
    //             let decipher = crypto.createDecipheriv(algorithm, Buffer.from(hash, 'base64'), iv);
    //             let decrypted = decipher.update(key);
    //             decrypted = Buffer.concat([decrypted, decipher.final()]);
    //             decrypted = (decrypted.toString());

    //             const utcTime = moment(decrypted).utc();
    //             const now = moment.utc();
    //             if (moment(decrypted) == "Invalid date" || now.diff(utcTime, "seconds") >= 60
    //             ) {

    //                 return res.status(429).send({
    //                     "statusCode": 429,
    //                     "message": process.lang.RESTRICTED_ACCESS,
    //                     "data": {
    //                         errorCode: moment(decrypted) == "Invalid date" ? 10004 : 10002,
    //                         errorMessage: moment(decrypted) == "Invalid date" ? process.lang.INVALID_DATE + '-app' : process.lang.INVALID_TIME + '-app',
    //                         difference: now.diff(utcTime, "milliseconds") + ' milliseconds',
    //                         now: now,
    //                         utcTime: utcTime
    //                     },
    //                     "status": 0,
    //                     "isSessionExpired": true
    //                 });
    //             }
    //         }
    //         next();
    //     } catch (error) {
    //         return res.status(429).send({
    //             "statusCode": 429,
    //             "message": process.lang.RESTRICTED_ACCESS,
    //             "data": {
    //                 // GENERAL ERROR
    //                 errorCode: 10003,
    //                 errorMessage: error
    //             },
    //             "status": 0,
    //             "isSessionExpired": true
    //         });
    //     }
    // }
}

function isValidUTCDate(dateString) {
    const date = moment.utc(dateString, true);

    if (date.isValid() && date.isUTC()) {
        return true;
    } else {
        return false;
    }
}
module.exports = {
    secKeyDecryptedWithSekForWEB: secKeyDecryptedWithSekForWEB,
    decrypWithSek: decrypWithSek,
    isValidUTCDate
};