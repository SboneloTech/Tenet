const Model = require("../../models");
const utility = require("../../utility/Utility");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const Otp = require("./otp");
const common = require("./common");
const moment = require("moment");
const responseCode = require("../../utility/responseCode");
// const emailService = require('./emailService')
const pushNotification = require('../../utility/pushNotifications');
const constant = require("../../utility/constant");
const { runUkhesheAlgo, createkhesheToken, generateUkhsheTokenMySide, createTenantSystemUkhesheToken } = require("./ukhesheService");
const { default: axios } = require("axios");
const crypto = require('crypto');


async function createAdmin(data) {
    let qry = {
        isDeleted: false
    };
    let or = [];

    qry.$or = or;
    if (or.length > 0) {
        let admin = await Model.admin.findOne(qry, {
            email: 1,
            phone: 1,
            name: 1
        });

        if (admin) {
            if (admin.name == data.name) {
                throw process.lang.DUPLICATE_NAME;
            }
            // if (admin.email == data.email.toLowerCase()) {
            //     throw process.lang.DUPLICATE_EMAIL;
            // }
            // if (admin.phone == data.phone) {
            //     throw process.lang.DUPLICATE_PHONE;
            // }
        }
    }
    if (!data.name) {
        throw responseCode.BAD_REQUEST;
    }

    const apiKey = crypto.randomBytes(32).toString('hex');
    const body = { name: data.name, apiKey };

    let admin = await Model.admin.create(body);


    return {
        _id: admin._id,
        name: admin.name,
        apiKey: admin.apiKey
    };
}

//*************************** OnBoarding****************************//

async function createAdminUser(data) {
    let qry = {
        isDeleted: false
    };
    let or = [];
    if (data.email) {
        or.push({
            email: data.email.toLowerCase()
        });
    }
    if (data.phone) {
        or.push({
            phone: data.phone
        });
    }

    qry.$or = or;
    if (or.length > 0) {
        let admin = await Model.admin.findOne(qry, {
            email: 1,
            phone: 1,
            name: 1
        });

        if (admin) {
            if (admin.name == data.name) {
                throw process.lang.DUPLICATE_PHONE;
            }
            if (admin.email == data.email.toLowerCase()) {
                throw process.lang.DUPLICATE_EMAIL;
            }
            if (admin.phone == data.phone) {
                throw process.lang.DUPLICATE_PHONE;
            }
        }
    }

    data.password = await utility.hashPasswordUsingBcrypt(data.password);

    let admin = await Model.admin.create(data);

    if (!admin) {
        throw responseCode.BAD_REQUEST;
    }
    return {
        email: admin.email,
        phone: admin.phone,
        _id: admin._id
    };
}
const login = async (data) => {
    let setObj = {
        deviceType: data.deviceType,
        deviceToken: data.deviceToken
    };
    let planPassword = data.password;
    delete data.deviceType;
    delete data.deviceToken;
    delete data.password;
    let qry = {};

    if (utility.isEmail(data.key)) {
        qry.email = data.key;
    } else {
        qry.phone = data.key;
    }
    let admin = await Model.admin.findOne(qry).select("+password");

    if (!admin) {
        throw process.lang.INVALID_CREDENTIALS;
    }
    let match = await utility.comparePasswordUsingBcrypt(planPassword, admin.password);
    if (!match) {
        throw process.lang.INVALID_CREDENTIALS;
    }
    admin = await Model.admin.findOneAndUpdate({ _id: mongoose.Types.ObjectId(admin._id) }, setObj).lean();
    admin = await Model.admin.findOne({ _id: mongoose.Types.ObjectId(admin._id) }).
        select("fullName userName phone email image saIdNo countryCode role").
        populate("adminId", "fullName userName phone email image saIdNo countryCode role").lean();

    admin.token = await utility.jwtSign({ _id: admin._id, role: admin.role });
    admin.type = "Bearer";
    admin.expire = await utility.getJwtExpireTime();
    admin.refreshToken = await utility.jwtRefreshSign({ _id: admin._id });

    return admin;
};

async function resetPassword(data) {
    if ((data.key && utility.isEmail(data.key)) || data.email) {
        let email = data.key || data.email;
        let user = await Model.user.findOne({ email: email.toLowerCase() });
        if (!user) {
            throw process.lang.INVALID_EMAIL;
        }
        let otp = await Otp.generateEmailVerification(user.email, null, user ? user.firstName : "");
        if (!otp) {
            throw process.lang.REQUIRED_FILED_IS_MISSING;
        }
        return {
            verificationType: 1
        };
    } else {
        throw process.lang.REQUIRED_FILED_IS_MISSING;
    }
}
async function verifyOtp(data) {
    if (data.key && utility.isEmail(data.key)) {
        data.email = data.key;
        return await verifyEmail(data, null, true);
    } else {
        throw process.lang.INVALID_CREDENTIALS;
    }
}
async function verifyEmail(data, user, removeOtp = true) {
    let otp = await Otp.verifyEmailCode(data.email, data.code, removeOtp, null);
    if (!otp) {
        throw process.lang.OTP_INVALID;
    }
    let admin = await Model.user.findOne({ email: data.email.toLowerCase() }).lean();

    admin.token = await utility.jwtSign({ _id: admin._id, role: "ADMIN" });
    admin.type = "Bearer";
    admin.expire = await utility.getJwtExpireTime();
    admin.refreshToken = await utility.jwtRefreshSign({ _id: admin._id });
    return admin;
}
async function changePassword(data, admin) {
    if (!admin.forResetPassword) {
        let findadmin = await Model.user.findOne(
            { _id: admin._id },
            {
                password: 1
            }
        );
        if (!findadmin) {
            throw process.lang.INVALID_CREDENTAILS;
        } else {
            let match = await utility.comparePasswordUsingBcrypt(data.oldPassword, findadmin.password);
            if (!match) {
                throw process.lang.OLD_PASS_NOT_MATCH;
            }
        }
    }
    await Model.user.findByIdAndUpdate(admin._id, {
        $set: {
            password: await utility.hashPasswordUsingBcrypt(data.password)
        }
    });
    return true;
}
async function updateProfile(req) {
    let data = req.body;
    let qry = {
        _id: {
            $ne: req.user._id
        },
        isDeleted: false
    };

    let or = [];
    if (data.email) {
        or.push({
            email: data.email.toLowerCase()
        });
    }
    if (data.phone) {
        or.push({
            phone: data.phone
        });
    }

    qry.$or = or;
    if (or.length > 0) {
        let duplicateUser = await Model.user.findOne(qry, {
            email: 1,
            phone: 1
        });

        if (duplicateUser) {
            if (duplicateUser.email == data.email.toLowerCase()) {
                throw process.lang.DUPLICATE_EMAIL;
            }
            if (duplicateUser.phone == data.phone) {
                throw process.lang.DUPLICATE_PHONE;
            }
        }
    }
    data.isProfileComplete = true;
    let updatedUser = await Model.user.findOneAndUpdate({ _id: mongoose.Types.ObjectId(req.user._id) }, data, { new: true }).lean();
    return updatedUser;
}

async function getProfile(data) {
    const profile = await Model.admin.findById(mongoose.Types.ObjectId(data._id)).select("+time").lean();
    return profile;
}

//***************************** SUBADMIN ***********************************//

async function addSubAdmin(data) {
    if (data.user && data.user.role == 'SUBADMIN') {
        throw process.lang.INVALID_REQUEST;
    }
    let subadmin = await Model.user.findOne({ email: data.body.email, isDeleted: false });
    if (subadmin) throw process.lang.DUPLICATE_EMAIL;

    data.body.role = "SUBADMIN";
    if (data.body.password) {
        data.body.password = await utility.hashPasswordUsingBcrypt(data.body.password);
    }
    let accountType = await common.findAccountType(data);
    let admin = await common.getAdminAccount(accountType);
    data.body.adminId = admin._id;
    data.body.userType = accountType;
    await Model.user.create(data.body);
    return { added: true };
}
async function getSubAdmin(data) {
    if (data.user && data.user.role == 'SUBADMIN') {
        throw process.lang.INVALID_REQUEST;
    }
    let page = data.query.page;
    let size = data.query.size;
    let skip = parseInt(page - 1) || 0;
    let limit = parseInt(size) || 10;
    skip = skip * limit;
    let accountType = await common.findAccountType(data);
    if (!accountType) {
        throw process.lang.TYPE_MANDATORY;
    }
    let admin = await common.getAdminAccount(accountType);

    let qry = { isDeleted: false, role: 'SUBADMIN', adminId: admin._id };

    if (data.query.searchTerm) {
        qry.$or = [
            { name: { $regex: data.query.search, $options: "i" } },
            { email: { $regex: data.query.search, $options: "i" } },
            { phone: { $regex: data.query.search, $options: "i" } }
        ];
    }
    let detail = {};
    if (data.params.id) {
        return await Model.user.findOne({ _id: ObjectId(data.params.id), ...qry }).
            select("fullName userName phone email image saIdNo countryCode role firstName lastName");
    } else {
        let count = await Model.user.count({ ...qry });
        detail.subAdmin = await Model.user.find({ ...qry }).
            select("fullName userName phone email image saIdNo countryCode role firstName lastName").skip(skip).limit(limit);
        detail.totalCount = count;
    }
    return detail;
}

async function updateSubAdmin(data) {
    if (data.user && data.user.role == 'SUBADMIN') {
        throw process.lang.INVALID_REQUEST;
    }
    let accountType = await common.findAccountType(data);
    if (!accountType) {
        throw process.lang.TYPE_MANDATORY;
    }
    let admin = await Model.user.findOne({ _id: data.params.id, isDeleted: false, userType: accountType });
    if (!admin) throw process.lang.SUBADMIN_NOT_FOUND;

    let subadmin = await Model.user.findOne({ _id: { $ne: data.params.id }, email: data.body.email, isDeleted: false, userType: accountType });
    if (subadmin) throw process.lang.DUPLICATE_EMAIL;

    if (data.body.password) {
        data.body.password = await utility.hashPasswordUsingBcrypt(data.body.password);
    }
    await Model.user.findByIdAndUpdate({ _id: data.params.id }, data.body, { new: true });
    return { isUpdate: true };
}

async function deleteSubAdmin(data) {
    if (data.user && data.user.role == 'SUBADMIN') {
        throw process.lang.INVALID_REQUEST;
    }
    let accountType = await common.findAccountType(data);
    if (!accountType) {
        throw process.lang.TYPE_MANDATORY;
    }
    let admin = await Model.user.findOne({ _id: data.params.id, isDeleted: false, userType: accountType }).lean();
    if (!admin) throw process.lang.SUBADMIN_NOT_FOUND;

    await Model.user.findByIdAndUpdate({ _id: data.params.id, isDeleted: false, userType: accountType }, { isDeleted: true }, { new: true });
    return {};
}

//************************************** CMS **********************************//

async function addCms(data) {
    return await Model.cms.create(data.body);
}
async function updateCms(data) {
    let cms = await Model.cms.findOne({ _id: data.params.id, isDeleted: false });
    if (!cms) throw process.lang.CMS_NOT_FOUND;
    cms = await Model.cms.findOneAndUpdate({ _id: data.params.id }, data.body, { new: true });
    return cms;
}
async function getCms() {
    return await Model.cms.findOne({ isDeleted: false });
}

//************************************** DashBoard AND USER MANAGEMENT ************************************//
async function getDashboard(data) {
    return {};
}
async function getAllUsers(data) {
    let page = data.query['page'] ?? 1;
    let pageSize = Math.min(data.query['pageSize'], 100) ?? 100;
    let users = await Model.user.find().skip((page - 1) * pageSize).limit(pageSize);
    return users.map(data => {
        return {
            _id: data._id,
            title: data.title,
            gender: data.gender,
            email: data.email,
            maritalStatus: data.maritalStatus,
            firstName: data.firstName,
            lastName: data.lastName,
            phone: data.phone,
            dateOfBirth: data.dateOfBirth,
            saIdNo: data.saIdNo,
            isProfileComplete: data.isProfileComplete,
            deviceType: data.deviceType,
            deviceId: data.deviceId,
            isKYCCompleted: data.isKYCCompleted,
            selfieIsASelfie: data.selfieIsASelfie,
            selfieIsLegitimate: data.selfieIsLegitimate,
            selfieMatchesIdentity: data.selfieMatchesIdentity,
            firstNameMatchesIdentity: data.firstNameMatchesIdentity,
            lastNameMatchesIdentity: data.lastNameMatchesIdentity,
            identityNumberMatchesIdentity: data.identityNumberMatchesIdentity,
            idChecksPassed: data.idChecksPassed,
            selfieChecksPassed: data.selfieChecksPassed,
            updatedAt: data.updatedAt,
            isDeleted: data.isDeleted
        };
    });
}

async function searchUsers(data) {
    let page = data.query['page'] ?? 1;
    let pageSize = Math.min(data.query['pageSize'], 100) ?? 100;
    let regex = new RegExp(data.query['searchTerm'], "gi");
    let users = await Model.user.find(
        {
            $or: [
                { firstName: { $regex: regex } },
                { saIdNo: { $regex: regex } },
                { lastName: { $regex: regex } },
                { phone: { $regex: regex } },
                { email: { $regex: regex } }
            ]
        }
    ).skip((page - 1) * pageSize).limit(pageSize);
    return users.map(data => {
        return {
            _id: data._id,
            title: data.title,
            gender: data.gender,
            email: data.email,
            maritalStatus: data.maritalStatus,
            firstName: data.firstName,
            lastName: data.lastName,
            phone: data.phone,
            dateOfBirth: data.dateOfBirth,
            saIdNo: data.saIdNo,
            isProfileComplete: data.isProfileComplete,
            deviceType: data.deviceType,
            deviceId: data.deviceId,
            isKYCCompleted: data.isKYCCompleted,
            selfieIsASelfie: data.selfieIsASelfie,
            selfieIsLegitimate: data.selfieIsLegitimate,
            selfieMatchesIdentity: data.selfieMatchesIdentity,
            firstNameMatchesIdentity: data.firstNameMatchesIdentity,
            lastNameMatchesIdentity: data.lastNameMatchesIdentity,
            identityNumberMatchesIdentity: data.identityNumberMatchesIdentity,
            idChecksPassed: data.idChecksPassed,
            selfieChecksPassed: data.selfieChecksPassed,
            updatedAt: data.updatedAt,
            isDeleted: data.isDeleted
        };
    });
}

async function getUserDocsByUserId(data) {
    let userDocs = await Model.userDocument.find({ userId: mongoose.Types.ObjectId(data.params.id), isDeleted: false });
    return userDocs;
}

async function deleteUserDocById(data) {
    await Model.userDocument.findOneAndUpdate({ _id: mongoose.Types.ObjectId(data.params.id) }, { isDeleted: true });
}

async function getUserById(data) {
    let user = await Model.user.find({ _id: data.params.id });
    return user.map(data => {
        return {
            _id: data._id,
            title: data.title,
            gender: data.gender,
            email: data.email,
            maritalStatus: data.maritalStatus,
            firstName: data.firstName,
            lastName: data.lastName,
            phone: data.phone,
            identityPhone: data.identityPhone,
            countryCode: data.countryCode,
            dateOfBirth: data.dateOfBirth,
            saIdNo: data.saIdNo,
            isProfileComplete: data.isProfileComplete,
            deviceType: data.deviceType,
            deviceId: data.deviceId,
            isKYCCompleted: data.isKYCCompleted,
            selfieIsASelfie: data.selfieIsASelfie,
            selfieIsLegitimate: data.selfieIsLegitimate,
            selfieMatchesIdentity: data.selfieMatchesIdentity,
            firstNameMatchesIdentity: data.firstNameMatchesIdentity,
            lastNameMatchesIdentity: data.lastNameMatchesIdentity,
            identityNumberMatchesIdentity: data.identityNumberMatchesIdentity,
            idChecksPassed: data.idChecksPassed,
            selfieChecksPassed: data.selfieChecksPassed,
            updatedAt: data.updatedAt,
            isDeleted: data.isDeleted
        };
    });
}

async function deleteUserById(data) {
    await Model.user.findOne({ _id: data.params.id }, async (err, result) => {
        if (err) throw process.lang.USER_NOT_FOUND;

        let swap = new (Model.archivedUsers)(result.toJSON());
        swap._id = mongoose.Types.ObjectId();
        swap.isNew = true;
        result.remove();
        swap.save();

    });

}

async function updateUserById(req, data) {
    // eslint-disable-next-line no-useless-catch
    try {
        let user = await Model.user.findOneAndUpdate({ _id: mongoose.Types.ObjectId(req.params.id) }, data);
    } catch (e) {
        throw e;
    }
}

async function ratifyUserById(req, data) {
    let resRunAlgo = await runUkhesheAlgo({ req: req, user: req.user, userToken: null }); // run ukheshe in ukeshe

    let kycStatus = await common.checkKYCStatus(req, req.user, resRunAlgo);
    let _user = await Model.user.find({ saIdNo: req.user.saIdNo, isDeleted: false });
    return _user.map(_data => {
        return {
            _id: _data._id,
            title: _data.title,
            gender: _data.gender,
            maritalStatus: _data.maritalStatus,
            firstName: _data.firstName,
            lastName: _data.lastName,
            phone: _data.phone,
            saIdNo: _data.saIdNo,
            isProfileComplete: _data.isProfileComplete,
            deviceType: _data.deviceType,
            isKYCCompleted: kycStatus.isKYCCompleted,
            selfieIsASelfie: kycStatus.selfieIsASelfie,
            selfieIsLegitimate: kycStatus.selfieIsLegitimate,
            selfieMatchesIdentity: kycStatus.selfieMatchesIdentity,
            firstNameMatchesIdentity: kycStatus.firstNameMatchesIdentity,
            lastNameMatchesIdentity: kycStatus.lastNameMatchesIdentity,
            identityNumberMatchesIdentity: kycStatus.identityNumberMatchesIdentity,
            idChecksPassed: data.idChecksPassed,
            selfieChecksPassed: data.selfieChecksPassed
        };
    });

}

//************************************** FAQ *************************************//

async function addFaq(req) {
    return await Model.faq.create(req.body);
}
async function getFaq(data) {
    let qry = { isDeleted: false };

    let page = data.query.page;
    let size = data.query.size;
    let skip = parseInt(page - 1) || 0;
    let limit = parseInt(size) || 10;
    skip = skip * limit;
    if (data.query.search) {
        qry.$or = [
            { question: { $regex: data.query.search, $options: "i" } },
            { answer: { $regex: data.query.search, $options: "i" } }
        ];
    }
    let faq;
    if (data.params.id) {
        faq = await Model.faq.findOne({ _id: data.params.id, ...qry });
        if (!faq) {
            throw process.lang.INVALID_FAQ;
        }
        return faq;
    }
    if (data.query.type == 'all') {
        return await Model.faq.find();

    }
    faq = await Model.faq.find({ ...qry }).skip(skip).limit(limit);
    let count = await Model.faq.find({ ...qry }).count();
    return { count: count, data: faq };
}
async function updateFaq(data) {
    let faq = await Model.faq.findOne({ _id: data.params.id, isDeleted: false });
    if (!faq) throw process.lang.INVALID_FAQ;

    return await Model.faq.findOneAndUpdate({ _id: data.params.id, isDeleted: false }, data.body, { new: true });
}
async function deleteFaq(data) {
    let faq = await Model.faq.findOne({ _id: data.params.id, isDeleted: false });
    if (!faq) throw process.lang.INVALID_FAQ;

    return await Model.faq.findOneAndUpdate({ _id: data.params.id, isDeleted: false }, { $set: { isDeleted: true } }, { new: true });
}

async function addNotification(req) {
    let deviceToken = [], deviceTokenIos = [];
    req.body.type = 'ADMIN';
    await Model.notification.create(req.body);
    let users = await Model.user.find({ isDeleted: false });
    users.map(async (e) => {
        if (e.deviceToken && e.deviceToken.length > 0 && e.deviceType === 'ANDROID') deviceToken.push(e.deviceToken);
        if (e.deviceToken && e.deviceToken.length > 0 && e.deviceType === 'IOS') deviceTokenIos.push(e.deviceToken);
    });
    if (deviceToken.length > 0) {
        await pushNotification.sendNotification(req.body, deviceToken);
    }
    if (deviceTokenIos.length > 0) {
        await pushNotification.sendNotificationToIos(req.body, deviceTokenIos);
    }
    return {};
}

async function getNotification(req) {
    let qry = {};
    let page = req.query.page;
    let size = req.query.limit;
    let skip = parseInt(page - 1) || 0;
    let limit = parseInt(size) || 10;
    skip = skip * limit;
    let pipeline = [];
    let check = {};
    if (req.query.isAdmin == 'false') {
        check.userId = req.user._id;
        await Model.notification.findOneAndUpdate({ userId: req.user._id, isDeleted: false }, { $set: { isRead: true } });
    }
    pipeline.push({ $match: { isDeleted: false, ...check } });
    if (req.query.search) {
        qry.$or = [
            { "title": { $regex: req.query.search, $options: "i" } },
            { "message": { $regex: req.query.search, $options: "i" } },
            { "notificationType": { $regex: req.query.search, $options: 'i' } }
        ];
        pipeline.push({ $match: qry });
    }

    pipeline.push({ $lookup: { from: "users", localField: "userId", foreignField: "_id", as: "users" } },
        { $unwind: { path: "$users", preserveNullAndEmptyArrays: true } },
        { $sort: { createdAt: -1 } },
        {
            $project: {
                notificationType: 1,
                createdAt: 1,
                title: 1,
                message: 1,
                type: 1,
                userType: 1,
                "users.saIdNo": 1,
                "user.userName": 1,
                "users.lastName": 1,
                "users.firstName": 1,
                "users.image": 1
            }
        });

    pipeline = await common.pagination(pipeline, skip, limit);
    let data = await Model.notification.aggregate(pipeline);
    return data;
}

async function getQuery(req) {
    let detail = {};

    let page = req.query.page;
    let size = req.query.limit;
    let sort = req.query.sortby || -1;

    let skip = parseInt(page - 1) || 0;
    let limit = parseInt(size) || 10;
    skip = skip * limit;
    let pipeline = [];
    if (req.query.isAdmin) {
        pipeline.push({ $match: { text: { $ne: null } } });
    }
    if (req.query.type == 'RESOLVED') {
        // pipeline.push({ $match: { isQueryResolved: true, isEscalated: false } });
        pipeline.push({ $match: { isQueryResolved: true } });
    } else if (req.query.type == 'UN_RESOLVED') {
        // pipeline.push({ $match: { isQueryResolved: false, isEscalated: false } });
        pipeline.push({ $match: { isQueryResolved: false } });
    } else if (req.query.type == 'UN_ASSIGN') {
        pipeline.push({ $match: { assign: 'PENDING' } });
    } else if (req.query.type == 'ESCALATED') {
        pipeline.push({ $match: { isEscalated: true } });
    }
    if (req.query.connectionId) {
        pipeline.push({ $match: { connectionId: req.query.connectionId } });
    }
    if (req.user && req.user.role == 'SUBADMIN') {
        pipeline.push({
            $match: {
                $or: [{ recieverId: ObjectId(req.user._id) }, { senderId: ObjectId(req.user._id) }]
            }
        });
    }
    let accountType = await common.findAccountType(req);
    if (!accountType) {
        throw process.lang.TYPE_MANDATORY;
    }
    pipeline.push({ $match: { accountType: accountType } });
    pipeline.push(
        // {
        // $match: {
        //     $or: [{ recieverId: mongoose.Types.ObjectId(req.user._id) }, { senderId: mongoose.Types.ObjectId(req.user._id) }]
        // }
        // },
        { $match: { "isDeleted": false } },
        {
            $lookup: {
                from: "chatmessages",
                let: { connectionId: "$connectionId" },
                pipeline: [{
                    $match: {
                        $expr: {
                            $or: [{ $eq: ["$$connectionId", "$connectionId"] }]
                        }
                    }
                },
                { $sort: { createdAt: -1 } },
                { $limit: 1 }
                ],
                as: "lastMessage"
            }
        },
        {
            $group: {
                _id: {
                    connectionId: "$connectionId",
                    lastMessage: { $arrayElemAt: ["$lastMessage", -1] }
                }
            }
        },
        { $project: { _id: 0, lastMessage: "$_id.lastMessage", connectionId: "$_id.connectionId" } },
        {
            $addFields: {
                user: {
                    $cond: {
                        if: {
                            $eq: ["$lastMessage.senderId", mongoose.Types.ObjectId(req.user._id)]
                        },
                        then: "$lastMessage.recieverId", else: "$lastMessage.senderId"
                    }
                }
            }
        },
        { $lookup: { from: "users", localField: "user", foreignField: "_id", as: "user" } },
        { $unwind: "$user" },
        { $lookup: { from: "users", localField: "lastMessage.senderId", foreignField: "_id", as: "sender" } },
        { $unwind: { path: "$sender", preserveNullAndEmptyArrays: true } },

        { $lookup: { from: "users", localField: "lastMessage.recieverId", foreignField: "_id", as: "reciever" } },
        { $unwind: { path: "$reciever", preserveNullAndEmptyArrays: true } },

        { $lookup: { from: "users", localField: "lastMessage.adminId", foreignField: "_id", as: "adminId" } },
        { $unwind: { path: "$adminId", preserveNullAndEmptyArrays: true } },

        { $match: { "sender.isDeleted": false } },
        { $match: { "reciever.isDeleted": false } }

    );

    pipeline.push(
        { "$sort": { "lastMessage.createdAt": -1 } },
        {
            $project: {
                _id: 0, lastMessage: "$lastMessage", connectionId: "$connectionId", status: "$status",
                fullName: "$user.fullName", image: "$user.image", userId: "$user._id", isBlocked: "$isBlocked", clear: "$clear",
                // users: {
                //     "firstName": "$user.firstName", "lastName": "$user.lastName", image: "$user.image", _id: "$user._id", countryCode: "$user.countryCode",
                //     phone: "$user.phone", userName: "$user.userName", saIdNo: "$user.saIdNo"
                // },
                // user: {
                //     "firstName": "$user.firstName", "lastName": "$user.lastName", image: "$user.image", _id: "$user._id", countryCode: "$user.countryCode",
                //     phone: "$user.phone", userName: "$user.userName", saIdNo: "$user.saIdNo"
                // }
                "users": {
                    "firstName": "$sender.firstName",
                    "lastName": "$sender.lastName",
                    "image": "$sender.image",
                    "_id": "$sender._id",
                    "countryCode": "$sender.countryCode",
                    "phone": "$sender.phone",
                    "userName": "$sender.userName",
                    "role": "$sender.role",
                    "saIdNo": "$sender.saIdNo"
                },
                "user": {
                    "firstName": "$reciever.firstName",
                    "lastName": "$reciever.lastName",
                    "image": "$reciever.image",
                    "_id": "$reciever._id",
                    "countryCode": "$reciever.countryCode",
                    "phone": "$reciever.phone",
                    "userName": "$reciever.userName",
                    "role": "$reciever.role",
                    "saIdNo": "$reciever.saIdNo"
                },
                "adminId": {
                    "firstName": "$adminId.firstName",
                    "lastName": "$adminId.lastName",
                    "image": "$adminId.image",
                    "_id": "$adminId._id",
                    "countryCode": "$adminId.countryCode",
                    "phone": "$adminId.phone",
                    "userName": "$adminId.userName",
                    "role": "$adminId.role",
                    "saIdNo": "$adminId.saIdNo"
                }
            }
        }
    );
    pipeline.push({ $sort: { createdAt: Number(sort) } });
    if (req.query.search) {
        pipeline.push({
            $match: {
                $or: [{ "user.firstName": { $regex: req.query.search, $options: "i" } },
                { "user.lastName": { $regex: req.query.search, $options: "i" } },
                { "user.fullName": { $regex: req.query.search, $options: "i" } },
                { "user.phone": { $regex: req.query.search, $options: "i" } }]
            }
        });
    }
    pipeline.push({
        $facet: {
            metadata: [{
                $group: {
                    _id: null,
                    total: { $sum: 1 }
                }
            }],
            chats: [{ $skip: skip }, { $limit: limit }]
        }
    }, {
        $project: {
            count: { $arrayElemAt: ['$metadata.total', 0] }, chats: 1
        }
    });
    let chats = await Model.chatMessage.aggregate(pipeline);
    detail.count = chats[0].count;
    detail.chats = chats[0].chats;
    return detail;
}

async function changeAgent(req) {
    let subAdmin = await Model.user.findOne({ _id: req.body.subAdminId, isDeleted: false, role: 'SUBADMIN' });
    if (!subAdmin) throw process.lang.SUBADMIN_NOT_FOUND;

    let connectionId = await Model.chatMessage.findOne({ connectionId: req.body.connectionId, isDeleted: false });
    if (!connectionId) throw process.lang.INVALID_CONNECTION_ID;

    let data = {
        senderId: mongoose.Types.ObjectId(subAdmin._id),
        recieverId: mongoose.Types.ObjectId(connectionId.recieverId),
        connectionId: connectionId.connectionId,
        clearedBy: [],
        text: `${subAdmin.fullName} is your new Agent.`,
        queryType: connectionId.queryType,
        assign: connectionId.assign,
        status: connectionId.status,
        accountType: connectionId.accountType
    };
    await Model.chatMessage.create(data);

    return { isSuccess: true };
}

async function escalate(req) {
    let accountType = await common.findAccountType(req);
    if (!accountType) {
        throw process.lang.TYPE_MANDATORY;
    }
    let admin = await Model.user.findOne({ isDeleted: false, role: 'ADMIN', userType: accountType });
    // if (!subAdmin) throw process.lang.SUBADMIN_NOT_FOUND;

    let connectionId = await Model.chatMessage.findOne({ connectionId: req.body.connectionId, isDeleted: false });
    if (!connectionId) throw process.lang.INVALID_CONNECTION_ID;

    await Model.chatMessage.updateMany({ connectionId: req.body.connectionId }, { $set: { isEscalated: true } });

    let data = {
        senderId: mongoose.Types.ObjectId(connectionId.senderId),
        recieverId: mongoose.Types.ObjectId(connectionId.recieverId),
        adminId: mongoose.Types.ObjectId(admin._id),
        connectionId: connectionId.connectionId,
        clearedBy: [],
        isEscalated: true,
        text: `Your query has been excalated to admin.`,
        queryType: connectionId.queryType,
        assign: connectionId.assign,
        status: connectionId.status,
        accountType: connectionId.accountType
    };
    await Model.chatMessage.create(data);

    return { isSuccess: true };
}

async function statusList(req) {
    return constant.STATUS_LIST;
}

async function statusChange(req) {
    if (!req.body.connectionId)
        throw process.lang.INVALID_CONNECTION_ID;

    let qry = { connectionId: req.body.connectionId };

    await Model.chatMessage.updateMany(qry, { $set: { status: req.body.status } });

    return { isSuccess: true };
}
module.exports = {
    statusChange,
    statusList,
    escalate,
    changeAgent,
    getQuery,
    addNotification,
    getNotification,
    addFaq,
    getFaq,
    updateFaq,
    deleteFaq,
    createAdminUser,
    createAdmin,
    login,
    resetPassword,
    verifyOtp,
    changePassword,
    updateProfile,
    getProfile,
    addSubAdmin,
    getSubAdmin,
    updateSubAdmin,
    deleteSubAdmin,
    addCms,
    updateCms,
    getCms,
    getDashboard,
    getAllUsers,
    getUserById,
    deleteUserDocById,
    deleteUserById,
    updateUserById,
    getUserDocsByUserId,
    searchUsers,
    ratifyUserById
};
