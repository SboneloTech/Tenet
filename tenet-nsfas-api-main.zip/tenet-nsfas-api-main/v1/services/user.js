const Model = require("../../models");
const responseCode = require("../../utility/responseCode");
const Otp = require("../services/otp");
const config = require('config');
const utility = require("../../utility/Utility");
const mongoose = require("mongoose");
const airtime = require("./airTime");
const common = require("./common");
const moment = require("moment");
const constant = require("../../utility/constant");
const ukhesheService = require('./ukhesheService');
var pdf = require('html-pdf-node');
var path = require("path");
const ObjectId = mongoose.Types.ObjectId;
const fileUpload = require("./fileUpload");
const request = require("request");
const fs = require('fs');
const fs1 = require('fs-extra');
var aws = require('aws-sdk');
const { execSync } = require('child_process');
const smsService = require("./SMSService");
const axios = require('axios');
const logger = require('../services/logger');

if (process.env.NODE_ENV == 'dev') {
    aws.config.update({
        secretAccessKey: process.env.BUCKET_KEY,
        accessKeyId: process.env.BUCKET_ID,
        region: process.env.BUCKET_REGION
    });
}
var s3 = new aws.S3();

function formatPhone(phone) {
    let ph = phone + "";
    ph = ph.replace('+', '');
    if (ph && ph.startsWith("0") || ph.startsWith("27")) {
        if (ph.startsWith("0")) {
            ph = ph.slice(1, ph.length);
        } else if (ph.startsWith("27")) {
            ph = ph.slice(2, ph.length);
        }
    }
    return '27' + ph;
}

function formatPhoneBL(phone) {
    let ph = phone + "";
    ph = ph.replace('+', '');
    if (ph && ph.startsWith("0") || ph.startsWith("27")) {
        if (ph.startsWith("0")) {
            ph = ph.slice(1, ph.length);
        } else if (ph.startsWith("27")) {
            ph = ph.slice(2, ph.length);
        }
    }
    return '0' + ph;
}

//********************************** OnBoarding *********************************//
async function createUser(data) {
    let user;
    //-Hal- You could probably replace 90% of this function by calling the existing function "checkDuplicateUser" - only if no duplicate is found, then call "Model.user.create(data)"
    if (utility.isEmail(data.key)) {
        data.email = data.key;
        user = await Model.user.findOne({
            email: data.email,
            //-Hal- Remove this "isProfileComplete: true" clause...
            isProfileComplete: true,
            isDeleted: false
        });
        if (!user) {
            //-Hal- Remove everything between line #72 and line #83:
            user = await Model.user.findOne({
                email: data.email,
                isDeleted: false
            });
            if (user) {
                await Model.user.deleteMany({
                    email: data.email,
                    isDeleted: false,
                    isProfileComplete: false
                });
            }
            user = await Model.user.create(data);
            await Otp.generateEmailVerification(data.email, data);
        } else {
            throw process.lang.DUPLICATE_EMAIL;
        }
    } else {
        data.phone = data.key;
        user = await Model.user.findOne({
            phone: data.phone,
            countryCode: data.countryCode,
            //-Hal- Remove this "isProfileComplete: true" clause...
            isProfileComplete: true,
            isDeleted: false
        });
        if (!user) {
            //-Hal- Remove everything between line #99 and line #112:
            user = await Model.user.findOne({
                phone: data.phone,
                countryCode: data.countryCode,
                isDeleted: false
            });
            if (user) {
                await Model.user.deleteMany({
                    phone: data.phone,
                    countryCode: data.countryCode,
                    isDeleted: false,
                    isProfileComplete: false
                });
            }
            user = await Model.user.create(data);
            await Otp.generatePhoneOtp(data.countryCode, data.phone, user);
        } else {
            throw process.lang.DUPLICATE_PHONE;
        }
    }
    if (!user) {
        throw responseCode.BAD_REQUEST;
    }
    return user;

}
async function adminDetailUpdate(req) {
    await Model.user.findByIdAndUpdate(req.user._id, { $set: { time: req.body.time } });
    return {};
}
async function setPassword(req) {
    let token = await ukhesheService.createkhesheToken(true);

    let identity;

    if (req.body.hasIdIdentity != true) {
        let existingIdentity = await ukhesheService.getIdentityOfUser({ ukhesheCustId: req.body.customerId });
        identity = existingIdentity.data[0].identity;
    } else {
        identity = 'BHA-' + req.body.saIdNo;
    }

    let body = {
        password: req.body.password,
        hash: req.body.hash // <-- OTP received from Ukheshe
    };

    let config = {
        method: 'POST',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/global/identities/${identity}/password-change`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token.headerValue
        },
        data: body
    };

    let response;
    try {
        response = await axios(config);
    } catch (error) {
        throw Object.assign(
            new Error('Error Setting Password'),
            {
                message: error.response?.data[0]?.code == 'USR006' ? process.lang.INVALID_OTP : 'Error Setting Password',
                newRelicMessage: 'set password failed: Ukheshe',
                details: {
                    description: error.response?.data[0]?.description,
                    ukTraceId: error.response?.data[0]?.traceId,
                    ukCode: error.response?.data[0]?.code
                }
            }
        );
    }


    if (response.status === 200 || response.status === 204) {
        try {
            await Model.user.findOneAndUpdate({ saIdNo: req.body.saIdNo, isDeleted: false }, {
                $set: {
                    password: await utility.hashPasswordUsingBcrypt(req.body.password),
                    submitKey: req.body.password
                }
            });
        } catch (error) {
            // Do nothing because the user has not been enrolled yet
        }
    }

    return response.data;
}

async function logout(req) {
    await Model.user.findOneAndUpdate({
        _id: ObjectId(req.user._id),
        isDeleted: false
    }, {
        $set: {
            deviceType: '',
            deviceToken: ''
        }
    }, {
        new: true
    });
    return {};
}
async function verifyOTP(req, data) {
    let user;
    let setObj = {};
    //-Hal- Is there any reason to store "user.isEmailVerify", "user.isPhoneVerify", or "user.jti"? If not, remove lines #228-229 becuase there is need to update and get the user model again.
    let key = data.key;

    if (key.substring(0, 2) == '27') {
        key = key.replace('27', '');
    }

    if (key.startsWith('0')) {
        key = key.slice(1);
    }

    let otp = await Otp.verifyPhoneOtp(data.countryCode, key, data.code, true, false);

    if (!otp.isSuccess) {
        // fix
        throw Object.assign(
            new Error(process.lang.INVALID_OTP),
            {
                message: process.lang.INVALID_OTP,
                newRelicMessage: 'verifyOTP Invalid OTP',
                details: {
                    description: process.lang.INVALID_OTP,
                    saIdNo: data.saIdNo,
                    phone: key,
                    deviceFingerprint: user?.deviceId ?? 'deviceFingerprint not found',
                    deviceType: user?.deviceType ?? 'deviceType not found'
                }
            }
        );
    }

    let createIdentity = {
        saIdNo: data.saIdNo,
        ukhesheCustId: data.customerId + "",
        password: data.password
    };

    let identity = await ukhesheService.createIdentityOfUser(createIdentity);

    if (identity.isSuccess == false) {
        let error = identity?.data[0]?.description ?? 'Registration Failed';
        throw Object.assign(
            new Error(error),
            {
                message: error,
                newRelicMessage: 'Registration Failed',
                details: {}
            }
        );
    }

    setObj.isPhoneVerify = true;

    let jti = utility.generateRandomString(20);
    setObj.jti = jti;
    user = await Model.user.findOneAndUpdate({ saIdNo: data.saIdNo, isDeleted: false}, setObj).lean();
    user = await Model.user.findOne({ saIdNo: data.saIdNo, isDeleted: false }).lean();
    user.token = await utility.jwtSign({
        _id: user._id,
        role: user.role,
        jti: jti
    });
    user.type = "Bearer";
    user.expire = await utility.getJwtExpireTime();
    user.refreshToken = await utility.jwtRefreshSign({ _id: user._id });

    return user;
}

async function checkDuplicateUser(data) {
    let qry = {
        isDeleted: false,
        role: data.role
    };

    let or = [];
    if (data.email) {
        or.push({
            email: data.email.toLowerCase()
        });
    }
    if (data.phone) {
        or.push({
            phone: data.phone
        });
    }
    if (data.userName) {
        or.push({
            userName: data.userName
        });
    }
    qry.$or = or;
    let user;
    if (or.length > 0) {
        user = await Model.user.findOne(qry, {
            email: 1,
            phone: 1,
            userName: 1
        });

        if (user) {
            if (user.email == data.email.toLowerCase()) {
                throw process.lang.DUPLICATE_EMAIL;
            }
            if (user.phone == data.phone) {
                throw process.lang.DUPLICATE_PHONE;
            }
        }
    }
    return user;
}
async function socialLogin(data) {
    let qry = {
        isDeleted: false,
        role: data.role
    };

    let user = await Model.user.findOne({
        socialId: data.socialId,
        socialType: data.socialType,
        isDeleted: false,
        role: data.role
    });

    if (!user) {
        if (utility.isEmail(data.email)) {
            qry.email = data.email.toLowerCase();
        } else {
            qry.phone = data.phone;
            qry.countryCode = data.countryCode;
        }

        user = await Model.user.findOne(qry);
        if (!user) {
            data.isSocialLogin = true;
            await checkDuplicateUser(data);

            if (utility.isEmail(data.email)) {
                data.isEmailVerify = true;
                data.verificationType = 1;
            }
            if (data.phone) {
                data.isPhoneVerify = true;
                data.verificationType = 0;
            }
            user = await Model.user.create(data);
        } else {
            await Model.user.findByIdAndUpdate(user._id, {
                $set: {
                    socialId: data.socialId,
                    socialType: data.socialType
                }
            });
        }
    }
    if (user) {
        user = await Model.user.findOne({
            _id: user._id
        });
    }
    user = await _doLogin(user, data);
    return user;
}


async function _doEnrolmentLogin(req, data) {
    let identity;
    if (data.hasIdIdentity != true) {

        let createIdentity = {
            saIdNo: data.saIdNo,
            ukhesheCustId: data.customerId,
            password: data.password
        };

        let existingIdentity = await ukhesheService.getIdentityOfUser({ ukhesheCustId: data.customerId });
        identity = existingIdentity.data[0].identity;

        await ukhesheService.createIdentityOfUser(createIdentity);
    } else {
        identity = 'BHA-' + data.saIdNo;
    }

    const verified = await smsService.verifySMSToPhone(data.otp, identity);

    if (verified.isSuccess) {
        let createToken = {
            phone: data.phone,
            submitKey: data.password,
            ukhesheCustId: data.customerId + "",
            otp: data.otp,
            deviceId: data.deviceId,
            saIdNo: data.saIdNo
        };

        let token = await ukhesheService.generateUkhsheTokenMySide(req, createToken);
        if (token.isSuccess == false) {
            let error = token.data[0]?.code == 'USR002' ? 'Invalid Credentials' : (token.data[0]?.description ?? 'Login failed');
            throw Object.assign(
                new Error(error),
                {
                    message: error,
                    newRelicMessage: 'Ukheshe Token Failed: Invalid Credentials',
                    details: {}
                }
            );
        }

        let ukesheUser = await ukhesheService.getUserDetail(createToken, token);

        let detail = {};
        detail.saIdNo = data.saIdNo;
        detail.ukhesheCustId = ukesheUser.customerId + "";
        detail.submitKey = data.password;
        detail.ukhesheExternalCustId = ukesheUser.externalUniqueId;
        detail.firstName = ukesheUser.firstName;
        detail.lastName = ukesheUser.lastName;
        detail.email = ukesheUser.email;
        detail.title = ukesheUser.title;
        detail.gender = ukesheUser.gender;
        detail.locale = ukesheUser.locale;
        detail.dateOfBirth = ukesheUser.dateOfBirth;
        detail.maritalStatus = ukesheUser.maritalStatus;
        detail.deviceId = createToken.deviceId;

        detail.isProfileComplete = true;

        detail.deviceType = data.deviceType;
        detail.deviceToken = data.deviceToken;

        detail.password = await utility.hashPasswordUsingBcrypt(data.password);
        if (ukesheUser.phone1) {
            let ph = ukesheUser.phone1 + "";
            if (ph && ph.startsWith("0") || ph.startsWith("27")) {
                if (ph.startsWith("0")) {
                    ph = ph.slice(1, ph.length);
                } else if (ph.startsWith("27")) {
                    ph = ph.slice(2, ph.length);
                }
            }
            detail.phone = ph;
        }
        detail.identityPhone = data.phone;
        detail.countryCode = "+27";
        detail.role = 'user';

        let _userModel = await Model.user.findOne({
            saIdNo: req.body.saIdNo, isDeleted: false
        }, {
            saIdNo: 1, role: 1, isBlocked: 1, countryCode: 1, phone: 1, ukhesheCustId: 1, isProfileComplete: 1, submitKey: 1
        });
        if (!_userModel) {
            _userModel = await Model.user.create(detail);
        }

        let setObj = {};
        let jti = utility.generateRandomString(20);
        setObj.jti = jti;

        let resRunAlgo = await ukhesheService.getKycData(createToken);
        let _updateKYC = await common.checkKYCStatus(req, _userModel, resRunAlgo);

        let _returnUser = { ...ukesheUser, ...detail, ..._updateKYC, _id: _userModel._id };
        _returnUser = JSON.parse(JSON.stringify(_returnUser)); //THIS IS WEIRD BUT IT WORKS
        _returnUser.token = await utility.jwtSign({
            _id: _userModel._id,
            role: _userModel.role,
            email: _userModel.email
        });
        _returnUser.type = "Bearer";
        _returnUser.expire = await utility.getJwtExpireTime();
        _returnUser.refreshToken = await utility.jwtRefreshSign({
            _id: _userModel._id
        });
        _returnUser.isRequiredPassCode = true;
        _returnUser.isRegistred = true;
        _returnUser.ukhesheCustId = _returnUser.ukhesheCustId + "";
        delete _returnUser.password;
        delete _returnUser.submitKey;
        return _returnUser;
    } else {
        throw Object.assign(
            new Error(process.lang.INVALID_OTP),
            {
                message: process.lang.INVALID_OTP,
                newRelicMessage: '_enrollmentLogin Token Failed',
                details: {
                    description: process.lang.INVALID_OTP,
                    saIdNo: data.saIdNo,
                    phone: data.phone,
                    deviceFingerprint: data.deviceId,
                    deviceType: data.deviceType
                }
            }
        );
    }

}


async function _doLogin(req, user, data, enroll) {
    let setObj = {
        deviceType: data.deviceType,
        deviceToken: data.deviceToken,
        identityPhone: user.identityPhone
    };
    if (user) {
        user = JSON.parse(JSON.stringify(user));
    }

    if (user.isBlocked) {
        throw Object.assign(new Error(process.lang.USER_IS_BLOCKED), {
            newRelicMessage: process.lang.USER_IS_BLOCKED,
            details: { description: 'User is blocked', saIdNo: user.saIdNo }
        });
    }

    let config = {
        customerId: user.ukhesheCustId,
        saIdNo: user.saIdNo
    };

    if (!enroll) {
        let createIdIdentity = await ukhesheService.getIdentityFromUkheshe(config);

        if (createIdIdentity.isSuccess == false) {
            let createIdentity = {
                saIdNo: data.saIdNo,
                ukhesheCustId: user.ukhesheCustId,
                password: data.password
            };

            await ukhesheService.createIdentityOfUser(createIdentity);
        }
    }

    let kycData = await ukhesheService.getKycData(user);
    if (kycData.isSuccess && kycData.data != undefined) {
        await common.checkKYCStatus(req, user, kycData);
    }

    await Model.user.findOneAndUpdate({ _id: user._id }, setObj, { new: true });
    user = await Model.user.findOne({ _id: ObjectId(user._id) });
    // [user] = await Model.user.aggregate([{ $match: { _id: ObjectId(user._id), isDeleted: false } },
    // {
    //     $lookup: {
    //         from: "userdocuments",
    //         localField: '_id',
    //         foreignField: 'userId',
    //         as: "userdocuments"
    //     }
    // }
    // ]);

    //user.userdocuments = user.userdocuments.filter((x) => x.isDeleted == false);

    user = JSON.parse(JSON.stringify(user));
    user.token = await utility.jwtSign({
        _id: user._id,
        role: user.role,
        // jti: jti,
        email: user.email
    });
    user.type = "Bearer";
    user.expire = await utility.getJwtExpireTime();
    user.refreshToken = await utility.jwtRefreshSign({
        _id: user._id
    });
    delete user.submitKey;
    return user;
}

async function updateprofile(req) {
    let data = req.body;
    let user = req.user;

    let update = {
        saIdNo: user.saIdNo,
        phone: user.phone,
        submitKey: user.submitKey,
        deviceId: data.deviceId,
        ukhesheCustId: user.ukhesheCustId
    };

    if (data.saIdNo) {
        data.phone = req.user.phone;
        data.saIdNo = req.user.saIdNo;
        if (!data.dateOfBirth || data.dateOfBirth?.length < 8) {
            data.dateOfBirth = (data.saIdNo.substring(0, 1) === '0' ? '20' : '19') + data.saIdNo.substring(0, 6);
        }

        let res = await ukhesheService.updateUkhesheUser(req, data, req.user, update);
        if (!res.isSuccess) {
            throw Object.assign(
                new Error('Error Updating Profile'),
                {
                    message: 'Error Updating Profile',
                    newRelicMessage: 'Updating Profile Failed',
                    details: {
                        data: res.data,
                        saIdNo: data.saIdNo,
                        otp: data.otp,
                        device: data.deviceType
                    }
                }
            );
            // throw res.data && res.data.length > 0 ? res.data[0].description : "error in Ukheshe Api";
        }
    }

    delete data.isProfileComplete;
    let updatedUser = await Model.user.findOneAndUpdate({ _id: req.user._id }, data, { new: true });

    return updatedUser;
}

async function cardProfileUpdate(req) {
    let data = req.body;
    let updatedUser;
    let payload;
    payload = data.profileDetail;

    let accessToken = req.headers["ukheshetoken"];

    let token = {
        headerValue: accessToken
    };

    let ukhesheUser = await ukhesheService.getUserDetail(req.user, token);

    if (req.body.profileDetail && ukhesheUser.profileCompletionStatus != 13) {
        let res = await ukhesheService.updateCardDetailUkhesheUser(req, payload, req.user);
        if (!res.isSuccess) {
            throw res.data && res.data.length > 0 ? res.data[0].description : "error in Ukheshe Api";
        }
        updatedUser = await Model.user.findOneAndUpdate({ _id: req.user._id }, payload, { new: true });
    }
    if (data.addressId) {
        await ukhesheService.deleteAddressOfUser(req, data, req.user);
    }
    if (data.addressDetail) {
        let res = await ukhesheService.updateAddressDetailUkhesheUser(req, data, req.user);
        if (!res.isSuccess) {
            throw res.data && res.data.length > 0 ? res.data[0].description : "error in Ukheshe Api";
        }
    }
    return updatedUser;
}


async function findSaId(req) {
    // Find customer on Ukheshe
    let user = await ukhesheService.getUserFromUksheBySaId(req.body.saIdNo);

    if (user.length == 0) {
        // User is not registered in ukheshe
        throw process.lang.SAID_NOT_REGISTRED;
    } else {
        // Get User Identities
        let getUserIdentities = await ukhesheService.getIdentityOfUser({ ukhesheCustId: user[0].customerId });

        // Check if user has any identities
        let hasIdentity = getUserIdentities.data.length > 0;

        // Check if user has an identity with SaId
        let hasIdIdentity = getUserIdentities.data.find(it => it.identity == "BHA-" + req.body.saIdNo) !== undefined;

        // Check if user is on MongoDB
        //-Hal- Find user in local DB (should be the only "findOne" from this point onwards, should not be "lean"):
        let findUser = await Model.user.findOne({
            saIdNo: req.body.saIdNo, isDeleted: false
        }, {
            saIdNo: 1, role: 1, isBlocked: 1, countryCode: 1, phone: 1, ukhesheCustId: 1, isProfileComplete: 1
        }).lean();

        let registrationCompleted;

        if (hasIdentity && !hasIdIdentity) {
            registrationCompleted = await getWalletProvisions(user[0].customerId);
        } else {
            registrationCompleted = true;
        }

        if (hasIdentity && registrationCompleted) {
            if (!findUser) {
                // Migration 
                return { enroll: true, hasIdIdentity: hasIdIdentity, customerId: user[0].customerId };
            } else {
                // Login - User found in MongoDB
                findUser.hasIdIdentity = hasIdIdentity;
                findUser.isRegistred = true;
                findUser.customerId = user[0].customerId;
                return findUser;
            }
        } else {
            // Registration - No identities found
            if (findUser) {
                await Model.user.deleteMany({
                    saIdNo: req.body.saIdNo
                });
                return { enroll: false, customerId: user[0].customerId, isRegistred: false, hasIdIdentity: false };
            } else {
                return { enroll: false, customerId: user[0].customerId, isRegistred: false, hasIdIdentity: false };
            }
        }
    }
}

async function updatepassCode(req) {
    let data = req.body;
    if (data.isUpdate) {
        let user = await Model.user.findOne({
            _id: req.user._id
        }).select("passCode passCodeRamdom").lean();
        if (user.passCodeRamdom != req.body.passCodeRamdom) {
            throw process.lang.INVALID_HASH;
        }
        let bufferObj = Buffer.from(req.body.passCode, "base64");
        data.passCode = bufferObj.toString("utf8");
        data.passCode = await utility.hashPasswordUsingBcrypt(data.passCode);
    } else {
        if (data.passCode) {
            data.passCode = await utility.hashPasswordUsingBcrypt(data.passCode);
        }
    }
    return await Model.user.findOneAndUpdate({
        _id: req.user._id
    }, data, {
        new: true
    });
}
async function verifyPassCode(req) {
    let user = await Model.user.findOne({ _id: req.user._id, isDeleted: false }).select("passCode passCodeRamdom").lean();
    if (req.body.isOnlyPin) {
        let bufferObj = Buffer.from(req.body.passCode, "base64");
        let passCode = bufferObj.toString("utf8");
        let match = await utility.comparePasswordUsingBcrypt(passCode, user.passCode);

        if (!match) {
            throw process.lang.INVALID_PASCODE;
        }
        return { isMatched: true };
    } else {
        if (user.passCodeRamdom != req.body.passCodeRamdom) {
            throw process.lang.INVALID_HASH;
        }
    }


    let bufferObj = Buffer.from(req.body.passCode, "base64");
    let passCode = bufferObj.toString("utf8");
    let match = await utility.comparePasswordUsingBcrypt(passCode, user.passCode);

    if (!match) {
        let response = await wrongPin(req);
        if (response.isBlocked) {
            return { isThreeAttamped: true };
        }
        throw process.lang.INVALID_PASCODE;
    }

    await Model.errorPin.updateMany({ userId: req.user._id, isDeleted: false, type: 'PASSCODE' }, { isDeleted: true });

    return { isMatched: true };

}
async function wrongPin(req) {
    let errorPin = await Model.errorPin.find({ userId: req.user._id, isDeleted: false, type: 'PASSCODE' }).sort({ lastTryAt: 1 }).lean();
    if (errorPin.length >= 2) {
        let first = errorPin[0];
        let diffrence = moment().diff(moment(first.lastTryAt), "second");
        if (diffrence <= 120) { // 2 mints
            let detail = {
                userId: req.user._id,
                type: "VERIFY_PIN"
            };
            process.emit("userBlock", detail);
            return { isBlocked: true };
        }
    } else {
        let adding = {
            userId: req.user._id,
            lastTryAt: new Date(),
            lastTryCount: 1,
            type: 'PASSCODE'
        };
        await Model.errorPin.create(adding);
    }
    return { isBlocked: false };
}
async function login(req, data) {
    //-Hal- Check how "enroll" variable is being set; there may be a fault here causing enrollments to be done multiple times.
    //-Hal- It would probably be better to do the "Model.user.findOne" (line #871) here first, then check if "!user.ukhesheCustId" then "_doEnrolmentLogin":
    if (data.enroll) {
        const user = await _doEnrolmentLogin(req, data);
        return user;
    }

    let planPassword = data.password;
    let qry = {
        isDeleted: false,
        //-Hal- "role" unnecessary? Can one unique user have more than one role? If not, then remove "role" from "qry":
        role: data.role
    };

    if (data.saIdNo) {
        qry.saIdNo = data.saIdNo;
    } else if (utility.isPhone(data.phone)) {
        //TODO: Fix IOS app so that it passes "saIdNo" and does not neet to use "phone" to verify:
        qry.phone = data.phone;

        if (data.countryCode) qry.countryCode = data.countryCode;
    }

    let user = await Model.user.findOne(qry, {
        password: 1,
        role: 1,
        isBlocked: 1,
        deviceId: 1,
        ukhesheCustId: 1,
        phone: 1,
        submitKey: 1,
        identityPhone: 1,
        saIdNo: 1,
        isRequiredPassCode: 1,
        passCode: 1
    });

    if (!user) {
        throw Object.assign(new Error(process.lang.INVALID_CREDENTAILS), {
            newRelicMessage: process.lang.INVALID_CREDENTAILS,
            details: { description: 'User Not found in MongoDB', saIdNo: data.saIdNo }
        });
    }
    //-Hal- Maybe move this to the top of the function (Line #855), since everything else should not happen if password is wrong:
    let match = await utility.comparePasswordUsingBcrypt(planPassword, user.password);
    if (!match) {
        throw Object.assign(new Error(process.lang.INVALID_CREDENTAILS), {
            newRelicMessage: process.lang.INVALID_CREDENTAILS,
            details: { description: 'MongoDB Passwords do not match', saIdNo: data.saIdNo }
        });
    }
    // if (user) {
    //     user = await Model.user.findOne({
    //         _id: user._id
    //     });
    // }
    //-Hal- Should move this to the top of the function as well, since everything else should not happen if user id blocked:
    if (user.isBlocked) {
        throw process.lang.USER_BLOCKED;
    }
    user = await _doLogin(req, user, data, data.enroll);
    return user;
}

async function forgotpassword(data) {
    let token = await ukhesheService.createkhesheToken(true);

    let identity;

    if (data.hasIdIdentity != true) {
        let existingIdentity = await ukhesheService.getIdentityOfUser({ ukhesheCustId: data.customerId });
        identity = existingIdentity.data[0].identity;
    } else {
        identity = 'BHA-' + data.saIdNo;
    }

    let config = {
        method: 'POST',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/global/identities/${identity}/password-change-init`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token.headerValue
        }
    };
    const response = await axios(config);
    return response.data;
}

async function changePassword(req, data, user) {
    if (!user.forResetPassword) {
        let findadmin = await Model.user.findOne({ _id: user._id }, {
            password: 1
        });
        if (!findadmin) {
            throw process.lang.INVALID_CREDENTAILS;
        } else {
            let match = await utility.comparePasswordUsingBcrypt(data.oldPassword, findadmin.password);
            if (!match) {
                throw process.lang.OLD_PASS_NOT_MATCH;
            }
        }
    }
    let detail = {
        password: data.password,
        identitiy: user.saIdNo,
        ukhesheCustId: user.ukhesheCustId
    };
    let res = await ukhesheService.updatePasswordInUkshe(req, detail, user);
    if (res && !res.isSuccess) {
        throw res.data[0].description;
    }

    await Model.user.findByIdAndUpdate(user._id, {
        $set: {
            password: await utility.hashPasswordUsingBcrypt(data.password),
            submitKey: data.password
        }
    });
    return {};
}
//************************* DashBoard *********************************//
async function dashboard() {

}
//****************************** Notification ***************************************//
async function userNotification(req) {
    let page = req.query.page;
    let size = req.query.limit;
    let skip = parseInt(page - 1) || 0;
    let limit = parseInt(size) || 10;
    skip = skip * limit;

    let notification = await Model.notification.find({ isDeleted: false, userId: ObjectId(req.user._id) }).
        populate("userId fullName firstName lastName email phone image saIdNo countryCode").
        sort({ createdAt: -1 }).skip(skip).limit(limit);
    return notification;
}
async function userClearNotification(req) {
    let notification = await Model.notification.updateMany({
        userId: req.user._id,
        isDeleted: false
    }, {
        $set: {
            isDeleted: true
        }
    });
    return notification;
}

async function userDocUpload(req) {
    if (req.user) {
        req.body.userId = req.user._id;
    } else {
        req.body.userId = req.params.id;
    }
    if (req.body.isThumb_image) { // when Thumb is uploaded
        let result = {
            body: {}
        };
        let userDoc = await Model.userDocument.findOne({
            userId: req.user._id, isDeleted: false,
            doc_type: constant.DOC_TYPE.THUMB_SELFIE
        });
        if (userDoc) {
            if (userDoc.ukhesheDocId) {
                await ukhesheService.deleteUserDocument(req, req.user, userDoc.ukhesheDocId);
            }
            await Model.userDocument.updateOne({ userId: req.user._id, isDeleted: false }, { isDeleted: true });
        }

        let res = await ukhesheService.addDocumentkhesheUser(req, req.user, req.body, true); // adding Thumb selfie in ukeshe
        let isArray = Array.isArray(res?.data);
        if (isArray) {
            throw process.lang.DOCUMENT_ANDTYPE_NOT_MATCHED;
        } else { // sucess
            // result.body = JSON.parse(result.body);
            result.body.isverified = false;
            result.body.pagination = true;
            result.body.noCode = true;
            req.body.ukhesheDocId = res.data.documentId;
            req.body.ukhesheDocType = res.data.documentType;
        }

        await Model.userDocument.create(req.body);
        let payload = {
            userId: req.user._id, type: "DOC_UPLOADED"
        };
        process.emit("DocUploaded", payload);
        return result.body;
    } else {
        if (!req.user.ukhesheCustId) {
            let data = {};
            data.firstName = "user";
            data.lastName = "user";
            data.phone = req.user.phone;
            data.ukhesheExternalCustId = utility.generateRandom(15);
            let res = await ukhesheService.createUkhesheUser(data, req.user);
            req.user = await Model.user.findOneAndUpdate({
                _id: req.user._id
            }, {
                $set: {
                    ukhesheExternalCustId: data.ukhesheExternalCustId, ukhesheCustId: res.customerId
                }
            }, { new: true });
        }
        if (req.body.isProfileUpdate) {
            let userDoc = await Model.userDocument.findOne({
                userId: req.user._id,
                isDeleted: false,
                doc_type: { $ne: constant.DOC_TYPE.THUMB_SELFIE }
            });
            if (userDoc && userDoc.ukhesheDocId) {
                await ukhesheService.deleteUserDocument(req, req.user, userDoc.ukhesheDocId);
                await Model.userDocument.updateOne({
                    _id: userDoc._id, userId: req.user._id, isDeleted: false
                }, { isDeleted: true });
            }
        } else {
            let userDoc = await Model.userDocument.find({ userId: req.user._id, isDeleted: false });
            if (userDoc && userDoc.length > 0) {
                await ukhesheService.deleteUserDocumentLocalAndUkshe(req, req.user, userDoc);
            }
        }
    }
    let res = await ukhesheService.addDocumentkhesheUser(req, req.user, req.body, false); // adding document in ukeshe
    let isArray = Array.isArray(res.data);
    if (isArray) {
        throw process.lang.DOCUMENT_ANDTYPE_NOT_MATCHED;
    } else {
        req.body.ukhesheDocId = res.data.documentId;
        req.body.ukhesheDocType = res.data.documentType;
    }
    await Model.userDocument.create(req.body);

    utility.clearJunk("../public/images");
    if (req.body.isProfileUpdate) {
        let resRunAlgo = await ukhesheService.runUkhesheAlgo({ req: req, user: req.user }); // run ukheshe in ukeshe
        if (resRunAlgo && !resRunAlgo.isSuccess) {
            throw process.lang.ALGO_MATCH_ERROR;
        }
        common.checkKYCStatus(req, req.user, resRunAlgo);
    }
    return {
        isUpload: true
    };
}
async function sendOtp(req) {
    let data = req.body;

    let token = await ukhesheService.generateUkhsheTokenMySide(req, req.user);

    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token.headerValue
        }
    };
    const response = await axios(config);
    let phone = response.data.phone1;

    await Otp.generatePhoneOtp(data.countryCode, phone);
    return {
        phone: `+27 ** **** ${phone.slice(-4)}`,
        verificationType: 1
    };
}

async function otp(req) {
    let data = req.body;

    let token = await ukhesheService.generateUkhsheTokenMySide(req, req.user);

    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token.headerValue
        }
    };
    const response = await axios(config);
    let phone = response.data.phone1;

    await Otp.generatePhoneOtp(data.countryCode, phone);
    return {
        phone: `+27 ** **** ${phone.slice(-4)}`,
        verificationType: 1
    };
}
async function verotp(data, req) {
    let user = req.user;
    let setObj = {};

    let token = await ukhesheService.generateUkhsheTokenMySide(req, req.user);

    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${req.user.ukhesheCustId}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token.headerValue
        }
    };
    const response = await axios(config);

    let phone = response.data.phone1;

    if (phone.substring(0, 2) == '27') {
        phone = phone.replace('27', '');
    }

    if (phone.startsWith('0')) {
        phone = phone.slice(1);
    }

    let otp = await Otp.verotp(data.countryCode, phone, data.code, true, false, user._id, data.type);
    if (!otp.isSuccess) {
        let response = await wrongotp(req);
        if (response.isBlocked) {
            return { isThreeOTPAttamped: true };
        }
        return { message: "Invalid OTP", count: response.errorPinCount, isError: true };
    }
    setObj.isPhoneVerify = true;
    setObj.passCodeRamdom = utility.generateRandomString(20);
    await Model.errorPin.updateMany({ userId: req.user._id, isDeleted: false, type: 'OTP' }, { isDeleted: true });


    user = await Model.user.findOneAndUpdate({ _id: ObjectId(user._id) }, setObj).lean();
    user.isPhoneVerify = true;
    user.passCodeRamdom = setObj.passCodeRamdom;

    return user;
}

async function wrongotp(req) {
    let errorPin = await Model.errorPin.find({ userId: req.user._id, isDeleted: false, type: 'OTP' }).sort({ lastTryAt: 1 }).lean();
    if (errorPin.length >= 3) {
        let first = errorPin[0];
        let diffrence = moment().diff(moment(first.lastTryAt), "second");
        if (diffrence <= 180) { // 3 mints
            let detail = {
                userId: req.user._id,
                type: "VERIFY_OTP"
            };
            process.emit("userBlock", detail);
            return { isBlocked: true };
        }
    } else {
        let adding = {
            userId: req.user._id,
            lastTryAt: new Date(),
            lastTryCount: 1,
            type: 'OTP'
        };
        await Model.errorPin.create(adding);
    }
    errorPin = await Model.errorPin.count({ userId: req.user._id, isDeleted: false, type: 'OTP' }).sort({ lastTryAt: 1 });

    return { isBlocked: false, errorPinCount: errorPin };
}
async function getPofile(req) {
    let accessToken = {
        headerValue: req.headers["ukheshetoken"]
    };

    let user = req.user;
    let _data = await ukhesheService.getUserDetail(req.user, accessToken);

    return {
        title: _data.title,
        gender: _data.gender,
        maritalStatus: _data.maritalStatus,
        firstName: _data.firstName,
        lastName: _data.lastName,
        phone: _data.phone1,
        saIdNo: _data.nationalIdentityNumber,
        dateOfBirth: _data.dateOfBirth,
        isProfileComplete: user.isProfileComplete,
        deviceType: user.deviceType,
        isKYCCompleted: user.isKYCCompleted,
        selfieIsASelfie: user.selfieIsASelfie,
        selfieIsLegitimate: user.selfieIsLegitimate,
        selfieMatchesIdentity: user.selfieMatchesIdentity,
        firstNameMatchesIdentity: user.firstNameMatchesIdentity,
        lastNameMatchesIdentity: user.lastNameMatchesIdentity,
        identityNumberMatchesIdentity: user.identityNumberMatchesIdentity,
        idChecksPassed: user.idChecksPassed,
        selfieChecksPassed: user.selfieChecksPassed
    };
}

async function deletePofile(req) {
    let res = await ukhesheService.deleteUser(req.user);
    if (res && !res.isSuccess) {
        throw res.data[0].description;
    }
    return await Model.user.findOneAndUpdate({ _id: req.user._id }, { isDeleted: true }, { new: true });
}
async function callBackUrl(req) {
    if (req.body) {
        let externalUniqueId = req.body.externalUniqueId;
        if (externalUniqueId?.includes("-")) {
            externalUniqueId = externalUniqueId.split("-")[1];
        }
        let user = await Model.user.findOne({ _id: ObjectId(externalUniqueId), isDeleted: false }).lean();
        if (user && user.deviceToken) {
            let notification = {
                title: "Card added successfully",
                message: "Card added successfully",
                userId: user._id,
                isSaved: true,
                pushType: 3,
                deviceToken: user.deviceToken,
                deviceType: user.deviceType
            };
            process.emit("sendNotification", notification);
        }
    }
    return {};
}
async function landing(req) {
    return {};
}
async function eftCallbackUrl(req) {
    if (req.body) {
        let user = await Model.user.findOne({ ukhesheCustId: req.body.customerId, isDeleted: false }).lean();
        if (user && user.deviceToken) {
            let notification = {
                title: "Your EFT is done successfully",
                message: `Your EFT of R${req.body.finalAmount} was successful`,
                userId: user._id,
                isSaved: true,
                pushType: 1,
                deviceToken: user.deviceToken,
                deviceType: user.deviceType
            };
            process.emit("sendNotification", notification);

        }
    }
    return {};
}
async function cardfieldtopup(req) {
    if (req.body) {
        let externalUniqueId = req.body.externalUniqueId;
        if (externalUniqueId.includes("-")) {
            externalUniqueId = externalUniqueId.split("-")[1];
        }
        let user = await Model.user.findOne({ _id: ObjectId(externalUniqueId), isDeleted: false }).lean();
        if (user && user.deviceToken) {
            let notification = {
                title: "Wallet topup successful",
                message: `Wallet topped up with R${req.body.amount} successful`,
                userId: user._id,
                isSaved: true,
                pushType: 2,
                deviceToken: user.deviceToken,
                deviceType: user.deviceType
            };
            if (req.body.status != 'SUCCESSFUL') {
                notification.title = "Wallet top up failed";
                notification.message = "Wallet top up failed";
            }
            process.emit("sendNotification", notification);
        }
    }
    return {};
}

async function walletWithdrawalCallback(req) {
    if (req.body) {
        let externalUniqueId = req.body.externalUniqueId;
        if (externalUniqueId.includes("-")) {
            externalUniqueId = externalUniqueId.split("-")[1];
        }
        let user = await Model.user.findOne({ _id: ObjectId(externalUniqueId), isDeleted: false }).lean();
        if (user && user.deviceToken) {
            let notification = {
                title: "Withdrawal successful",
                message: `${req.body.description} of R${req.body.finalAmount} successful`,
                userId: user._id,
                isSaved: true,
                pushType: 4,
                deviceToken: user.deviceToken,
                deviceType: user.deviceType
            };
            if (req.body.status != 'SUCCESSFUL') {
                notification.title = "Withdrawal failed";
                notification.message = "Withdrawal failed";
            }
            process.emit("sendNotification", notification);
        }
    }
    return {};
}

async function walletToWalletTopUp(req) {
    if (req.body) {
        let externalUniqueId = req.body.externalUniqueId;
        if (externalUniqueId.includes("-")) {
            externalUniqueId = externalUniqueId.split("-")[1];
        }
        let user = await Model.user.findOne({ _id: ObjectId(externalUniqueId), isDeleted: false }).lean();
        if (user && user.deviceToken) {
            let notification = {
                title: "Wallet transfer done successfully",
                message: "Wallet transfer done successfully",
                userId: user._id,
                isSaved: true,
                pushType: 4,
                deviceToken: user.deviceToken,
                deviceType: user.deviceType
            };
            if (req.body.status != 'SUCCESSFUL') {
                notification.title = "Wallet transfer failed";
                notification.message = "Wallet transfer failed";
            }
            process.emit("sendNotification", notification);
        }
    }
    return {};
}

async function sendCaptureOtp(req) {
    let accessTokenFull = req.headers["authorization"];
    let accessToken;
    if (accessTokenFull.startsWith("Bearer")) {
        accessToken = accessTokenFull.substr("Bearer".length + 1);
    } else {
        const parts = accessTokenFull.split(" ");
        accessToken = parts[1];
    }
    let link;

    if (!req.body.type && req.body.webType == "TENET") {
        link = `${config.get("Link.url")}/web/authenticate?token=${accessToken}&data=${req.body.data}`;
    }
    if (req.body.type == "selfie" && req.body.webType == "TENET") {
        link = `${config.get("Link.url")}/web/selfie?token=${accessToken}&type=selfie&data=${req.body.data}`;
    }
    if (req.body.type == "editDocument" && req.body.webType == "TENET") {
        link = `${config.get("Link.url")}/web/authenticate?token=${accessToken}&type=editDocument&data=${req.body.data}`;
    }
    if (req.body.type == "editDocument" && req.body.webType == "TENET") {
        link = `${config.get("Link.url")}/web/authenticate?token=${accessToken}&type=editDocument&data=${req.body.data}`;
    }
    // nsfas/web/SA

    if (!req.body.type && req.body.webType == "NSFAS") {
        link = `${process.env.NSFAS_WEB_URL}/authenticate?token=${accessToken}&data=${req.body.data}`;
    }
    if (req.body.type == "selfie" && req.body.webType == "NSFAS") {
        link = `${process.env.NSFAS_WEB_URL}/selfie?token=${accessToken}&type=selfie&data=${req.body.data}`;
    }
    if (req.body.type == "editDocument" && req.body.webType == "NSFAS") {
        link = `${process.env.NSFAS_WEB_URL}/authenticate?token=${accessToken}&type=editDocument&data=${req.body.data}`;
    }
    if (req.body.type == "editDocument" && req.body.webType == "NSFAS") {
        link = `${process.env.NSFAS_WEB_URL}/authenticate?token=${accessToken}&type=editDocument&data=${req.body.data}`;
    }

    return { url: link };
}
async function getStudent(req) {
    let user = await Model.studentCards.findOne({
        IDNumber: req.query.id
    });
    if (!user) {
        // eslint-disable-next-line no-throw-literal
        throw "No result found";
    }
    return user;
}
async function updateStudent(req) {
    let user = await Model.studentCards.findOne({
        IDNumber: req.params.id
    });
    if (!user) {
        // eslint-disable-next-line no-throw-literal
        throw "No result found";
    }
    user = await Model.studentCards.findOne({
        IDNumber: req.params.id,
        CardIssued: 'ISSUED'
    });
    if (user) {
        // eslint-disable-next-line no-throw-literal
        throw "Card already issued";
    }
    return await Model.studentCards.findOneAndUpdate({
        IDNumber: req.params.id
    }, {
        $set: {
            CardIssued: 'ISSUED'
        }
    }, {
        new: true
    });
}
async function refreshToken(req, res) {
    let setObj = {};
    let jti = utility.generateRandomString(20);
    setObj.jti = jti;
    let user = await Model.user.findOneAndUpdate({
        _id: req.user._id
    }, {
        jti: jti
    }, {
        new: true
    }).lean();
    user.token = await utility.jwtSign({
        _id: req.user._id,
        role: req.user.role,
        jti: jti,
        email: req.user.email
    });
    user.type = "Bearer";
    user.expire = await utility.getJwtExpireTime();
    user.refreshToken = await utility.jwtRefreshSign({
        _id: req.user._id
    });
    return user;
}

async function airtimePayment(req) {
    let data = req.body;

    let reservationData = {
        walletId: data.fromWalletId,
        amount: data.amount
    };

    let walletsReservation = await ukhesheService.createReservation(req, reservationData, req.user);

    if (!walletsReservation.isSuccess) {
        throw walletsReservation.data[0].description;
    }

    let airtimedata = {
        requestId: data.requestId,
        vendorId: data.vendorId,
        mobileNumber: formatPhoneBL(data.mobileNumber),
        amount: data.amount.replace(".", "")
    };
    if (data.productId) {
        airtimedata.productId = data.productId;
    }

    airtimedata = JSON.stringify(airtimedata);
    let url;
    let airtimeRes;

    if (data.type == 0) {
        url = `mobile/airtime/sales`;
        airtimeRes = await airtime.airtimeinfo(airtimedata, url);
    }

    if (data.type == 1) {
        url = `mobile/bundle/sales`;
        airtimeRes = await airtime.airtimeinfo(airtimedata, url);
    }

    let deleteReservationData = {
        walletId: data.fromWalletId,
        reservationId: walletsReservation.data.reservationId

    };

    let deleteReservation = await ukhesheService.deleteReservation(deleteReservationData, req.user);

    if (!airtimeRes.isSuccess) {
        if (airtimeRes.data.status == 409) {
            throw process.lang.SERVICE_UNAVAILABLE;
        } else {
            throw process.lang.SOMETHING_WENT_WRONG;
        }
    }

    let axidata = JSON.stringify({
        description: `${data.description} ${formatPhoneBL(data.mobileNumber)}`,
        externalUniqueId: data.requestId,
        fromWalletId: data.fromWalletId,
        toWalletId: process.env.BLUE_LABEL_WALLET_ID,
        amount: data.amount
    });

    let walletsTransfer = await ukhesheService.walletsTransfer(req, axidata, req.user);

    if (!walletsTransfer.isSuccess) {
        throw walletsTransfer.data[0].description;
    }

    if (!deleteReservation.isSuccess && deleteReservation.data.response !== null) {
        addError({
            body: {
                error: deleteReservation.data.response.statusText,
                body: JSON.stringify(deleteReservation.data.response.data[0]),
                statusCode: deleteReservation.data.response.status.toString(),
                url: deleteReservation.data.response.config.url
            }
        });
    }

    return airtimeRes.data;
}

async function initRefund(data, amount, fromWalletId) {
    let axidata = JSON.parse(data);
    axidata.toWalletId = fromWalletId;
    axidata.fromWalletId = 198165; // refund wallet id 
    axidata.amount = amount;
    axidata = JSON.stringify(axidata);

    let walletsTransfer = await ukhesheService.walletsTransfer(axidata, null, true);
    if (!walletsTransfer.isSuccess) {
        throw walletsTransfer.data[0].description;
    }
}
async function addHelp(req) {
    req.body.userId = req.user._id;
    return await Model.query.create(req.body);
}
async function getHelp(data) {
    let qry = { isDeleted: false };
    if (data.user) {
        qry = { isDeleted: false, userId: data.user._id };
    }

    let page = data.query.page;
    let size = data.query.size;
    let skip = parseInt(page - 1) || 0;
    let limit = parseInt(size) || 10;
    skip = skip * limit;
    if (data.originalUrl.includes('admin')) {
        qry = { isDeleted: false, isResolved: false };
    }
    if (data.query.search) {
        qry.$or = [
            { email: { $regex: data.query.search, $options: "i" } },
            { phone: { $regex: data.query.search, $options: "i" } },
            { name: { $regex: data.query.search, $options: "i" } }
        ];
    }
    if (data.params.id) {
        return await Model.query.findOne({ _id: data.params.id, ...qry });
    }
    if (data.params.type == 'all') {
        return await Model.query.find({ ...qry }).sort({ createdAt: -1 });
    }
    let pipeline = [];
    pipeline.push({ $match: qry }, { $sort: { createdAt: -1 } });
    pipeline.push({ $lookup: { from: "users", foreignField: "_id", localField: "userId", as: "user" } }, { $unwind: "$user" },
        {
            $project: {
                name: 1, email: 1, phone: 1, query: 1, countryCode: 1, isoCode: 1, isResolved: 1, resolvedRemarks: 1,
                createdAt: 1, "user.fullName": 1, "user.userName": 1, "user.firstName": 1, "user.lastName": 1, "user.email": 1
                , "user.phone": 1, "user.saIdNo": 1, "user.countryCode": 1, "user.image": 1
            }
        });
    pipeline = await common.pagination(pipeline, skip, limit);
    let [details] = await Model.query.aggregate(pipeline);
    return details;
}
async function updateHelp(req) {
    let query = await Model.query.findOne({ _id: req.params.id, isDeleted: false });

    if (!query) throw process.lang.INVALID_HELP_ID;

    await Model.query.findOneAndUpdate({ _id: req.params.id }, req.body);

    return { isSuccess: true };

}
async function addError(req) {
    // return await Model.error.create(req.body);
}
async function getError() {
    return await Model.error.find({ isDeleted: false });
}

async function getChatList(req) {
    let detail = {};
    detail.connectionId = await common.findUserWithPendingQuery(req.user);

    let page = req.query.page;
    let size = req.query.limit;
    let skip = parseInt(page - 1) || 0;
    let limit = parseInt(size) || 10;
    skip = skip * limit;
    let pipeline = [];
    if (req.query.isAdmin) {
        pipeline.push({ $match: { text: { $ne: null } } });
    }
    pipeline.push({
        $match: {
            $or: [{ recieverId: mongoose.Types.ObjectId(req.user._id) }, { senderId: mongoose.Types.ObjectId(req.user._id) }]
        }
    },
        { $match: { "isDeleted": false } },
        {
            $lookup: {
                from: "chatmessages",
                let: { connectionId: "$connectionId" },
                pipeline: [{
                    $match: {
                        $expr: {
                            $or: [{ $eq: ["$$connectionId", "$connectionId"] }]
                        }
                    }
                },
                { $sort: { createdAt: -1 } },
                { $limit: 1 }
                ],
                as: "lastMessage"
            }
        },
        {
            $group: {
                _id: {
                    connectionId: "$connectionId",
                    lastMessage: { $arrayElemAt: ["$lastMessage", -1] }
                }
            }
        },
        { $project: { _id: 0, lastMessage: "$_id.lastMessage", connectionId: "$_id.connectionId" } },
        {
            $addFields: {
                user: {
                    $cond: {
                        if: {
                            $eq: ["$lastMessage.senderId", mongoose.Types.ObjectId(req.user._id)]
                        },
                        then: "$lastMessage.recieverId", else: "$lastMessage.senderId"
                    }
                }
            }
        },
        { $lookup: { from: "users", localField: "user", foreignField: "_id", as: "user" } },
        { $unwind: "$user" },
        { $lookup: { from: "users", localField: "lastMessage.senderId", foreignField: "_id", as: "sender" } },
        { $lookup: { from: "users", localField: "lastMessage.recieverId", foreignField: "_id", as: "reciever" } },
        { $match: { "sender.isDeleted": false } },
        { $match: { "reciever.isDeleted": false } }

    );

    pipeline.push(
        { "$sort": { "lastMessage.createdAt": -1 } },
        {
            $project: {
                _id: 0, lastMessage: "$lastMessage", connectionId: "$connectionId",
                fullName: "$user.fullName", image: "$user.image", userId: "$user._id", isBlocked: "$isBlocked", clear: "$clear", status: "$status",
                users: {
                    "firstName": "$user.firstName", "lastName": "$user.lastName", image: "$user.image", _id: "$user._id", countryCode: "$user.countryCode",
                    phone: "$user.phone", userName: "$user.userName"
                },
                user: {
                    "firstName": "$user.firstName", "lastName": "$user.lastName", image: "$user.image", _id: "$user._id", countryCode: "$user.countryCode",
                    phone: "$user.phone", userName: "$user.userName"
                }
            }
        }
    );
    pipeline.push({
        $facet: {
            metadata: [{
                $group: {
                    _id: null,
                    total: { $sum: 1 }
                }
            }],
            chats: [
                { $skip: skip },
                { $limit: limit }
            ]
        }
    }, {
        $project: {
            count: { $arrayElemAt: ['$metadata.total', 0] }, chats: 1
        }
    });
    let chats = await Model.chatMessage.aggregate(pipeline);
    detail.count = chats[0].count;
    detail.chats = chats[0].chats;

    return detail;
}
async function getChatHistory(req) {
    let detail = {};
    let accountType = await common.findAccountType(req);
    if (!accountType) {
        throw process.lang.TYPE_MANDATORY;
    }
    if (req.user.role == 'user') {
        detail.connectionId = await common.findUserWithPendingQuery(req.user, accountType, req.query.type, true);
    }
    let page = req.query.page;
    let size = req.query.limit;
    let skip = parseInt(page - 1) || 0;
    let limit = parseInt(size) || 10;
    skip = skip * limit;
    let pipeline = [];
    let user1 = req.user._id;
    if (req.query.userId) { // super admin case
        user1 = req.query.userId;
    }

    // let user2 = req.query.userId;
    // pipeline.push({ $match: { text: { $ne: null } } });
    pipeline.push({
        $match: {
            $or: [{ recieverId: ObjectId(user1) }, { senderId: ObjectId(user1) }]
        }
    },
        { $match: { isQueryResolved: false } },
        { $match: { isDeleted: false } },
        {
            $lookup: {
                from: "users",
                let: { userId: "$senderId" },
                pipeline: [{
                    $match: {
                        $expr: {
                            $and: [{ $eq: ["$$userId", "$_id"] }]
                        }
                    }
                },
                { $project: { fullName: 1, userName: 1, image: 1, firstName: 1, lastName: 1, role: 1 } }
                ],
                as: "senderId"
            }
        },
        { $unwind: "$senderId" },
        {
            $lookup: {
                from: "users",
                let: { userId: "$recieverId" },
                pipeline: [{
                    $match: {
                        $expr: {
                            $and: [{ $eq: ["$$userId", "$_id"] }]
                        }
                    }
                },
                { $project: { fullName: 1, userName: 1, image: 1, firstName: 1, lastName: 1, role: 1 } }
                ],
                as: "recieverId"
            }
        },
        { $unwind: "$recieverId" },
        {   // admin Id
            $lookup: {
                from: "users",
                let: { userId: "$adminId" },
                pipeline: [{
                    $match: {
                        $expr: { $and: [{ $eq: ["$$userId", "$_id"] }] }
                    }
                },
                { $project: { fullName: 1, userName: 1, image: 1, firstName: 1, lastName: 1, role: 1 } }
                ],
                as: "adminId"
            }
        },
        { $unwind: { path: "$adminId", preserveNullAndEmptyArrays: true } },
        {
            $project: {
                senderId: 1, recieverId: 1, message: 1, latitude: 1, longitude: 1, createdAt: 1, isEscalated: 1,
                text: 1, type: 1, isReaded: 1, uploads: 1, isQueryResolved: 1, queryType: 1, thumbnail: 1, adminId: 1, status: 1
            }
        },
        { $sort: { createdAt: -1 } }
    );

    pipeline = await common.pagination(pipeline, skip, limit);
    let [chats] = await Model.chatMessage.aggregate(pipeline);

    detail.chat = chats;
    return detail;
}
async function getCheckPendingChat(req) {
    let pipeline = [];
    let user1 = req.user._id;
    pipeline.push({
        $match: {
            $or: [{ recieverId: ObjectId(user1) }, { senderId: ObjectId(user1) }]
        }
    },
        { $match: { isQueryResolved: false } },
        { $match: { isDeleted: false } },
        { $sort: { createdAt: -1 } }
    );
    let chats = await Model.chatMessage.aggregate(pipeline);

    let isPendingChat = chats && chats.length > 0 ? true : false;
    return { isPendingChat: isPendingChat };
}
async function getQueryList() {
    return constant.QUERY_TYPE;
}
async function chatAction(req) {
    if (!req.body.connectionId)
        throw process.lang.INVALID_CONNECTION_ID;
    let qry = { connectionId: req.body.connectionId };
    await Model.chatMessage.updateMany(qry, { $set: { isQueryResolved: true } });

    let chat = await Model.chatMessage.findOne(qry);
    if (chat) {
        let user = await Model.user.findOne({ _id: chat.senderId, role: "SUBADMIN" });
        if (user) {
            let subAdminCount = Number(user.queryCount) > 0 ? Number(user.queryCount) - 1 : 0;
            await Model.user.findOneAndUpdate({ _id: user._id }, { $set: { queryCount: subAdminCount } });
        } else {
            user = await Model.user.findOne({ _id: chat.recieverId, role: "SUBADMIN" });

            let subAdminCount = Number(user.queryCount) > 0 ? Number(user.queryCount) - 1 : 0;
            await Model.user.findOneAndUpdate({ _id: user._id }, { $set: { queryCount: subAdminCount } });
        }

        // notify user and subadmin chat is closed case
        process.emit("queryResolved", { userId: chat.senderId });
        process.emit("queryResolved", { userId: chat.recieverId });
    }


}

async function sendChat(req, res) {
    let connectionId = (req.params.id);
    let user = null, chat = null, qry = {
        connectionId: ObjectId(connectionId),
        isDeleted: false
    };
    chat = await Model.chatMessage.findOne(qry).lean();
    user = await Model.user.findOne({ _id: ObjectId(chat.senderId), isDeleted: false, role: "user" });
    if (!user)
        user = await Model.user.findOne({ _id: ObjectId(chat.recieverId), isDeleted: false, role: "user" });
    let pipeline = [];
    qry.connectionId = connectionId;
    pipeline.push({ $match: qry });
    chat = await Model.chatMessage.aggregate(pipeline);
    // chat = JSON.stringify(chat);    
    const subject = "Chat Details";

    let str = await utility.chatNewTemplate(chat, user._id, user.firstName);
    const options = { format: 'A4', path: `./uploads/${connectionId}.pdf` };
    pdf.generatePdf({ content: str }, options)
        .then(pdfBuffer => {
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', 'attachment; filename="generated.pdf"');
            fs1.remove(options.path)
                .then(() => {
                    console.log('File removed successfully');
                })
                .catch((err) => {
                    console.error('Error removing file:', err);
                });
            // Send the PDF buffer as the response
            res.send(pdfBuffer);
        }).catch(error => {

            throw new Error(error);
        });

    return false;
}

/** KYC LIVENESS */

async function getSessionId(req) {
    let sessionId = await ukhesheService.getAwsSessionId(req, req.user);
    return sessionId;
}

async function getAwsConfig(req) {
    let config = await ukhesheService.getAwsConfigFile();
    return config;
}

async function getRatifyResults(req) {
    let sessionId = req.params.sessionId;
    let ratifyResult = await ukhesheService.ratifyWithSessionId(req, req.user, sessionId);
    let kycStatus;
    if (ratifyResult.isSuccess) {
        await Model.user.findOneAndUpdate({ saIdNo: req.user.saIdNo }, {
            $set: {
                profileCompleteAt: 2,
                isProfileComplete: true
            }
        });
        kycStatus = await common.checkKYCStatus(req, req.user, ratifyResult);
        return { isKYCCompleted: kycStatus.isKYCCompleted };
    } else {
        return { isKYCCompleted: false, message: 'KYC FAILED' };
    }
}

async function syncKyc(req, res) {
    let kycData = await ukhesheService.getKycData(req.user);

    const response = await common.checkKYCStatus(req, req.user, kycData);

    return response.data;
}

async function sendOTPtoIdentity(req) {
    let identity;
    let customerId = req.body.customerId;

    if (customerId == undefined) {
        let user = await ukhesheService.getUserFromUksheBySaId(req.body.saIdNo);
        customerId = user[0].customerId;
    }

    if (req.body.hasIdIdentity == true) {
        identity = "BHA-" + req.body.saIdNo;
    } else {
        let response = await ukhesheService.getIdentityOfUser({ ukhesheCustId: customerId });
        identity = response?.data?.length > 1 ? "BHA-" + req.body.saIdNo : response.data[0].identity;
    }

    await smsService.sendSMSToIdentity(identity);

    return {};
}

async function verifySMSToPhone(req, res) {
    let idnetity = 'BHA-' + req.saIdNo;
    let user;
    let setObj = {};

    user = await Model.user.findOne({
        saIdNo: req.saIdNo, isDeleted: false
    });

    let otp = await smsService.verifySMSToPhone(req.code, idnetity);
    if (!otp.isSuccess) {
        throw Object.assign(
            new Error(process.lang.INVALID_OTP),
            {
                message: process.lang.INVALID_OTP,
                newRelicMessage: 'verifyOTP Invalid OTP',
                details: {
                    description: otp.data[0]?.description,
                    saIdNo: req.saIdNo,
                    ukTraceId: otp.data[0]?.traceId,
                    deviceFingerprint: user?.deviceId ?? 'deviceFingerprint not found',
                    deviceType: user?.deviceType ?? 'deviceType not found'
                }
            }
        );
    }
    setObj.isPhoneVerify = true;


    let jti = utility.generateRandomString(20);
    setObj.jti = jti;
    user = await Model.user.findOneAndUpdate({ _id: mongoose.Types.ObjectId(user._id) }, setObj).lean();
    user = await Model.user.findOne({ _id: mongoose.Types.ObjectId(user._id) }).lean();
    user.token = await utility.jwtSign({
        _id: user._id,
        role: user.role,
        jti: jti
    });
    user.type = "Bearer";
    user.expire = await utility.getJwtExpireTime();
    user.refreshToken = await utility.jwtRefreshSign({ _id: user._id });

    return user;
}

async function getWalletProvisions(customerId) {
    try {
        let systemToken = await ukhesheService.createTenantSystemUkhesheToken();

        let config = {
            method: 'GET',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${customerId}/wallet-types`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': systemToken.headerValue
            }
        };
        const response = await axios(config);

        let walletProvisions = response.data;

        let digitalWalletTypeId;
        if (process.env.NODE_ENV == 'dev' || process.env.NODE_ENV == 'qa') {
            digitalWalletTypeId = 1346;
        } else {
            digitalWalletTypeId = 102;
        }

        let digitalWalleProvision = walletProvisions.find(item => item.walletTypeId == digitalWalletTypeId && item.allowed);

        return digitalWalleProvision ? true : false;
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function sendOTPtoNewUser(req) {

    let getUserById = await ukhesheService.getUserFromUksheBySaId(req.body.saIdNo);
    let user = getUserById[0];

    let phone = req.body.key + "";

    if (phone && phone.startsWith("0") || phone.startsWith("27")) {
        if (phone.startsWith("0")) {
            phone = phone.slice(1, phone.length);
        } else if (phone.startsWith("27")) {
            phone = phone.slice(2, phone.length);
        }
    }

    let sendOtp = await Otp.generatePhoneOtp("+27", phone);

    let custId = user.customerId;
    user = await Model.user.findOne({
        saIdNo: req.body.saIdNo, isDeleted: false
    }, {
        saIdNo: 1, role: 1, isBlocked: 1, countryCode: 1, phone: 1, ukhesheCustId: 1, isProfileComplete: 1
    });

    let detail = {};
    detail.saIdNo = req.body.saIdNo;
    detail.ukhesheCustId = custId;
    detail.submitKey = req.body.password;
    detail.deviceId = req.body.deviceId;
    detail.password = await utility.hashPasswordUsingBcrypt(req.body.password);
    detail.phone = phone;
    detail.countryCode = "+27";
    detail.role = 'user';

    if (!user) {
        user = await Model.user.create(detail);
    } else {
        user = await Model.user.findOneAndUpdate({ saIdNo: req.body.saIdNo, isDeleted: false }, detail);
    }

    let jti = utility.generateRandomString(20);
    user.token = await utility.jwtSign({ _id: user._id, role: user.role, jti: jti, email: user.email });
    user.type = "Bearer";
    user.isRequiredPassCode = true;
    user = JSON.parse(JSON.stringify(user));
    delete user.submitKey;
    return user;
}

module.exports = {
    sendChat,
    getCheckPendingChat,
    airtimePayment,
    refreshToken,
    updateStudent,
    getStudent,
    walletToWalletTopUp,
    sendCaptureOtp,
    eftCallbackUrl,
    callBackUrl,
    deletePofile,
    userClearNotification,
    logout,
    createUser,
    setPassword,
    verifyOTP,
    socialLogin,
    _doLogin,
    updateprofile,
    login,
    forgotpassword,
    changePassword,
    dashboard,
    userNotification,
    updatepassCode,
    userDocUpload,
    sendOtp,
    getPofile,
    landing,
    findSaId,
    otp,
    verotp,
    verifyPassCode,
    cardProfileUpdate,
    addHelp,
    getHelp,
    updateHelp,
    addError,
    getError,
    getChatList,
    getChatHistory,
    cardfieldtopup,
    getQueryList,
    chatAction,
    adminDetailUpdate,
    walletWithdrawalCallback,
    getSessionId,
    getAwsConfig,
    getRatifyResults,
    syncKyc,
    sendOTPtoIdentity,
    verifySMSToPhone,
    sendOTPtoNewUser
};