const Model = require("../../models");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
// const Otp = require("./otp");
const notification = require('../../utility/pushNotifications');
// const moment = require('moment-timezone');
const utility = require("../../utility/Utility");
const ukhesheService = require('./ukhesheService');


async function pagination(pipeline, skip, limit) {
    pipeline.push({
        $facet: {
            metadata: [{
                $group: {
                    _id: null,
                    total: {
                        $sum: 1
                    }
                }
            }],
            data: [
                //         { $sort: sort },
                {
                    $skip: skip
                },
                {
                    $limit: limit
                }
            ]
        }
    }, {
        $project: {
            total: {
                $arrayElemAt: ['$metadata.total', 0]
            },
            data: 1
        }
    });
    return pipeline;
}
async function convertMap(obj) {
    return Array.from(obj).reduce((acc, [key, value]) => Object.assign(acc, {
        [key]: value
    }), {});
}
async function addNotification(userId, title, message, reactId, postId, pushType) {
    await Model.notification.create({
        userId: userId,
        title: title,
        message: message,
        reactId: reactId,
        postId: postId,
        pushType: pushType
    });
}
async function sendTagUserNotification(users, sendNotification, userDetail, pushType) {
    if (users && users.length > 0) {
        let user;
        for (let i = 0; i < users.length; i++) {
            const e = users[i];
            if (userDetail && userDetail == true) {
                user = e;
            } else {
                user = await Model.user.findOne({
                    _id: ObjectId(e),
                    isDeleted: false
                });
            }
            if (user) {
                if (user.deviceToken && user.deviceToken.length > 0) {
                    await addNotification(user._id, sendNotification.title, sendNotification.message, pushType);
                    sendNotification.userId = user._id;
                    await notificationAccDevice(user, sendNotification);
                }
            }
        }
    }
}
async function notificationAccDevice(user, sendNotification) {
    if (user.deviceType == 'IOS') {
        await notification.sendNotificationToIos(sendNotification, user.deviceToken);
    } else if (user.deviceType == 'ANDROID') {
        await notification.sendNotification(sendNotification, user.deviceToken);
    }
}

async function checkKYCStatus(req, user, kycData) {
    let kycStatus = await ukhesheService.kycStatusFromWalletProvisions(req, user);
    kycData = kycData?.data;

    let isSelfiePassed = kycData.selfieIsASelfie.passed;
    let selfieIsLegitimate = kycData.selfieIsLegitimate.passed;
    let selfieMatchesIdentity = passed(kycData.selfieMatchesNationalIdentity);
    let selfieMatchesDatabase = passed(kycData.selfieMatchesNationalDatabase);
    let firstNameMatches = passed(kycData.firstNameMatchesNationalIdentity);
    let lastNameMatches = passed(kycData.lastNameMatchesNationalIdentity);

    let selfieChecksPassed = isSelfiePassed && selfieIsLegitimate;
    let idChecksPassed = passed(kycData.identityNumberMatchesNationalIdentity) && passed(kycData.nationalIdentityIsANationalIdentity) && passed(kycData.nationalIdentityIsLegitimate) && passed(kycData.dateOfBirthMatchesNationalIdentity) && firstNameMatches && lastNameMatches;

    let isSelfieMatches = isSelfiePassed && selfieIsLegitimate && selfieMatchesIdentity && selfieMatchesDatabase;
    let identityNumberMatches = passed(kycData.identityNumberMatchesNationalIdentity) && passed(kycData.nationalIdentityIsANationalIdentity) && passed(kycData.nationalIdentityIsLegitimate) && passed(kycData.dateOfBirthMatchesNationalIdentity);
    let checkKYCStatus = await isAlltrue(isSelfieMatches, firstNameMatches, identityNumberMatches, lastNameMatches);

    await Model.user.findOneAndUpdate({
        _id: user._id
    }, {
        $set: {
            isKYCCompleted: kycStatus,
            selfieIsASelfie: isSelfiePassed,
            selfieIsLegitimate: selfieIsLegitimate,
            selfieMatchesIdentity: selfieMatchesIdentity,
            firstNameMatchesIdentity: firstNameMatches,
            lastNameMatchesIdentity: lastNameMatches,
            identityNumberMatchesIdentity: identityNumberMatches,
            idChecksPassed: idChecksPassed,
            selfieChecksPassed: selfieChecksPassed
        }
    });

    return {
        isKYCCompleted: kycStatus,
        selfieIsASelfie: isSelfiePassed,
        selfieIsLegitimate: selfieIsLegitimate,
        selfieMatchesIdentity: isSelfieMatches,
        firstNameMatchesIdentity: firstNameMatches,
        lastNameMatchesIdentity: lastNameMatches,
        identityNumberMatchesIdentity: identityNumberMatches,
        idChecksPassed: idChecksPassed,
        selfieChecksPassed: selfieChecksPassed
    };

}

function passed(kycField) {
    return kycField?.checked ? kycField?.passed : true;
}

async function istrue(v1, v2, v3, v4) {
    if (v1 || v2 || v3 || v4) {
        return true;
    } else {
        return false;
    }
}

async function isAlltrue(v1, v2, v3, v4) {
    if (v1 && v2 && v3 && v4) {
        return true;
    } else {
        return false;
    }
}


async function withoutSecrectApi(req) {
    let originalUrl = req.originalUrl + "".toLowerCase();

    if (originalUrl.includes('/student')
        || originalUrl.includes('/eftcallbackurl')
        || originalUrl.includes('/cardfieldtopup')
        || originalUrl.includes('/cardcallbackurl')
        || originalUrl.includes('/landing')
        || originalUrl.includes('/wtwtopup')
        || originalUrl.includes('/walletWithdrawal')
        || originalUrl.includes('/transactioncallback')
        || originalUrl.includes('/product')
        || originalUrl.includes('/sales')
        || originalUrl.includes('/cms')
        || originalUrl.includes('/downloadChat')
        || originalUrl.includes('/test')
        || originalUrl.includes('/error')
        || originalUrl.includes('/faq')) {
        return true;
    }
    return false;
}


async function getUserName(user) {
    let name = '';
    if (user) {
        if (user.firstName) {
            name = user.firstName;
        }
        if (user.lastName) {
            name = name + " " + user.lastName;
        }
    }
    return name;
}
async function findAccountType(req) {
    return req.headers["type"];
}
async function getAdminAccount(type) {
    return await Model.user.findOne({ role: "ADMIN", isDeleted: false, userType: type }).lean();
}
async function getSubAdminAccount(type) {
    // logic of sub-admins 
    let subadmin = await Model.user.find({ role: "SUBADMIN", isDeleted: false, userType: type }).sort({ queryCount: 1 }).lean();
    if (subadmin.length > 0) {
        return subadmin[0];
    } else {
        throw process.lang.SUB_ADMIN_NOT_FOUND;
    }
}

async function findUserWithPendingQuery(user, type, queryType, sendNotification) {
    let qry = {};
    let user1 = user._id;
    qry = {
        $or: [{ senderId: ObjectId(user1) }, { recieverId: ObjectId(user1) }],
        isQueryResolved: false, isDeleted: false, accountType: type
    };
    let oldChat = await Model.chatMessage.findOne(qry);
    if (oldChat) {
        return oldChat.connectionId;
    }

    let user2 = await getSubAdminAccount(type);
    let subAdminCount = Number(user2.queryCount) + 1;
    await Model.user.findOneAndUpdate({ _id: user2._id }, { $set: { queryCount: subAdminCount } });

    let supportAgent = user2.firstName + (user2.lastName ? " " + user2.lastName : "");
    user2 = user2._id;
    qry = {
        $or: [
            { senderId: ObjectId(user1), recieverId: ObjectId(user2) },
            { senderId: ObjectId(user2), recieverId: ObjectId(user1) }
        ],
        isQueryResolved: false, isDeleted: false, accountType: type
    };
    let chat = await Model.chatMessage.findOne(qry);
    if (!chat) {
        let data = {
            recieverId: mongoose.Types.ObjectId(user1),
            senderId: mongoose.Types.ObjectId(user2),
            connectionId: utility.generateRandomString(12),
            clearedBy: [],
            isQueryResolved: false, isDeleted: false, queryType: queryType,
            assign: 'AUTO_ASSIGN', accountType: type,
            // text: `Hi ${user.fullName} your support agent is ${supportAgent}`
            text: `Hi, ${supportAgent} is your support agent`,
            status: "In progress"
        };
        chat = await Model.chatMessage.create(data);
        if (user2 && sendNotification) {
            let notification = {
                userId: user2._id,
                pushType: 5,
                title: "You have a New chat assigned",
                message: "You have a New chat assigned",
                isSaved: true,
                type: 'SubAdmin',
                userType: 'SubAdmin',
                deviceToken: user2.deviceToken,
                deviceType: user2.deviceType
            };
            let adminData = await Model.user.findOne({ role: "ADMIN", isDeleted: false, userType: type }).lean();
            process.emit("sendNotification", notification);
            process.emit("notificationCount", { userId: user2._id, adminId: String(adminData._id) });
        }
    }

    return chat.connectionId;
}

async function getSimplePhoneNo(ph) {
    if (ph && ph.startsWith("0") || ph.startsWith("27") || ph.startsWith("+27")) {
        if (ph.startsWith("0")) {
            ph = ph.slice(1, ph.length);
        } else if (ph.startsWith("27")) {
            ph = ph.slice(2, ph.length);
        } else if (ph.startsWith("+27")) {
            ph = ph.slice(3, ph.length);
        }
    }
    return ph;
}
async function escalate(data) {
    let admin = await Model.user.findOne({ isDeleted: false, role: 'ADMIN', userType: data.accountType });
    // if (!subAdmin) throw process.lang.SUBADMIN_NOT_FOUND;

    let connectionId = await Model.chatMessage.findOne({ connectionId: data.connectionId, isDeleted: false });
    if (!connectionId) throw process.lang.INVALID_CONNECTION_ID;

    await Model.chatMessage.updateMany({ connectionId: data.connectionId }, { $set: { isEscalated: true } });

    let details = {
        senderId: mongoose.Types.ObjectId(connectionId.senderId),
        recieverId: mongoose.Types.ObjectId(connectionId.recieverId),
        adminId: mongoose.Types.ObjectId(admin._id),
        connectionId: connectionId.connectionId,
        clearedBy: [],
        isEscalated: true,
        text: `Your query has been excalated to admin.`,
        queryType: connectionId.queryType,
        assign: connectionId.assign,
        status: connectionId.status,
        accountType: connectionId.accountType
    };
    await Model.chatMessage.create(details);

    return { isSuccess: true };
}
module.exports = {
    escalate,
    pagination,
    convertMap,
    addNotification,
    sendTagUserNotification,
    notificationAccDevice,
    checkKYCStatus,
    withoutSecrectApi,
    getUserName,
    getAdminAccount,
    findUserWithPendingQuery,
    getSubAdminAccount,
    getSimplePhoneNo,
    findAccountType
};