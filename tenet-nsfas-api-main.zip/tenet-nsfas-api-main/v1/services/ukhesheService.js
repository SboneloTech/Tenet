const axios = require('axios');
const fileUpload = require('./fileUpload');
const fs = require('fs');
const Model = require("../../models");
const constant = require('../../utility/constant');
const moment = require("moment");
const NodeCache = require("node-cache");
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const ukhesheCache = new NodeCache();

function isExpired() {
    const now = moment().valueOf();
    const exp = ukhesheCache.get('expires');
    if (exp == undefined) return true;
    return now > exp;
}

function isSystemExpired() {
    const now = moment().valueOf();
    const exp = ukhesheCache.get('systemTokenexipries');
    if (exp == undefined) return true;
    return now > exp;
}

async function authenticate() {
    try {

        let body = JSON.stringify({
            "identity": process.env.UKHESHE_USERNAME,
            "password": process.env.UKHESHE_PASSWORD
        });

        let config = {
            method: 'post',
            url: process.env.UKHESHE_BASE_URL + '/eclipse-conductor/rest/v1/authentication/login',
            headers: {
                'Content-Type': 'application/json'
            },
            data: body
        };

        const authenticationResult = await axios(config);
        let authToken = authenticationResult.data.headerValue.replace(/^bearer\s+/i, "");

        const newTime = moment().add(10, 'minutes');
        const newTimestamp = newTime.valueOf();

        ukhesheCache.set('accessToken', authToken);
        ukhesheCache.set('expires', newTimestamp);
        console.log('Onboarding User AccessToken ---> ready');

    } catch (err) {
        console.error('Onboarding User AccessToken ---> FAILED');
        throw err;
    }
}

async function getAccessToken() {
    if (isExpired()) {
        // RENEW ACCESS TOKEN
        await authenticate();
    }
    return ukhesheCache.get('accessToken');
}

async function authenticateSystemUser() {
    try {
        let identity = process.env.TENANT_SYSTEM_USERNAME;
        let password = process.env.TENANT_SYSTEM_PASSWORD;

        let body = JSON.stringify({
            "identity": identity,
            "password": password
        });

        let config = {
            method: 'post',
            url: process.env.UKHESHE_BASE_URL + '/eclipse-conductor/rest/v1/authentication/login',
            headers: {
                'Content-Type': 'application/json'
            },
            data: body
        };

        const authenticationResult = await axios(config);
        let authToken = authenticationResult.data.headerValue.replace(/^bearer\s+/i, "");

        const newTime = moment().add(10, 'minutes');
        const newTimestamp = newTime.valueOf();

        ukhesheCache.set('systemAccessToken', authToken);
        ukhesheCache.set('systemTokenexipries', newTimestamp);
        console.log('System User AccessToken ---> ready');

    } catch (err) {
        console.error('System User AccessToken ---> FAILED');
        throw err;
    }
}

async function createSystemUkhesheToken() {
    if (isSystemExpired()) {
        // RENEW ACCESS TOKEN
        await authenticateSystemUser();
    }
    return ukhesheCache.get('systemAccessToken');
}


async function getDammyKey() {
    // return process.env.UKHESHE_TENANT_ID_IDENTITY + "-";
    return "BHA-";
}

async function createUserIdentity(saIdNo) {
    return await getDammyKey() + saIdNo;
}

async function formatPhoneNumber(phone) {
    let _phone = phone.replace('+', '');

    if (_phone.startsWith('0')) {
        _phone = '27' + _phone.slice(1);
    }

    if (!_phone.startsWith('27')) {
        _phone = '27' + _phone;
    }

    return await _phone;
}



async function createkhesheToken(isForSibusisu) {
    try {
        let token = await getAccessToken();
        let authorization = `Bearer ${token}`;

        return { headerValue: authorization };
    } catch (error) {
        console.log(error);
    }
}

async function createTenantSystemUkhesheToken(isForSibusisu) {
    try {
        let token = await createSystemUkhesheToken();
        let authorization = `Bearer ${token}`;

        return { headerValue: authorization };
    } catch (error) {
        console.log(error);
    }
}

async function createUkhesheUser(data, user) { // using for create ukheshe user
    try {
        let token = await createkhesheToken();

        let _phone = await formatPhoneNumber(data.phone);

        let body = JSON.stringify({
            "email": user.email,
            "externalUniqueId": data.ukhesheExternalCustId,
            "firstName": data.firstName ? data.firstName : "",
            "lastName": data.lastName ? data.lastName : "",
            "phone1": _phone,
            "status": "ACTIVE",
            "gender": "M"
        });

        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: body
        };
        const response = await axios(config);
        return response.data;
    } catch (error) {
        return {};
    }
}

async function updateUkhesheUser(req, data, user, userToken) { // using for update ukheshe user    
    try {
        let token = await generateUkhsheTokenMySide(req, userToken);
        let ukhesheUser = await getUserDetail(user, token);

        let _phone = user.isProfileComplete == true ? ukhesheUser.phone1 : await formatPhoneNumber(data.phone);

        let payload = {
            "email": user.email,
            "firstName": data.firstName ? data.firstName : "",
            "lastName": data.lastName ? data.lastName : "",
            "phone1": _phone,
            "status": "ACTIVE",
            "gender": data.gender,
            "maritalStatus": data.maritalStatus,
            "dateOfBirth": data.dateOfBirth,
            "nationalIdentityNumber": ukhesheUser.nationalIdentityNumber,
            "version": Number(ukhesheUser.version),
            "title": data.title
        };

        let body = JSON.stringify(payload);

        let config = {
            method: 'put',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: body
        };

        const response = await axios(config);

        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (error.response ? (error.response.data ?? error.response.message) : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function addDocumentkhesheUser(req, user, document, isSelfie) { // Add  a new document against the customer
    let docType = "AUTO";
    let type = document.doc_type;
    if (type == constant.DOC_TYPE.SOUTH_AFRICA_ID) {
        docType = "NATIONAL_IDENTITY";
    } else {
        docType = "PASSPORT";
    }
    document = document.document;

    let token = await generateUkhsheTokenMySide(req, user);

    if (isSelfie) {
        docType = "FACIAL_PHOTO";
    }
    try {
        let data = JSON.stringify({
            "documentType": docType,
            "mediaType": "image/jpeg",
            "base64EncodedDocument": await base64_encodeOfImage(document)
        });

        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}/documents`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: data
        };

        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function base64_encodeOfImage(file) {
    file = await fileUpload.fileDownload(file);
    let bitmap = fs.readFileSync(file);
    return new Buffer(bitmap).toString('base64');
}

async function runUkhesheAlgo({ req, user, userToken }) { // Run a KYC algorithm on the customers profile to update the KYC status.
    let token = userToken || await generateUkhsheTokenMySide(req, user);

    let data = JSON.stringify({});
    try {
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}/ratify`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: data
        };

        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return { data: error, isSuccess: false };
    }
}

async function deleteUser(user) {
    let token = await createkhesheToken();
    try {
        let config = {
            method: 'delete',
            // url: `https://eclipse-java-sandbox.ukheshe.rocks/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}`,
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}`,
            headers: {
                'Authorization': token.headerValue
            }
        };
        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function deleteUserDocument(req, user, docId) {
    let token = await generateUkhsheTokenMySide(req, user);

    try {
        let config = {
            method: 'delete',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/documents/${docId}`,
            headers: {
                'Authorization': token.headerValue
            }
        };
        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function deleteUserDocumentLocalAndUkshe(req, user, allDocs) {
    for (const row of allDocs) {
        if (row.ukhesheDocId) {
            await deleteUserDocument(req, user, row.ukhesheDocId);
        }
    }
    await Model.userDocument.updateMany({ userId: user._id, isDeleted: false }, { isDeleted: true });
}

async function getUserDetail(user, token) {
    let config = {
        method: 'get',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}`,
        headers: {
            'Authorization': token.headerValue
        }
    };
    const response = await axios(config);
    return response.data;
}

async function getUserFromUksheBySaId(saIdNo) {
    let token = await createkhesheToken(true);

    let config = {
        method: 'get',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers?fields=customerId&nationalIdentityNumber=${saIdNo}`,
        headers: {
            'Authorization': token.headerValue
        }
    };
    const response = await axios(config);
    // let token = await createkhesheToken(true);
    // let config = {
    //     method: 'get',
    //     url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers?limit=10&nationalIdentityNumber=${saIdNo}&offset=0`,
    //     headers: {
    //         'Authorization': token.headerValue
    //     }
    // };
    // const response = await axios(config);
    return response.data;
}

async function walletsTransfer(req, payload, user, isForRefund) {
    let token;
    if (isForRefund) {
        token = await createkhesheToken(true);
    } else {
        let accessToken = req.headers["ukheshetoken"];
        token = {
            headerValue: accessToken
        };
    }
    try {
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/transfers`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: payload
        };
        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    }
    catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function getUserFromUksheByPhoneNo(phoneNo) {
    try {
        let token = await createkhesheToken();
        let config = {
            method: 'get',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers?limit=10&phone1=${phoneNo}&offset=0`,
            headers: {
                'Authorization': token.headerValue
            }
        };
        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function updateCardDetailUkhesheUser(req, data, user) { // using for update ukheshe user
    try {
        let accessToken = req.headers["ukheshetoken"];
        let token = {
            headerValue: accessToken
        };
        let ukhesheUser = await getUserDetail(user, token);
        let _phone = await formatPhoneNumber(user.phone);

        let body = JSON.stringify({
            "email": ukhesheUser.email,
            "firstName": ukhesheUser.firstName,
            "lastName": ukhesheUser.lastName,
            "phone1": ukhesheUser.phone1,
            "status": "ACTIVE",
            "gender": ukhesheUser.gender,
            "maritalStatus": ukhesheUser.maritalStatus,
            "dateOfBirth": ukhesheUser.dateOfBirth,
            "nationalIdentityNumber": ukhesheUser.nationalIdentityNumber,
            "version": Number(ukhesheUser.version),
            "title": ukhesheUser.title
        });

        if (data.addressDetail) {
            body = JSON.stringify({
                "email": ukhesheUser.email,
                "firstName": ukhesheUser.firstName,
                "lastName": ukhesheUser.lastName,
                "phone1": ukhesheUser.phone1,
                "status": "ACTIVE",
                "gender": ukhesheUser.gender,
                "maritalStatus": ukhesheUser.maritalStatus,
                "dateOfBirth": ukhesheUser.dateOfBirth,
                "line1": data.addressDetail.line1,
                "addressType": data.addressDetail.addressType,
                "city": data.addressDetail.city,
                "country": data.addressDetail.country,
                "state": data.addressDetail.state,
                "nationalIdentityNumber": ukhesheUser.nationalIdentityNumber,
                "version": Number(ukhesheUser.version)
            });
        }

        let config = {
            method: 'put',
            // url: `https://eclipse-java-sandbox.ukheshe.rocks/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}`,
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: body
        };
        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function updateAddressDetailUkhesheUser(req, data, user) { // using for update ukheshe user
    try {
        let accessToken = req.headers["ukheshetoken"];

        let body = JSON.stringify({
            "line1": data.addressDetail.line1,
            "addressType": data.addressDetail.addressType,
            "city": data.addressDetail.city,
            "country": data.addressDetail.country,
            "state": data.addressDetail.state,
            "code": data.addressDetail.code
        });


        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}/addresses`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': accessToken
            },
            data: body
        };
        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function createIdentityOfUser(data) { // using for create Identity in ukheshe user
    try {
        let token = await createTenantSystemUkhesheToken();
        let identity = await createUserIdentity(data.saIdNo);
        let body = JSON.stringify({
            "identity": identity.trim(),
            "password": data.password
        });
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${data.ukhesheCustId}/identities`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: body
        };
        let response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function customerHasIdentities(data) {
    try {
        let token = await createkhesheToken(true);
        let config = {
            method: 'head',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${data.ukhesheCustId}/identities`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            }
        };
        let response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function getIdentityOfUser(data) { // using for create Identity in ukheshe user
    try {
        let token = await createTenantSystemUkhesheToken();
        let config = {
            method: 'get',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${data.ukhesheCustId}/identities`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            }
        };
        let response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function deleteIdentityOfUser(data) { // using for delete Identity in ukheshe user
    try {
        let token = await createkhesheToken(true);
        let identity = await getDammyKey() + data.saIdNo;
        let config = {
            method: 'delete',
            // https://eclipse-java-sandbox.ukheshe.rocks/eclipse-conductor/rest/v1/tenants/5648/customers/1212/identities/14141
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${data.ukhesheCustId}/identities/${identity}`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            }
        };
        let response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}
async function deleteAddressOfUser(req, data, user) { // using for delete Address in ukheshe user
    try {
        let accessToken = req.headers["ukheshetoken"];

        let config = {
            method: 'delete',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/addresses/${data.addressId}`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': accessToken
            }
        };
        let response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}
async function updatePasswordInUkshe(req, data, user, isDeleteIdentity) { // using for update password from ukheshe user    
    try {
        let token = await generateUkhsheTokenMySide(req, user);

        let body = JSON.stringify({
            "password": data.password
        });

        let identity = await createUserIdentity(user.saIdNo);

        let config = {
            method: 'put',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${data.ukhesheCustId}/identities/${identity}`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: body
        };
        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}
async function getIdentityFromUkheshe(data) { // using for getting Identity from ukheshe user
    try {
        let token = await createTenantSystemUkhesheToken();
        let identitiy = await getDammyKey() + data.saIdNo;

        let config = {
            method: 'get',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${data.customerId}/identities/${identitiy}`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            }
        };
        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function generateUkhsheTokenMySide(req, user) {
    try {
        let identity = await createUserIdentity(user.saIdNo);

        // Device override for Play Store testing
        let deviceId;
        if (req.headers["devicetype"] == 'WEB' || req.headers.devicetype == 'WEB' || user.saIdNo == '9303115689084') {
            deviceId = process.env.UKHESHE_DEVICE_OVERRIDE;
        } else {
            // TODO: Send device Id in req for document upload and selfie upload;
            deviceId = process.env.UKHESHE_DEVICE_OVERRIDE;
        }

        let body = JSON.stringify({
            "identity": identity,
            "password": user.submitKey,
            "deviceFingerprint": deviceId
        });
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/authentication/login`,
            headers: {
                'Content-Type': 'application/json'
            },
            data: body
        };
        let response = await axios(config);
        return response.data;
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function generateUkhsheTokenOverride(user) {
    try {
        let phone;
        if (user.identityPhone) {
            phone = user.identityPhone;
        } else {
            phone = user.phone;
        }
        let identity = await createUserIdentity(phone);
        let body = JSON.stringify({
            "identity": identity,
            "password": user.submitKey,
            "deviceFingerprint": process.env.UKHESHE_DEVICE_OVERRIDE
        });
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/authentication/login`,
            headers: {
                'Content-Type': 'application/json'
            },
            data: body
        };
        let response = await axios(config);
        return response.data;
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function generateUkhsheTokenWithOTP(req, user) {
    try {
        let identitiy = await createUserIdentity(user.phone);

        let deviceId;
        if (req.headers["devicetype"] == 'WEB' || req.headers.devicetype == 'WEB') {
            deviceId = process.env.UKHESHE_DEVICE_OVERRIDE;
        } else {
            deviceId = req.body.deviceId;
        }

        let body = JSON.stringify({
            "identity": identitiy,
            "password": user.submitKey,
            "otp": user.otp,
            "deviceFingerprint": deviceId
        });
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/authentication/login`,
            headers: {
                'Content-Type': 'application/json'
            },
            data: body
        };
        let response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function generateUkhsheToken(req) {
    let data = req.body;
    try {
        let user = await Model.user.findOne({ saIdNo: data.saIdNo, isDeleted: false }).select("+submitKey").lean();

        if (!user) {
            return { isUserNotFound: true };
        }

        let identitiy = await createUserIdentity(user.saIdNo);

        // Device override for Play Store testing
        let deviceId;
        if (req.headers["devicetype"] == 'WEB' || req.headers.devicetype == 'WEB' || user.saIdNo == '9303115689084') {
            deviceId = process.env.UKHESHE_DEVICE_OVERRIDE;
        } else {
            deviceId = data.deviceId;
        }

        let body = JSON.stringify({
            "identity": identitiy,
            "password": user.submitKey,
            deviceFingerprint: deviceId

        });
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/authentication/login`,
            headers: {
                'Content-Type': 'application/json'
            },
            data: body
        };
        let response = await axios(config);

        return { data: response.data, isSuccess: true };
    } catch (error) {
        const configData = JSON.parse(error.config?.data);
        return {
            data: (error.response?.data),
            configData: configData.identity,
            isSuccess: false
        };
    }
}

async function deleteDeviceFromUkhshe(data) {
    try {
        let token = await createkhesheToken(true);
        let res = await getDeviceFingerPrintFromUkhshe(data, token);
        let ids = res.data[0];
        if (ids) {
            let config = {
                method: 'delete',
                url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${data.ukhesheCustId}/device-fingerprints/${ids.deviceFingerprintId}`,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': token.headerValue
                }
            };
            let response = await axios(config);
            return { data: response.data, isSuccess: true };
        }
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function getDeviceFingerPrintFromUkhshe(data, token) {
    try {
        let config = {
            method: 'get',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${data.ukhesheCustId}/device-fingerprints`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            }
        };
        let response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}

async function createReservation(req, payload, user) {
    let accessToken = req.headers["ukheshetoken"];

    let reservationData = {
        amount: payload.amount,
        sessionId: crypto.randomUUID(),
        expires: moment().add(5, 'minutes').toISOString()
    };

    try {
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${payload.walletId}/reservations`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': accessToken
            },
            data: reservationData
        };
        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    }
    catch (error) {
        return {
            data: (
                error.response
                    ? (error.response.data ?? error.response.message)
                    : error.message), isSuccess: false, stack: error.stack?.toString().substring(0, 1000)
        };
    }
}
async function deleteReservation(payload) {
    let token = await createTenantSystemUkhesheToken();

    try {
        let config = {
            method: 'delete',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/wallets/${payload.walletId}/reservations/${payload.reservationId}`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            }
        };
        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    }
    catch (error) {
        return { data: error, isSuccess: false };
    }
}


async function getKycData(user) {
    let token = await createTenantSystemUkhesheToken();

    try {
        let config = {
            method: 'get',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}/ratify?limit=1&offset=0`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            }
        };

        const response = await axios(config);
        return { data: response.data[0], isSuccess: true };
    } catch (error) {
        return { data: error, isSuccess: false };
    }
}

async function getAwsSessionId(req, user) {
    req.body.deviceId = user.deviceId;
    let token = await generateUkhsheTokenMySide(req, user);

    let body = JSON.stringify({
        "documentType": "FACIAL_PHOTO",
        "base64EncodedDocument": "AWS_LIVENESS_CHECK",
        "mediaType": "image/jpeg"
    });
    try {
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}/documents?performOcr=false&validateDocType=false`,
            headers: {
                'accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: body
        };

        const response = await axios(config);
        return { ...response.data, isSuccess: true };
    } catch (error) {
        return { data: error, isSuccess: false };
    }
}
async function getAwsConfigFile() {
    let token = await createTenantSystemUkhesheToken();
    try {
        //public.jwt.protected.aws.amplify.config.sandbox
        //public.jwt.protected.aws.amplify.config.live
        let config = {
            method: 'get',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/global/config/public.jwt.protected.aws.amplify.config.sandbox`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            }
        };

        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return { data: error, isSuccess: false };
    }

}
async function ratifyWithSessionId(req, user, sessionId) {
    req.body.deviceId = user.deviceId;
    let token = await generateUkhsheTokenMySide(req, user);

    let body = JSON.stringify({
        awsFaceLivenessSessionId: `${sessionId}`
    });
    try {
        let config = {
            method: 'post',
            url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}/ratify`,
            headers: {
                'accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': token.headerValue
            },
            data: body
        };

        const response = await axios(config);
        return { data: response.data, isSuccess: true };
    } catch (error) {
        return { data: error, isSuccess: false };
    }

}

async function getWalletProvisions(req, user, token) {
    
    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}/wallet-types`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token.headerValue
        }
    };
    const response = await axios(config);
    return response.data;
}

async function kycStatusFromWalletProvisions(req, user) {
    let token = await generateUkhsheTokenMySide(req, user);

    if (token.isSuccess == false) {
        let error = token.data[0]?.code == 'USR002' ? 'Invalid Credentials' : (token.data[0]?.description ?? 'Login failed');
        throw Object.assign(
            new Error(error),
            {
                message: error,
                newRelicMessage: 'Ukheshe Token Failed: Invalid Credentials',
                details: {}
            }
        );
    }
    
    let walletProvisions = await getWalletProvisions(req, user, token);

    let digitalWalletTypeId;
    if (process.env.NODE_ENV == 'dev' || process.env.NODE_ENV == 'qa') {
        digitalWalletTypeId = 1346;
    } else {
        digitalWalletTypeId = 102;
    }

    let digitalWalleProvision = walletProvisions.find(item => item.walletTypeId == digitalWalletTypeId && item.allowed);

    let kycStatus = digitalWalleProvision ? true : false;

    if (kycStatus == false) {
        await updateProfileCompletionStatus(user, token);
    }
    return kycStatus;
}

async function updateProfileCompletionStatus(user, token) {
    let ukhesheUser = await getUserDetail(user, token);

    if (ukhesheUser.profileCompletionStatus == 0) {
        return { data: ukhesheUser, isSuccess: true };
    } 

    let systemToken =  await createTenantSystemUkhesheToken();
    let body = JSON.stringify({
        "email": ukhesheUser.email,
        "firstName": ukhesheUser.firstName,
        "lastName": ukhesheUser.lastName,
        "phone1": ukhesheUser.phone1,
        "status": ukhesheUser.status,
        "gender": ukhesheUser.gender,
        "maritalStatus": ukhesheUser.maritalStatus,
        "dateOfBirth": ukhesheUser.dateOfBirth,
        "nationalIdentityNumber": ukhesheUser.nationalIdentityNumber,
        "version": Number(ukhesheUser.version),
        "profileCompletionStatus": 0,
        "title": ukhesheUser.title
    });

    let config = {
        method: 'put',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/tenants/${process.env.UKHESHE_TENANT_ID}/customers/${user.ukhesheCustId}`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': systemToken.headerValue
        },
        data: body
    };
    const response = await axios(config);
    return { data: response.data, isSuccess: true };
}


module.exports = {
    generateUkhsheTokenMySide,
    generateUkhsheTokenOverride,
    generateUkhsheTokenWithOTP,
    getDeviceFingerPrintFromUkhshe,
    deleteDeviceFromUkhshe,
    generateUkhsheToken,
    getIdentityFromUkheshe,
    createIdentityOfUser,
    getIdentityOfUser,
    updatePasswordInUkshe,
    updateAddressDetailUkhesheUser,
    updateCardDetailUkhesheUser,
    walletsTransfer,
    getUserFromUksheBySaId,
    deleteUserDocumentLocalAndUkshe,
    deleteUserDocument,
    createUkhesheUser,
    updateUkhesheUser,
    createkhesheToken,
    addDocumentkhesheUser,
    base64_encodeOfImage,
    runUkhesheAlgo,
    deleteUser,
    getUserDetail,
    getUserFromUksheByPhoneNo,
    deleteIdentityOfUser,
    deleteAddressOfUser,
    customerHasIdentities,
    createReservation,
    createUserIdentity,
    deleteReservation,
    createTenantSystemUkhesheToken,
    getKycData,
    getAwsSessionId,
    getAwsConfigFile,
    ratifyWithSessionId,
    authenticate,
    authenticateSystemUser,
    kycStatusFromWalletProvisions
};