const winston = require('winston');
const { AsyncLocalStorage } = require('node:async_hooks');
const { combine, errors, json } = winston.format;

let traceId = '';
const logger = winston.createLogger({
    level: 'info',
    format: combine(
        errors({ stack: true }),
        json()
    ),
    transports: [
        //
        // - Write all logs with importance level of `error` or less to `error.log`
        // - Write all logs with importance level of `info` or less to `combined.log`
        //
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
        new winston.transports.File({ filename: 'combined.log' })
    ]
});

function log(message, data, level = 'info', reqId = null) {
    traceId = reqId ?? traceId;
    logger.log(level, message, { traceIds: { traceId }, details: { ...data } });
}

function info(message, data, reqId = null) {
    log(message, data, 'info', reqId);
}

function error(message, data, reqId = null) {
    log(message, data, 'error', reqId);
}

module.exports = {
    info, error
};