const axios = require('axios');


async function createkhesheToken(isForSibusisu) {
    try {
        let identity = process.env.UKHESHE_USERNAME;
        let password = process.env.UKHESHE_PASSWORD;

        // if (isForSibusisu) {
        //     identity = process.env.UKHESHE_DIMBA_USERNAME;
        //     password = process.env.UKHESHE_DIMBA_PASSWORD;
        // }
        let body = JSON.stringify({
            // "identity": process.env.UKHESHE_USERNAME,
            // "password": process.env.UKHESHE_PASSWORD
            "identity": identity,
            "password": password
        });

        let config = {
            method: 'post',
            url: process.env.UKHESHE_BASE_URL + '/eclipse-conductor/rest/v1/authentication/login',
            headers: {
                'Content-Type': 'application/json'
            },
            data: body
        };

        const response = await axios(config);
        return response.data;
    } catch (error) {
        console.log(error);
    }
}


module.exports = {
    createkhesheToken
};