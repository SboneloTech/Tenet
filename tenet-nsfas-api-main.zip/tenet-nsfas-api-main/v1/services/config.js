const Model = require("../../models");
const responseCode = require("../../utility/responseCode");
const Otp = require("./otp");
const config = require('config');
const utility = require("../../utility/Utility");
const mongoose = require("mongoose");
const airtime = require("./airTime");
const common = require("./common");
const moment = require("moment");
const constant = require("../../utility/constant");
const ukhesheService = require('./ukhesheService');
var pdf = require('html-pdf-node');
var path = require("path");
// const notification = require('../../utility/pushNotifications');
const ObjectId = mongoose.Types.ObjectId;
const fileUpload = require("./fileUpload");
const request = require("request");
const fs = require('fs');
const fs1 = require('fs-extra');
var aws = require('aws-sdk');
const { execSync } = require('child_process');
const axios = require('axios');
const NodeCache = require('node-cache');
const cache = new NodeCache();

aws.config.update({
    region: process.env.APP_CONFIG_REGION
});

const appConfigData = new aws.AppConfigData();

async function getBankList(req,res) {
    let accessToken = req.headers["ukheshetoken"];

    let config = {
        method: 'GET',
        url: `${process.env.UKHESHE_BASE_URL}/eclipse-conductor/rest/v1/global/config/public.bank.list`,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': accessToken
        }
    };
    const response = await axios(config);
    return response.data;
}

async function getVersionData(req) {
    // console.log(req.params);
    // const key = `version_${req.params.deviceType.toUpperCase()}`;

    // if (cache.get(key)) {
    //     const ts = cache.getTtl( key );
    //     console.log(`Found version for ${req.params.deviceType.toUpperCase()} - Time remaining ${ts}`);

    //     return cache.get(key);
    // }

    // console.log(`Failed to find version for ${req.params.deviceType.toUpperCase()}`);

    // const appConfig = new aws.AppConfig();

    // const getConfigPromise = () => {

    //     return new Promise((resolve, reject) => {

    //         const params = {
    //             Application: process.env.APP_CONFIG_APPLICATION_ID,
    //             Environment: process.env.APP_CONFIG_ENVIRONMENT_ID,
    //             Configuration: process.env.APP_CONFIG_CONFIGURATION_ID,
    //             ClientId: process.env.CLIENT_ID
    //         };

    //         appConfig.getConfiguration(params, (err, data) => {
    //             if (err) {
    //                 reject(err);
    //             } else {
    //                 const config = JSON.parse(data.Content.toString('utf-8'));
    //                 resolve(config);
    //             }
    //         });
    //     });
    // };

    // const config = await getConfigPromise();

    let deviceType = req.params.deviceType.toUpperCase();
    let response;

    switch (deviceType.toLowerCase()) {
        case 'android':
            response = {
                "minimumVersion": "1.4.5",
                "latestVersion": "1.4.5",
                "playStoreURL": "co.za.tenetech.nsfas"
              };
            break;

        case 'ios':
            response = {
                "minimumVersion": "1.4.0",
                "latestVersion": "1.4.0",
                "appStoreURL": "https://apps.apple.com/za/app/tenet-technology/id6466175448"
              };
            break;

        case 'web':
            response = {
                "minimumVersion": "2.4.2",
                "latestVersion": "2.4.2"
              };
            break;

        default:
            throw new Error(`Invalid deviceType: ${deviceType}`);
    }

    if (!response) {
        throw new Error('Configuration not found for the specified deviceType');
    }

    //cache.set(key, response, 86400);
    //console.log(`Setting cache ${key} to ${JSON.stringify(response)}`);
    return response;
}

function startConfigurationSession(params) {
    return new Promise((resolve, reject) => {
        appConfigData.startConfigurationSession(params, (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data.InitialConfigurationToken);
            }
        });
    });
}

function getLatestConfiguration(params) {
    return new Promise((resolve, reject) => {
        appConfigData.getLatestConfiguration(params, (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(JSON.parse(data.Configuration));
            }
        });
    });
}

async function getFeatureFlags(req) {
    console.log(req.params);
    // const key = `feature_${req.params.deviceType.toUpperCase()}`;

    // if (cache.get(key)) {
    //     const ts = cache.getTtl( key );
    //     console.log(`Found feature for ${req.params.deviceType.toUpperCase()} - Time remaining ${ts}`);

    //     return cache.get(key);
    // }

    // console.log(`Failed to find feature for ${req.params.deviceType.toUpperCase()}`);

    let deviceType = req.params.deviceType.toUpperCase();
    let config;

    switch (deviceType.toLowerCase()) {
        case 'android':
            config = {
                "vas-integration": {
                    "minimum-version": "1.3.0",
                    "enabled": false
                },
                "monthly-statement": {
                    "minimum-version": "1.2.0",
                    "enabled": true
                } 
            };
            break;

        case 'ios':
            config = {
                "vas-integration": {
                    "minimum-version": "1.3.0",
                    "enabled": false
                },
                "monthly-statement": {
                    "minimum-version": "1.1.0",
                    "enabled": true
                } 
            };
            break;

        case 'web':
            config = {
                "vas-integration": {
                    "minimum-version": "1.3.0",
                    "enabled": false
                },
                "monthly-statement": {
                    "minimum-version": "1.2.0",
                    "enabled": false
                } 
            };
            break;

        case 'api':
            config = {
                "info-logs": {
                    "enabled": true
                }
            };
            break;

        default:
            throw new Error(`Invalid deviceType: ${deviceType}`);
    }

    // const params = {
    //     ApplicationIdentifier: process.env.APP_CONFIG_APPLICATION_ID,
    //     EnvironmentIdentifier: process.env.APP_CONFIG_ENVIRONMENT_ID,
    //     ConfigurationProfileIdentifier: configurationProfile
    // };

    // const initialConfigToken = await startConfigurationSession(params);

    // const configurationToken = {
    //     ConfigurationToken: initialConfigToken
    // };

    // const config = await getLatestConfiguration(configurationToken);

    // cache.set(key, config, 86400);
    // console.log(`Setting cache ${key} to ${JSON.stringify(config)}`);

    return config;
}

module.exports = {
    getBankList,
    getVersionData,
    getFeatureFlags
};