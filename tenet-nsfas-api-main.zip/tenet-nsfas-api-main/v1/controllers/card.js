const validations = require("../validator/index");
const services = require("../services");
const response = require("../../utility/response");
const responseCode = require("../../utility/responseCode");

//********************* OnBaording ***********************//

async function getCard(req, res, next) {
    try {
        let card = await services.card.getCard(req);
        return res.status(200).set({}).send(card);
    } catch (error) {
        next(error);
    }
}


async function createPinSet(req, res, next) {
    try {
        let card = await services.card.createPinSet(req);
        return response.sendSuccessResponse(req, res, card, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

async function updateCard(req, res, next) {
    try {
        let card = await services.card.updateCard(req);
        return res.status(200).set({}).send(card);
    } catch (error) {
        next(error);
    }
}

module.exports = {
    //GET
    getCard,

    //POST
    createPinSet,

    //PUT
    updateCard
};
