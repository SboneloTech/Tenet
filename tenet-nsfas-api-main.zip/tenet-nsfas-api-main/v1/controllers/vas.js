const validations = require("../validator/index");
const services = require("../services");
const response = require("../../utility/response");
const responseCode = require("../../utility/responseCode");

//********************* OnBaording ***********************//

async function getCatalog(req, res, next) {
    try {
        let cards = await services.vas.getCatalog(req);
        return res.status(200).set({}).send(cards);
    } catch (error) {
        next(error);
    }
}

module.exports = {
    getCatalog
};
