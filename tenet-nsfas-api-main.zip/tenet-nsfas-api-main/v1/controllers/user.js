const validations = require("../validator/index");
const services = require("../services");
const response = require("../../utility/response");
const responseCode = require("../../utility/responseCode");

//********************* OnBaording ***********************//

async function signup(req, res, next) {
    try {
        await validations.user.validateSignUp(req);
        let user = await services.user.sendOTPtoNewUser(req);
        return response.sendSuccessResponse(req, res, user, responseCode.CREATED, process.lang.OTP_SEND_SUCCESS);
    } catch (error) {
        next(error);
    }
}
async function logout(req, res, next) {
    try {
        let user = await services.user.logout(req);
        return response.sendSuccessResponse(req, res, user, responseCode.OK, process.lang.LOGOUT);
    } catch (error) {
        next(error);
    }
}
async function verifyOtp(req, res, next) {
    try {
        await validations.user.validateVerifyOtp(req);
        let data = await services.user.verifyOTP(req, req.body);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.SUCCESS);
    } catch (error) {
        next(error);
    }
}
async function setPassword(req, res, next) {
    try {
        let data = await services.user.setPassword(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.PASSWORD_CHANGE_SUCCESS);
    } catch (error) {

        next(error);
    }
}
async function socialLogin(req, res, next) {
    try {
        await validations.user.socialLogin(req);
        let data = await services.user.socialLogin(req.body);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function updatepassCode(req, res, next) {
    try {
        await validations.user.updatepassCode(req);
        let data = await services.user.updatepassCode(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function verifyPassCode(req, res, next) {
    try {
        let data = await services.user.verifyPassCode(req);
        if (data.isThreeAttamped) {
            return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.YOUR_ACCOUNT_BLOCKED);
        }
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function updateprofile(req, res, next) {
    try {
        let data = await services.user.updateprofile(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

async function cardProfileUpdate(req, res, next) {
    try {
        let data = await services.user.cardProfileUpdate(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

async function findSaId(req, res, next) {
    try {
        await validations.user.findSaId(req);
        let user = await services.user.findSaId(req);
        if (!user.enroll) {

            return response.sendSuccessResponse(req, res, user, responseCode.CREATED, process.lang.FETCH_SUCCESSFULLY);
        } else {
            return response.sendAcceptedResponse(req, res, { saIdNo: req.body.saIdNo, customerId: user.customerId, ukhesheCustId: user.customerId + "", hasIdIdentity: user.hasIdIdentity }, 202, "User enrolment required");
        }
    } catch (error) {
        next(error);
    }
}
async function loginApp(req, res, next) {
    try {
        if (!req.body.enroll) {
            await validations.user.validateLogIn(req);
        }
        let user = await services.user.login(req, req.body);
        return response.sendSuccessResponse(req, res, user, responseCode.CREATED, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function forgotpassword(req, res, next) {
    try {
        let user = await services.user.forgotpassword(req.body);
        return response.sendSuccessResponse(req, res, user, responseCode.OK, process.lang.OTP_SEND_SUCCESS);
    } catch (error) {
        next(error);
    }
}
async function changePassword(req, res, next) {
    try {
        await validations.user.validateChangePassword(req, "body", false);
        req.user.forResetPassword = false;
        let data = await services.user.changePassword(req, req.body, req.user);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

//***************************** KYC LIVENESS ***********************************//
async function getSessionId(req, res, next) {
    try {
        let data = await services.user.getSessionId(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function getAwsConfig(req, res, next) {
    try {
        let data = await services.user.getAwsConfig(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function getRatifyResults(req, res, next) {
    try {
        let data = await services.user.getRatifyResults(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

async function syncKyc(req, res, next) {
    try {
        let data = await services.user.syncKyc(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}


//***************************** File Upload ***********************************//

async function fileUpload(req, res, next) {
    try {
        return response.sendSuccessResponse(req, res, `${req.file.location}`, responseCode.OK); // for s3 bucket
        // return response.sendSuccessResponse(req, res, `/images/${req.file.filename}`, responseCode.OK); // for normal
    } catch (error) {
        next(error);
    }
}

//******************************* DashBoard *******************************//

async function dashboard(req, res, next) {
    try {
        await validations.user.validateDashBoard(req);
        let data = await services.user.dashboard(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

//*********************** Notification ***************************//

async function notificationClear(req, res, next) {
    try {
        let data = await services.user.userClearNotification(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function userNotification(req, res, next) {
    try {
        let data = await services.user.userNotification(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

async function userDocUpload(req, res, next) {
    try {
        await validations.user.validateDocsUploads(req);
        let data = await services.user.userDocUpload(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

async function callBackUrl(req, res, next) {
    try {
        let data = await services.user.callBackUrl(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function landing(req, res, next) {
    try {
        let data = await services.user.landing(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function sendOtp(req, res, next) {
    try {
        let user = await services.user.sendOtp(req);
        return response.sendSuccessResponse(req, res, user, responseCode.OK, `${process.lang.OTP_SEND_SUCCESS} to ${user.phone}`);
    } catch (error) {
        next(error);
    }
}
async function otp(req, res, next) {
    try {
        let otp = await services.user.otp(req);
        return response.sendSuccessResponse(req, res, otp, responseCode.OK, `${process.lang.OTP_SEND_SUCCESS} to ${otp.phone}`);
    } catch (error) {
        next(error);
    }
}
async function adminDetailUpdate(req, res, next) {
    try {
        let otp = await services.user.adminDetailUpdate(req);
        return response.sendSuccessResponse(req, res, otp, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function verotp(req, res, next) {
    try {
        req.body.key = req.user.phone;
        req.body.countryCode = req.user.countryCode;
        let data = await services.user.verotp(req.body, req);
        if (data.isThreeOTPAttamped) {
            return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.YOUR_ACCOUNT_OTP_BLOCKED);
        }
        if (data.isError) {
            return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.OTP_INVALID);
        }
        return response.sendSuccessResponse(req, res, { passCodeRamdom: data.passCodeRamdom }, responseCode.OK, process.lang.SUCCESS);
    } catch (error) {
        next(error);
    }
}
async function getPofile(req, res, next) {
    try {
        let data = await services.user.getPofile(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function deletePofile(req, res, next) {
    try {
        let data = await services.user.deletePofile(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.DELETED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function sendCaptureOtp(req, res, next) {
    try {
        let data = await services.user.sendCaptureOtp(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.SMS_SENT);
    } catch (error) {
        next(error);
    }
}
async function eftCallbackUrl(req, res, next) {
    try {
        let data = await services.user.eftCallbackUrl(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function cardfieldtopup(req, res, next) {
    try {
        let data = await services.user.cardfieldtopup(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function walletToWalletTopUp(req, res, next) {
    try {
        let data = await services.user.walletToWalletTopUp(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

async function walletWithdrawalCallback(req, res, next) {
    try {
        let data = await services.user.walletWithdrawalCallback(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

async function getProductList(req, res, next) {
    try {
        let data = await services.airTime.getProductList(req);
        return res.status(200).send(data);
    } catch (error) {
        next(error);
    }
}
async function setSales(req, res, next) {
    try {
        let data = await services.airTime.setSales(req);
        return res.status(200).send(data);
    } catch (error) {
        next(error);
    }
}
async function getApis(req, res, next) {
    try {
        let data = await services.airTime.getApis(req);
        return res.status(200).send(data);
    } catch (error) {
        next(error);
    }
}
async function postApis(req, res, next) {
    try {
        let data = await services.airTime.postApis(req);
        return res.status(200).send(data);
    } catch (error) {
        next(error);
    }
}
async function getStudent(req, res, next) {
    try {
        let data = await services.user.getStudent(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function updateStudent(req, res, next) {
    try {
        let data = await services.user.updateStudent(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

async function refreshToken(req, res, next) {
    try {
        let data = await services.user.refreshToken(req, res);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}


async function airtimePayment(req, res, next) {
    try {
        await validations.user.airtimePayment(req);
        let data = await services.user.airtimePayment(req, res);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function ukhesheToken(req, res, next) {
    try {
        let data = await services.ukhesheService.generateUkhsheToken(req, res);
        if (Array.isArray(data.data)) {
            if (data.data[0].description == 'Device fingerprint is not enrolled') {
                // return response.sendFailResponse(req, res, responseCode.BAD_REQUEST, 'We have detected a change in device, please contact support for further assistance.');
                throw Object.assign(new Error('We have detected a change in device, please contact support for further assistance.'), {
                    newRelicMessage: "Device Fingerprint not enrolled",
                    details: { ...data.data, configData: { ...data.configData } }
                });
            }
        }
        if (data && !data.isSuccess) {
            // return response.sendFailResponse(req, res, responseCode.BAD_REQUEST, data.data[0].description);
            throw Object.assign(new Error(data.data[0].description), {
                newRelicMessage: "UkhesheToken Failed",
                details: { ...data.data, configData: { ...data.configData } }
            });
        }
        if (data.isUserNotFound) {
            return response.sendFailResponse(req, res, responseCode.BAD_REQUEST);
        }

        return res.status(200).send(data);

    } catch (error) {
        next(error);
    }
}

async function addHelp(req, res, next) {
    try {
        let data = await services.user.addHelp(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.QUERY_CREATED);
    } catch (error) {
        next(error);
    }
}

async function getHelp(req, res, next) {
    try {
        let data = await services.user.getHelp(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function updateHelp(req, res, next) {
    try {
        let data = await services.user.updateHelp(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.RESOLVED_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}


async function addError(req, res, next) {
    try {
        let data = await services.user.addError(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}


async function getError(req, res, next) {
    try {
        let data = await services.user.getError(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

async function getChatList(req, res, next) {
    try {
        let data = await services.user.getChatList(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function getChatHistory(req, res, next) {
    try {

        let data = await services.user.getChatHistory(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function getCheckPendingChat(req, res, next) {
    try {
        let data = await services.user.getCheckPendingChat(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}
async function getQueryList(req, res, next) {
    try {
        let data = await services.user.getQueryList(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}


async function chatAction(req, res, next) {
    try {
        let data = await services.user.chatAction(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.QUERY_CLOSED);
    } catch (error) {
        next(error);
    }
}
async function sendChat(req, res, next) {
    try {
        let data = await services.user.sendChat(req, res);
        // return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.QUERY_CLOSED);
    } catch (error) {
        next(error);
    }
}

async function runKyc(req, res, next) {
    try {
      let data = await services.admin.ratifyUserById(req, req.user);
      return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
    } catch (error) {
      next(error);
    }
}  

async function sendOTPtoIdentity(req, res, next) {
    try {
        let data = await services.user.sendOTPtoIdentity(req);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.SEND_SUCCESSFULLY);
    } catch (error) {
        next(error);
    }
}

async function verifySMSToPhone(req, res, next) {
    try {
        let data = await services.user.verifySMSToPhone(req.body);
        return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.SUCCESS);
    } catch (error) {
        next(error);
    }
}

module.exports = {
    getCheckPendingChat,
    getChatList,
    getChatHistory,
    ukhesheToken,
    airtimePayment,
    refreshToken,
    updateStudent,
    getStudent,
    setSales,
    getProductList,
    sendCaptureOtp,
    eftCallbackUrl,
    deletePofile,
    findSaId,
    notificationClear,
    logout,
    signup,
    verifyOtp,
    setPassword,
    socialLogin,
    updateprofile,
    fileUpload,
    loginApp,
    forgotpassword,
    changePassword,
    dashboard,
    userNotification,
    updatepassCode,
    userDocUpload,
    sendOtp,
    getPofile,
    callBackUrl,
    landing,
    otp,
    verotp,
    verifyPassCode,
    walletToWalletTopUp,
    getApis,
    postApis,
    cardProfileUpdate,
    addHelp,
    getHelp,
    updateHelp,
    addError,
    getError,
    cardfieldtopup,
    getQueryList,
    chatAction,
    sendChat,
    adminDetailUpdate,
    walletWithdrawalCallback,
    getSessionId,
    getAwsConfig,
    getRatifyResults,
    syncKyc,
    runKyc,
    sendOTPtoIdentity,
    verifySMSToPhone
};
