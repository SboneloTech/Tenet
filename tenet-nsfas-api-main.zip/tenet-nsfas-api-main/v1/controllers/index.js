module.exports = {
    user: require("./user"),
    admin: require('./admin'),
    wallet: require('./wallet'),
    customer: require('./customer'),
    config: require('./config'),
    card: require('./card'),
    vas: require('./vas')
};
