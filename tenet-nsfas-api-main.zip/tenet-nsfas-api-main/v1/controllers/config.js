const validations = require("../validator/index");
const services = require("../services");
const response = require("../../utility/response");
const responseCode = require("../../utility/responseCode");

//********************* OnBaording ***********************//

async function getBankList(req, res, next) {
    try {
        let banks = await services.config.getBankList(req);
        return res.status(200).set({}).send(banks);
    } catch (error) {
        next(error);
    }
}

async function getVersionData(req, res, next) {
    try {
        let versionData = await services.config.getVersionData(req);
        return res.status(200).set({}).send(versionData);
    } catch (error) {
        next(error);
    }
}

async function getFeatureFlags(req, res, next) {
    try {
        let featureFlagsData = await services.config.getFeatureFlags(req);
        return res.status(200).set({}).send(featureFlagsData);
    } catch (error) {
        next(error);
    }
}

module.exports = {
    getBankList,
    getVersionData,
    getFeatureFlags
};
