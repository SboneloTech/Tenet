const validations = require("../validator/index");
const services = require("../services");
const response = require("../../utility/response");
const responseCode = require("../../utility/responseCode");

//********************* OnBaording ***********************//

async function getCardsOnFile(req, res, next) {
    try {
        let cards = await services.customer.getCardsOnFile(req);
        return res.status(200).set({}).send(cards);
    } catch (error) {
        next(error);
    }
}

async function getCards(req, res, next) {
    try {
        let cards = await services.customer.getCards(req);
        return res.status(200).set({}).send(cards);
    } catch (error) {
        next(error);
    }
}


async function getAddresses(req, res, next) {
    try {
        let cards = await services.customer.getAddresses(req);
        return res.status(200).set({}).send(cards);
    } catch (error) {
        next(error);
    }
}

async function getStatement(req, res, next) {
    try {
        let statement = await services.customer.statement(req, res);
        return res.status(200).set({}).send(statement);
    } catch (error) {
        next(error);
    }
}

async function createCardOnFile(req, res, next) {
    try {
        let cards = await services.customer.createCardOnFile(req);
        return res.status(200).set({}).send(cards);
    } catch (error) {
        next(error);
    }
}

async function createPayment(req, res, next) {
    try {
        let cards = await services.customer.createPayment(req);
        return res.status(200).set({}).send(cards);
    } catch (error) {
        next(error);
    }
}


async function updatePayment(req, res, next) {
    try {
        let cards = await services.customer.updatePayment(req);
        return res.status(200).set({}).send(cards);
    } catch (error) {
        next(error);
    }
}


async function deleteCardOnFile(req, res, next) {
    try {
        let cards = await services.customer.deleteCardOnFile(req);
        return res.status(204).set({}).send(cards);
    } catch (error) {
        next(error);
    }
}

module.exports = {
    //GET
    getCardsOnFile,
    getAddresses,
    getCards,
    getStatement,

    //POST
    createCardOnFile,
    createPayment,

    //PUT
    updatePayment,

    //DELETE
    deleteCardOnFile
};
