const validations = require("../validator/index");
const services = require("../services");
const response = require("../../utility/response");
const responseCode = require("../../utility/responseCode");

//************************** API KEY MANAGEMENT **********************//
async function createAdmin(req, res, next) {
  try {
    // await validations.admin.validateSignUp(req);    
    let admin = await services.admin.createAdmin(req.body);
    return response.sendSuccessResponse(req, res, admin, responseCode.CREATED);
  } catch (error) {
    next(error);
  }
}

//************************** OnBoarding **********************//
async function signup(req, res, next) {
  try {
    await validations.admin.validateSignUp(req);
    // if (!req.body.email && !req.body.phone) {
    //   return response.sendFailResponse(req, res, responseCode.BAD_REQUEST, process.lang.REQUIRED_FILED_IS_MISSING);
    // }
    let admin = await services.admin.createAdminUser(req.body);
    return response.sendSuccessResponse(req, res, admin, responseCode.CREATED);
  } catch (error) {
    next(error);
  }
}
async function login(req, res, next) {
  try {
    await validations.admin.validateLogIn(req);
    let admin = await services.admin.login(req.body);
    return response.sendSuccessResponse(req, res, admin, responseCode.OK, process.lang.LOGIN_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function forgotPassword(req, res, next) {
  try {
    await validations.admin.validateResetPassword(req);
    await services.admin.resetPassword(req.body);
    return response.sendSuccessResponse(req, res, null, responseCode.OK, process.lang.OTP_SEND_SUCCESS);
  } catch (error) {
    next(error);
  }
}
async function verifyOtp(req, res, next) {
  try {
    await validations.admin.validateOtpVerify(req);
    let data = await services.admin.verifyOtp(req, req.body);
    return response.sendSuccessResponse(req, res, data, responseCode.OK);
  } catch (error) {
    next(error);
  }
}
async function setPassword(req, res, next) {
  try {
    await validations.admin.validateChangePassword(req, "body", true);
    req.user.forResetPassword = true;
    let data = await services.admin.changePassword(req.body, req.user);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.PASSWORD_CHANGE_SUCCESS);
  } catch (error) {
    next(error);
  }
}
async function changePassword(req, res, next) {
  try {
    await validations.admin.validateChangePassword(req, "body", false);
    req.user.forResetPassword = false;
    let data = await services.admin.changePassword(req.body, req.user);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function updateProfile(req, res, next) {
  try {
    await validations.admin.validateProfileUpdate(req);
    let data = await services.admin.updateProfile(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function getProfile(req, res, next) {
  try {
    let data = await services.admin.getProfile(req.user);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
// *********************** API KEY MANAGEMENT ***********************//
async function createAdmin(req, res, next) {
  try {
    await validations.admin.validateSignUp(req);

    let admin = await services.admin.createAdmin(req.body);
    return response.sendSuccessResponse(req, res, admin, responseCode.CREATED);
  } catch (error) {
    next(error);
  }
}

// ****************************** USER *****************************//
async function getAllUsers(req, res, next) {
  try {
    let data = await services.admin.getAllUsers(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function searchUsers(req, res, next) {
  try {
    let data = await services.admin.searchUsers(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function getUserDocsByUserId(req, res, next) {
  try {
    let data = await services.admin.getUserDocsByUserId(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function deleteUserDocById(req, res, next) {
  try {
    let data = await services.admin.deleteUserDocById(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function getUserById(req, res, next) {
  try {
    let data = await services.admin.getUserById(req);
    console.log(data);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function deleteUserById(req, res, next) {
  try {
    let data = await services.admin.deleteUserById(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function ratifyUserById(req, res, next) {
  try {
    let data = await services.admin.ratifyUserById(req, req.body);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function updateUser(req, res, next) {
  try {
    let data = await services.admin.updateUserById(req, req.body);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}

// ****************************** DashBaord *****************************//
async function getDashboard(req, res, next) {
  try {
    let data = await services.admin.getDashboard(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}

//***************************** SubAdmin *****************************//
async function addSubadmin(req, res, next) {
  try {
    await validations.admin.validateSubadmin(req);
    let data = await services.admin.addSubAdmin(req);
    return response.sendSuccessResponse(req, res, data, responseCode.CREATED, process.lang.ADD_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function getSubadmin(req, res, next) {
  try {
    let data = await services.admin.getSubAdmin(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function updateSubadmin(req, res, next) {
  try {
    await validations.admin.validateSubadmin(req);
    let data = await services.admin.updateSubAdmin(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function deleteSubadmin(req, res, next) {
  try {
    let data = await services.admin.deleteSubAdmin(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.DELETED_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}

//******************************** CMS *******************************//
async function addCms(req, res, next) {
  try {
    let data = await services.admin.addCms(req);
    return response.sendSuccessResponse(req, res, data, responseCode.CREATED, process.lang.CREATE_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function updateCms(req, res, next) {
  try {
    let data = await services.admin.updateCms(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function getCms(req, res, next) {
  try {
    let data = await services.admin.getCms(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}

//***************************** Account Verifed **************************************//
async function accountVerified(req, res, next) {
  try {
    let data = await services.admin.accountVerified(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function getAccountVerified(req, res, next) {
  try {
    let data = await services.admin.getAccountVerified(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}

//********************************* FAQ ************************************//

async function addFaq(req, res, next) {
  try {
    let data = await services.admin.addFaq(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.CREATE_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function updateFaq(req, res, next) {
  try {
    await validations.admin.faq(req);
    let data = await services.admin.updateFaq(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function deleteFaq(req, res, next) {
  try {
    let data = await services.admin.deleteFaq(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.DELETED_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function getFaq(req, res, next) {
  try {
    let data = await services.admin.getFaq(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}

async function notificationAdd(req, res, next) {
  try {
    await validations.admin.addNotification(req);
    let data = await services.admin.addNotification(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function getNotification(req, res, next) {
  try {
    let data = await services.admin.getNotification(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function getQuery(req, res, next) {
  try {
    let data = await services.admin.getQuery(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function changeAgent(req, res, next) {
  try {
    let data = await services.admin.changeAgent(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function escalate(req, res, next) {
  try {
    let data = await services.admin.escalate(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.UPDATED_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function statusList(req, res, next) {
  try {
    let data = await services.admin.statusList(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
async function statusChange(req, res, next) {
  try {
    let data = await services.admin.statusChange(req);
    return response.sendSuccessResponse(req, res, data, responseCode.OK, process.lang.FETCH_SUCCESSFULLY);
  } catch (error) {
    next(error);
  }
}
module.exports = {
  statusChange,
  statusList,
  getQuery,
  changeAgent,
  notificationAdd,
  getNotification,
  addFaq,
  updateFaq,
  deleteFaq,
  getFaq,
  accountVerified,
  getAccountVerified,
  signup,
  login,
  forgotPassword,
  verifyOtp,
  setPassword,
  updateProfile,
  getProfile,
  changePassword,
  addSubadmin,
  getSubadmin,
  updateSubadmin,
  deleteSubadmin,
  addCms,
  updateCms,
  getCms,
  escalate,
  getDashboard,
  getAllUsers,
  getUserById,
  deleteUserById,
  searchUsers,
  ratifyUserById,
  getUserDocsByUserId,
  deleteUserDocById,
  updateUser,
  createAdmin
};
