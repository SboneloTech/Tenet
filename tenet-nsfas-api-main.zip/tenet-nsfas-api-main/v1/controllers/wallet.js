const validations = require("../validator/index");
const services = require("../services");
const response = require("../../utility/response");
const responseCode = require("../../utility/responseCode");

//********************* OnBaording ***********************//

async function getWallets(req, res, next) {
    try {
        let wallets = await services.wallet.getWallets(req);
        return res.status(200).set({}).send(wallets);
    } catch (error) {
        next(error);
    }
}

async function getWalletById(req, res, next) {
    try {
        let wallet = await services.wallet.getWalletById(req);
        return res.status(200).set({}).send(wallet);
    } catch (error) {
        next(error);
    }
}

async function getWalletByPhoneNumber(req, res, next) {
    try {
        let wallet = await services.wallet.getWalletByPhoneNumber(req);
        return res.status(200).set({}).send(wallet);
    } catch (error) {
        next(error);
    }
}

async function getWalletCards(req, res, next) {
    try {
        let wallet = await services.wallet.getWalletCards(req);
        return res.status(200).set({}).send(wallet);
    } catch (error) {
        next(error);
    }
}

async function getQRCode(req, res, next) {
    try {
        let wallet = await services.wallet.getQRCode(req);
        return res.status(200).set({}).send(wallet);
    } catch (error) {
        next(error);
    }
}

async function getTransactions(req, res, next) {
    try {
        let wallets = await services.wallet.getTransactions(req);
        return res.status(200).set({}).send(wallets);
    } catch (error) {
        next(error);
    }
}

async function getWithdrawals(req, res, next) {
    try {
        let withdrawals = await services.wallet.getWithdrawals(req);
        return res.status(200).set({}).send(withdrawals);
    } catch (error) {
        next(error);
    }
}


async function getWithdrawalFees(req, res, next) {
    try {
        let withdrawalFees = await services.wallet.getWithdrawalFees(req);
        return res.status(200).set({}).send(withdrawalFees);
    } catch (error) {
        next(error);
    }
}


async function createWallet(req, res, next) {
    try {
        let wallet = await services.wallet.createWallet(req);
        return res.status(200).set({}).send(wallet);
    } catch (error) {
        next(error);
    }
}

async function topupWallet(req, res, next) {
    try {
        let topup = await services.wallet.topupWallet(req);
        return res.status(200).set({}).send(topup);
    } catch (error) {
        next(error);
    }
}

async function createWalletQRCode(req, res, next) {
    try {
        let topup = await services.wallet.createWalletQRCode(req);
        return res.status(200).set({}).send(topup);
    } catch (error) {
        next(error);
    }
}

async function walletWithdrawals(req, res, next) {
    try {
        let withdrawal = await services.wallet.walletWithdrawals(req);
        return res.status(200).set({}).send(withdrawal);
    } catch (error) {
        next(error);
    }
}


async function walletTransfer(req, res, next) {
    try {
        let transfer = await services.wallet.walletTransfer(req);
        return res.status(204).set({}).send(transfer);
    } catch (error) {
        next(error);
    }
}


async function updateWallet(req, res, next) {
    try {
        let transfer = await services.wallet.updateWallet(req);
        return res.status(200).set({}).send(transfer);
    } catch (error) {
        next(error);
    }
}

async function getDigitalWallets(req, res, next) {
    try {
        let wallets = await services.wallet.getDigitalWallets(req);
        return res.status(200).set({}).send(wallets);
    } catch (error) {
        next(error);
    }
}

module.exports = {
    //GET
    getWallets,
    getWalletById,
    getWalletByPhoneNumber,
    getWalletCards,
    getQRCode,
    getTransactions,
    getWithdrawals,
    getWithdrawalFees,
    getDigitalWallets,

    //POST
    createWallet,
    topupWallet,
    createWalletQRCode,
    walletWithdrawals,
    walletTransfer,

    //PUT
    updateWallet
};
