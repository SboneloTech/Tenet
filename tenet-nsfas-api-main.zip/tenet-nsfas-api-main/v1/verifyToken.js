const Model = require("../models");

module.exports = async function verifyToken(req, res, next) {
    const apiKey = req.headers['x-nsfas-api-key'];
    const apiName = req.headers['x-nsfas-api-name'];

    const admin = await Model.admin.findOne({ name: apiName });
    try {
        if (admin.apiKey == apiKey) {
            next();
        } else {
            throw new Error(process.lang.UNAUTHORIZED);
        }
    } catch (error) {
        next(error);
    }
};

