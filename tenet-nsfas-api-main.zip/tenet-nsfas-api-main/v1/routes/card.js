const router = require("express").Router();
const Controllers = require("../controllers").user;
const adminController = require("../controllers").admin;
const cardController = require("../controllers").card;
const Service = require("../services");
// const ExpressBrute = require("express-brute");
const upload = require("../services/fileUpload");



//----------onBoarding-------------------------------
// router.post("/signup", adminController.signup);
router.get("/:cardId", Service.authService.userAuth, cardController.getCard);

router.post("/:cardId/pin-sets", Service.authService.userAuth, cardController.createPinSet);

router.put("/:cardId", Service.authService.userAuth, cardController.updateCard);


module.exports = router;
