const router = require("express").Router();
const Controllers = require("../controllers").user;
const adminController = require("../controllers").admin;
const vasController = require("../controllers").vas;
const Service = require("../services");
// const ExpressBrute = require("express-brute");
const upload = require("../services/fileUpload");



//----------onBoarding-------------------------------
// router.post("/signup", adminController.signup);
router.get("/catalogs", Service.authService.userAuth, vasController.getCatalog);


module.exports = router;
