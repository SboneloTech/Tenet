const router = require("express").Router();
const Controllers = require("../controllers").user;
const adminController = require("../controllers").admin;
const Service = require("../services");
// const ExpressBrute = require("express-brute");
const upload = require("../services/fileUpload");
const verifyToken = require('../verifyToken');



//----------onBoarding-------------------------------
router.post("/signup", adminController.signup);
router.post("/login", adminController.login);
router.post("/forgotPassword", adminController.forgotPassword);
router.post("/verifyOtp", adminController.verifyOtp);
router.post("/setPassword", Service.authService.adminAuth, adminController.setPassword);
router.put("/updateProfile", Service.authService.adminAuth, adminController.updateProfile);
router.get("/profile", Service.authService.adminAuth, adminController.getProfile);
router.post("/changePassword", Service.authService.adminAuth, adminController.changePassword);
router.post("/upload", upload.fileUpload.single('image'), Controllers.fileUpload);

//API_KEY
router.post('/create', adminController.createAdmin);

// Users
router.get("/user/all", verifyToken, adminController.getAllUsers);
router.get("/user/search", verifyToken, adminController.searchUsers);
router.get("/user/:id", verifyToken, adminController.getUserById);
router.delete("/user/:id", Service.authService.adminAuth, adminController.deleteUserById);
router.post("/user/ratify", Service.authService.adminAuth, adminController.ratifyUserById);
router.put("/user/:id", verifyToken, adminController.updateUser);
router.get("/user/:id/docs", verifyToken, adminController.getUserDocsByUserId);
router.delete("/doc/:id", verifyToken, adminController.deleteUserDocById);

// SubAdmin
router.post("/subAdmin", Service.authService.adminAuth, adminController.addSubadmin);
router.get("/subAdmin", Service.authService.adminAuth, adminController.getSubadmin);
router.get("/subAdmin/:id", Service.authService.adminAuth, adminController.getSubadmin);
router.put("/subAdmin/:id", Service.authService.adminAuth, adminController.updateSubadmin);
router.delete("/subAdmin/:id", Service.authService.adminAuth, adminController.deleteSubadmin);

// cms 
router.post("/cms", Service.authService.adminAuth, adminController.addCms);
router.put("/cms/:id", Service.authService.adminAuth, adminController.updateCms);
router.get("/cms", Service.authService.adminAuth, adminController.getCms);


// faq
router.post("/faq", Service.authService.adminAuth, adminController.addFaq);
router.put("/faq/:id", Service.authService.adminAuth, adminController.updateFaq);
router.delete("/faq/:id", Service.authService.adminAuth, adminController.deleteFaq);
router.get("/faq", Service.authService.adminAuth, adminController.getFaq);
router.get("/faq/:id", Service.authService.adminAuth, adminController.getFaq);

// notification
router.post("/notification", Service.authService.adminAuth, adminController.notificationAdd);
router.get("/notification", Service.authService.adminAuth, adminController.getNotification);



router.put("/help/:id", Service.authService.adminAuth, Controllers.updateHelp);
router.get("/help", Service.authService.adminAuth, Controllers.getHelp);
router.get("/help/:id", Service.authService.adminAuth, Controllers.getHelp);


// chat
router.get("/chatList", Service.authService.adminAuth, Controllers.getChatList);
router.get("/chat/history", Service.authService.adminAuth, Controllers.getChatHistory);


router.get("/query", Service.authService.adminAuth, adminController.getQuery);

router.put("/agentChange", Service.authService.adminAuth, adminController.changeAgent);

router.post("/chatAction", Service.authService.adminAuth, Controllers.chatAction);
router.post("/sendChat/:id", Service.authService.adminAuth, Controllers.sendChat);


router.post("/escalate", Service.authService.adminAuth, adminController.escalate);

router.get("/statusList", adminController.statusList);
router.post("/status", Service.authService.adminAuth, adminController.statusChange);


router.put("/timing", Service.authService.adminAuth, Controllers.adminDetailUpdate); // admin update

router.get("/downloadChat/:id", Controllers.sendChat);

module.exports = router;
