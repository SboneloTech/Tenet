const express = require("express");
const response = require("../../utility/response");
const user = require("./user");
const adminRoute = require("./admin");
const walletRoute = require("./wallet");
const cardRoute = require("./card");
const vasRoute = require("./vas");
const customerRoute = require("./customer");
const configRoute = require("./config");
const router = express();
router.use("/user", user);
router.use("/admin", adminRoute);
router.use("/customer", customerRoute);
router.use("/config", configRoute);
router.use("/wallet", walletRoute);
router.use("/card", cardRoute);
router.use("/vas", vasRoute);
router.get("/health", (req, res) => {
    return response.sendSuccessResponse(req, res, {}, 200, "Server is running");
});
// router.post("/transactioncallback", (req, res, next) => {
//     console.log(req.body);
//     return response.sendSuccessResponse(req, res, {}, 200, "Callback url hit");
// });

//console.log(expressListRoutes(router));
module.exports = router;
