const router = require("express").Router();
const Controllers = require("../controllers").user;
const adminController = require("../controllers").admin;
const walletController = require("../controllers").wallet;
const Service = require("../services");
// const ExpressBrute = require("express-brute");
const upload = require("../services/fileUpload");



//----------onBoarding-------------------------------
// router.post("/signup", adminController.signup);
router.get("/", Service.authService.userAuth, walletController.getWallets);
router.get("/digital", Service.authService.userAuth, walletController.getDigitalWallets);
router.get("/phone/:phone", Service.authService.userAuth, walletController.getWalletByPhoneNumber);
router.get("/:walletId", Service.authService.userAuth, walletController.getWalletById);
router.get("/:walletId/cards", Service.authService.userAuth, walletController.getWalletCards);
router.get("/qr-codes/:code", Service.authService.userAuth, walletController.getQRCode);
router.get("/:walletId/transactions", Service.authService.userAuth, walletController.getTransactions);
router.get("/:walletId/withdrawals", Service.authService.userAuth, walletController.getWithdrawals);
router.get("/:walletId/withdrawals/fees", Service.authService.userAuth, walletController.getWithdrawalFees);

router.post("/", Service.authService.userAuth, walletController.createWallet);
router.post("/:walletId/topups", Service.authService.userAuth, walletController.topupWallet);
router.post("/:walletId/qr-codes", Service.authService.userAuth, walletController.createWalletQRCode);
router.post("/:walletId/withdrawals", Service.authService.userAuth, walletController.walletWithdrawals);
router.post("/transfers", Service.authService.userAuth, walletController.walletTransfer);

router.put("/:walletId", Service.authService.userAuth, walletController.updateWallet);


module.exports = router;
