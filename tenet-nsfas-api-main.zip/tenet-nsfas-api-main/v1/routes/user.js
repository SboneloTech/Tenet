const router = require("express").Router();
const Controllers = require("../controllers").user;
const adminController = require("../controllers").admin;
const Service = require("../services");
const upload = require("../services/fileUpload");


//OnBoarding 

router.post("/register", Controllers.signup);
router.post("/verifyotp", Controllers.verifyOtp);
router.post("/verifySMSToPhone", Controllers.verifySMSToPhone);
router.post("/passCode", Service.authService.userAuth, Controllers.updatepassCode);
router.post("/profile", Service.authService.userAuth, Controllers.updateprofile);
router.post("/cardProfileUpdate", Service.authService.userAuth, Controllers.cardProfileUpdate);
router.post("/runKyc", Service.authService.userAuth, Controllers.runKyc);

router.post("/changepassword", Service.authService.userAuth, Controllers.changePassword);
router.post("/login", Controllers.loginApp);
router.post("/saId", Controllers.findSaId);

router.post("/forgotpassword", Controllers.forgotpassword);
router.post("/logout", Service.authService.userAuth, Controllers.logout);

router.post("/setPassword", Controllers.setPassword);
router.post("/socialLogin", Controllers.socialLogin);
router.post("/upload", upload.fileUpload.single('image'), Controllers.fileUpload);
router.post("/sendOtp", Service.authService.userAuth, Controllers.sendOtp);

router.post("/sendPinOtp", Service.authService.userAuth, Controllers.otp);
router.post("/verifyPinOtp", Service.authService.userAuth, Controllers.verotp);
router.put("/passCode", Service.authService.userAuth, Controllers.verifyPassCode);
router.get("/profile", Service.authService.userAuth, Controllers.getPofile);
router.delete("/profile", Service.authService.userAuth, Controllers.deletePofile);
router.post("/sendCaptureOtp", Controllers.sendCaptureOtp);

/**
 * KYC LIVENESS 
 */
router.get("/getSessionID", Service.authService.userAuth, Controllers.getSessionId);
router.get("/getConfigFile", Controllers.getAwsConfig);
router.get("/getRatifyResults/:sessionId", Service.authService.userAuth, Controllers.getRatifyResults);
router.get("/syncKyc", Service.authService.userAuth, Controllers.syncKyc);


// Dsahboard
router.get("/dashboard", Service.authService.userAuth, Controllers.dashboard);



// Notifcation 
router.get("/notification", Service.authService.userAuth, Controllers.userNotification);
router.put("/clearNotification", Service.authService.userAuth, Controllers.notificationClear);


router.post("/doc_upload", Service.authService.userAuth, Controllers.userDocUpload);

router.get("/cms", adminController.getCms);

router.get("/faq", adminController.getFaq);


router.post("/eftcallbackurl", Controllers.eftCallbackUrl);   // for EFT

router.post("/cardfieldtopup", Controllers.cardfieldtopup);
router.get("/cardfieldtopup", Controllers.cardfieldtopup);


router.post("/cardcallbackurl", Controllers.callBackUrl);
router.get("/cardcallbackurl", Controllers.callBackUrl);

router.post("/landing", Controllers.landing);
router.get("/landing", Controllers.landing);

router.post("/wtwtopup", Controllers.walletToWalletTopUp);
router.get("/wtwtopup", Controllers.walletToWalletTopUp);



router.post("/walletWithdrawal", Controllers.walletWithdrawalCallback);
router.get("/walletWithdrawal", Controllers.walletWithdrawalCallback);



router.get("/product", Controllers.getProductList);
router.post("/sales", Controllers.setSales);
router.get("/shield", Controllers.getApis);
router.post("/shield", Controllers.postApis);




router.get("/student", Controllers.getStudent);
router.put("/student/:id", Controllers.updateStudent);
router.post("/refreshToken", Controllers.refreshToken);

router.post("/airtimePayment", Service.authService.userAuth, Controllers.airtimePayment);


router.post("/ukhsheToken", Controllers.ukhesheToken);


// help
router.post("/help", Service.authService.userAuth, Controllers.addHelp);
router.get("/help", Service.authService.userAuth, Controllers.getHelp);
router.get("/help/:id", Service.authService.userAuth, Controllers.getHelp);

//error
router.post("/error", Controllers.addError);
router.get("/error", Controllers.getError);
router.get("/downloadChat/:id", Controllers.sendChat);


// chat
router.get("/chatList", Service.authService.userAuth, Controllers.getChatList);
router.get("/chat/history", Service.authService.userAuth, Controllers.getChatHistory);
router.get("/pending/chat", Service.authService.userAuth, Controllers.getCheckPendingChat);



router.get("/queryType", Controllers.getQueryList);


router.post("/chatAction", Service.authService.userAuth, Controllers.chatAction);
router.post("/sendOTPtoIdentity", Controllers.sendOTPtoIdentity);

module.exports = router;
