const router = require("express").Router();
const Controllers = require("../controllers").user;
const adminController = require("../controllers").admin;
const configController = require("../controllers").config;
const Service = require("../services");
// const ExpressBrute = require("express-brute");
const upload = require("../services/fileUpload");
const cache = require('../routeCache');


//----------onBoarding-------------------------------
// router.post("/signup", adminController.signup);
router.get("/public.bank.list", Service.authService.userAuth, configController.getBankList);
router.get("/version/:deviceType", configController.getVersionData);
router.get("/featureFlags/:deviceType", configController.getFeatureFlags);

module.exports = router;
