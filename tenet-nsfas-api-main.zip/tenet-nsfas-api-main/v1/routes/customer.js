const router = require("express").Router();
const Controllers = require("../controllers").user;
const adminController = require("../controllers").admin;
const customerController = require("../controllers").customer;
const Service = require("../services");
// const ExpressBrute = require("express-brute");
const upload = require("../services/fileUpload");



//----------onBoarding-------------------------------
// router.post("/signup", adminController.signup);
router.get("/cards-on-file", Service.authService.userAuth, customerController.getCardsOnFile);
router.get("/cards", Service.authService.userAuth, customerController.getCards);
router.get("/addresses", Service.authService.userAuth, customerController.getAddresses);
router.get("/statement/:month", Service.authService.userAuth, customerController.getStatement);

router.post("/cards-on-file", Service.authService.userAuth, customerController.createCardOnFile);
router.post("/payments", Service.authService.userAuth, customerController.createPayment);

router.put("/payments/:paymentId", Service.authService.userAuth, customerController.updatePayment);

router.delete("/cards-on-file/:cardId", Service.authService.userAuth, customerController.deleteCardOnFile);

module.exports = router;
