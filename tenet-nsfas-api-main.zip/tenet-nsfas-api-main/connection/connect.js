const mongoose = require("mongoose");
const config = require('config');
const Model = require('../models');
const mysql = require('mysql');
const fs = require('fs');
const path = require('path');



var mongoDbconnection = async function () {
    var ca = [fs.readFileSync(path.resolve(__dirname, "./global-bundle.pem"))];
    var url = config.get("mongo.url");
    console.log('mongo url: ', url);
    if (process.env.NODE_ENV == 'docker') {
        await mongoose.connect(url, {
            auth: {
                authSource: config.get("mongo.authSource")
            },
            sslValidate: true,
            sslCA: ca,
            useUnifiedTopology: true,
            useNewUrlParser: true,
            useFindAndModify: false
        });
    } else {
        await mongoose.connect(url, { useUnifiedTopology: true, useNewUrlParser: true, useFindAndModify: false });
    }
    let cms = await Model.cms.findOne({ isDeleted: false });
    if (!cms) {
        await Model.cms.create({ isDeleted: false });
    }
};




module.exports = {
    mongoDbconnection: mongoDbconnection
};